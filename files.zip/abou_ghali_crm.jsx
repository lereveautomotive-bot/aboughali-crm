import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  LayoutDashboard, Users, Car, GitBranch, Package, Wallet, Handshake,
  BarChart3, Search, Plus, Globe, ChevronDown, ChevronLeft, ChevronRight,
  X, Check, Edit2, Trash2, Printer, Paperclip, Download, Eye, Filter,
  Phone, Mail, Clock, AlertCircle, CheckCircle2, ArrowRight, ArrowLeft,
  Save, Copy, Activity, Hash, CalendarDays, Target, FileDown, UserPlus,
  Building2, TrendingUp, Sparkles, MoreHorizontal, Repeat, MapPin,
  ArrowUpRight, ArrowDownRight, UserCircle2
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  AreaChart, Area, ComposedChart
} from 'recharts';

/* =====================================================================
   ABOU GHALI CAR SALES — CRM (v1, seeded from the live database)
   =====================================================================
   Modeled on Salesforce Sales Cloud (objects, relationships, Lead→Deal
   conversion, related lists, activity timeline). Visual tokens are
   inherited verbatim from the executive_crm_dashboard remix.

   OBJECT MODEL (master-detail marked MD; lookup marked LK)
   ------------------------------------------------------------------
   User            id, name, nameAr, username, password (demo),
                   role∈{owner, partner, sales_agent, reception},
                   commissionPct
                   Seed: Montaser (owner), Jean/Yasmine (partner),
                   Ahmed Mohsen (partner), Sales Agent (sales_agent),
                   Reception (reception)

   Session         currentUser→User|null  (in-memory only; client-side
                   UX gate, NOT real authentication — anyone with
                   browser DevTools can bypass. For demos and team
                   workflow segmentation; do NOT rely on for security.)
                   Role → allowed modules:
                     owner, partner   → all modules
                     sales_agent      → stock, pipeline, payments
                     reception        → stock, pipeline, payments

   Lead            id (PIPE-###), customerName, mobile, vehicleModel,
                   color, price, stage∈{lead, negotiation,
                   pending_delivery, converted, lost}, assignedTo→User,
                   followUpDate, notes, createdAt, attachments[],
                   convertedDealId?, convertedCustomerId?

   Customer        id (CUST-###), name, nationalId, mobile,
                   totalDeals, totalSpend, totalProfit, firstDealDate,
                   lastDealDate, modelsPurchased, segment∈{standard,
                   vip, cold}, attachments[]
                   (totalDeals/Spend/Profit are computed from Deals but
                   cached for list performance; recomputed on any Deal
                   write.)

   Deal            id (DEAL-YYYY-###), year, date, customerId→LK,
                   customerName (denormalised), nationalId, mobile,
                   vehicleModel, chassis, color, listPrice, salePrice,
                   profit (computed), deliveryStatus∈{delivered,
                   pending}, jeanYasmineShare, ahmedMohsenShare, notes,
                   linkedStockId→LK, attachments[]

   Stock           id (STK-AG-###), location, vehicleModel, year, color,
                   chassis, keys, comment, status∈{in_stock, with_safia,
                   out_with_client, sold, reserved}, attachments[]

   Movement        id (STK-ALL-###), stockId→LK, vehicleModel, year,
                   color, chassis, keys, movement (free text, incl. AR),
                   inDate, outDate, comment, status

   Payment         id (PAY-YYYY-###), year, date, amount, method∈
                   {cash, bank, unknown}, dealId→LK (optional),
                   attachments[]

   MonthlySummary  month, y2025, y2026 (derived from Payments; cached)

   PartnerShare    Virtual view: per-deal split of profit between
                   jeanYasmineShare + ahmedMohsenShare. Aggregated on
                   the Partners page.

   ATTACHMENTS are stored inline as
   record.attachments = [{id, filename, mimeType, size, dataUrl,
                          uploadedBy, uploadedAt}]
   Supports any format; held in React state (demo, not production).

   OUT OF SCOPE (flagged to Montaser)
     • Service / job cards / technicians — business is car trading,
       not after-sales service. Add module only if the business expands.
     • Installments / bank financing plans — a major gap given Egyptian
       market; recommend adding a Plans table + amortization.
     • Trade-in valuation — common locally, recommend a simple table.
     • License / plate registration (مرور) tracking per delivered deal.
     • Insurance & warranty registers.
   ===================================================================== */

// ==================== i18n DICTIONARY ====================
const DICT = {
  brand: { ar: 'أبو غالي لتجارة السيارات', en: 'Abou Ghali Car Sales' },
  tagline: { ar: 'نظام إدارة العلاقات والمخزون', en: 'CRM + Stock System' },

  // Nav
  dashboard: { ar: 'لوحة التحكم', en: 'Dashboard' },
  deals: { ar: 'الصفقات', en: 'Deals' },
  customers: { ar: 'العملاء', en: 'Customers' },
  pipeline: { ar: 'المسار البيعي', en: 'Pipeline' },
  stock: { ar: 'المخزون', en: 'Stock' },
  movements: { ar: 'حركات المخزون', en: 'Stock Movements' },
  payments: { ar: 'المدفوعات', en: 'Payments' },
  partners: { ar: 'الشركاء والعمولات', en: 'Partners & Shares' },
  reports: { ar: 'التقارير', en: 'Reports' },

  // Shell
  search_placeholder: { ar: 'ابحث عن عميل، سيارة، شاسيه، هاتف…', en: 'Search customers, vehicles, chassis, phone…' },
  new: { ar: 'جديد', en: 'New' },
  language: { ar: 'اللغة', en: 'Language' },
  numerals_ar: { ar: 'أرقام عربية', en: 'Arabic numerals' },
  numerals_en: { ar: 'أرقام إنجليزية', en: 'Western numerals' },
  live: { ar: 'مباشر', en: 'Live' },
  environment: { ar: 'بيئة العمل', en: 'Environment' },

  // Auth / sign-in
  signin_title: { ar: 'تسجيل الدخول', en: 'Sign in' },
  signin_subtitle: { ar: 'نظام إدارة أبو غالي للسيارات', en: 'Abou Ghali Auto Management System' },
  signin_username: { ar: 'اسم المستخدم', en: 'Username' },
  signin_password: { ar: 'كلمة المرور', en: 'Password' },
  signin_submit: { ar: 'دخول', en: 'Sign in' },
  signin_error: { ar: 'اسم المستخدم أو كلمة المرور غير صحيحة', en: 'Invalid username or password' },
  signed_in_as: { ar: 'مسجَّل الدخول باسم', en: 'Signed in as' },
  sign_out: { ar: 'تسجيل خروج', en: 'Sign out' },
  role_owner: { ar: 'المالك', en: 'Owner' },
  role_partner: { ar: 'شريك', en: 'Partner' },
  role_sales_agent: { ar: 'موظف مبيعات', en: 'Sales agent' },
  role_reception: { ar: 'استقبال', en: 'Reception' },
  no_access_module: { ar: 'لا تملك صلاحية الوصول لهذه الصفحة', en: 'You do not have access to this page' },

  // Generic
  all: { ar: 'الكل', en: 'All' },
  save: { ar: 'حفظ', en: 'Save' },
  cancel: { ar: 'إلغاء', en: 'Cancel' },
  delete: { ar: 'حذف', en: 'Delete' },
  edit: { ar: 'تعديل', en: 'Edit' },
  view: { ar: 'عرض', en: 'View' },
  back: { ar: 'رجوع', en: 'Back' },
  print: { ar: 'طباعة', en: 'Print' },
  close: { ar: 'إغلاق', en: 'Close' },
  download: { ar: 'تنزيل', en: 'Download' },
  attach_file: { ar: 'إرفاق ملف', en: 'Attach file' },
  convert: { ar: 'تحويل', en: 'Convert' },
  no_results: { ar: 'لا توجد نتائج', en: 'No results' },
  no_data: { ar: 'لا توجد بيانات', en: 'No data yet' },
  total: { ar: 'الإجمالي', en: 'Total' },
  amount: { ar: 'القيمة', en: 'Amount' },
  date: { ar: 'التاريخ', en: 'Date' },
  status: { ar: 'الحالة', en: 'Status' },
  created: { ar: 'تاريخ الإنشاء', en: 'Created' },
  notes: { ar: 'ملاحظات', en: 'Notes' },
  details: { ar: 'التفاصيل', en: 'Details' },
  related: { ar: 'مرتبطات', en: 'Related' },
  activity_tab: { ar: 'سجل النشاط', en: 'Activity' },
  attachments: { ar: 'المرفقات', en: 'Attachments' },
  quick_actions: { ar: 'إجراءات سريعة', en: 'Quick Actions' },
  confirm_delete: { ar: 'تأكيد الحذف', en: 'Confirm delete' },
  delete_warn: { ar: 'لا يمكن التراجع عن هذا الإجراء', en: "This can't be undone" },

  // Dashboard KPIs (matched to the business — car trading)
  kpi_deals_closed: { ar: 'صفقات مكتملة', en: 'Deals closed' },
  kpi_customers: { ar: 'العملاء', en: 'Customers' },
  kpi_pipeline_value: { ar: 'قيمة المسار', en: 'Pipeline value' },
  kpi_stock_units: { ar: 'وحدات المخزون', en: 'Stock units' },
  kpi_collections_2025: { ar: 'تحصيلات ٢٠٢٥', en: 'Collections 2025' },
  kpi_collections_2026: { ar: 'تحصيلات ٢٠٢٦', en: 'Collections 2026' },
  kpi_total_profit: { ar: 'إجمالي الأرباح', en: 'Total profit' },
  kpi_partner_shares: { ar: 'عمولات الشركاء', en: 'Partner shares' },
  kpi_avg_profit: { ar: 'متوسط الربح للصفقة', en: 'Avg profit / deal' },
  kpi_delivered: { ar: 'تم التسليم', en: 'Delivered' },
  kpi_pending: { ar: 'بانتظار التسليم', en: 'Pending delivery' },
  kpi_win_rate: { ar: 'معدل الإغلاق', en: 'Win rate' },
  collections_compare: { ar: 'مقارنة التحصيلات', en: 'Collections compared' },
  profit_by_model: { ar: 'الربح حسب الموديل', en: 'Profit by model' },
  recent_deals: { ar: 'أحدث الصفقات', en: 'Recent deals' },
  top_customers: { ar: 'أفضل العملاء', en: 'Top customers' },
  stock_by_model: { ar: 'المخزون حسب الموديل', en: 'Stock by model' },
  pipeline_by_stage: { ar: 'المسار حسب المرحلة', en: 'Pipeline by stage' },
  alerts: { ar: 'تنبيهات', en: 'Alerts' },

  // Deal fields
  deal_id: { ar: 'رقم الصفقة', en: 'Deal ID' },
  customer_name: { ar: 'اسم العميل', en: 'Customer name' },
  national_id: { ar: 'الرقم القومي', en: 'National ID' },
  mobile: { ar: 'رقم الهاتف', en: 'Mobile' },
  vehicle_model: { ar: 'الموديل', en: 'Vehicle' },
  chassis: { ar: 'رقم الشاسيه', en: 'Chassis' },
  color: { ar: 'اللون', en: 'Color' },
  list_price: { ar: 'السعر الأساسي', en: 'List price' },
  sale_price: { ar: 'سعر البيع', en: 'Sale price' },
  profit: { ar: 'الربح', en: 'Profit' },
  delivery_status: { ar: 'حالة التسليم', en: 'Delivery status' },
  jean_yasmine_share: { ar: 'نصيب جان/ياسمين', en: 'Jean/Yasmine share' },
  ahmed_mohsen_share: { ar: 'نصيب أحمد محسن', en: 'Ahmed Mohsen share' },
  delivered: { ar: 'تم التسليم', en: 'Delivered' },
  pending: { ar: 'بانتظار التسليم', en: 'Pending' },

  // Customer
  customer_id: { ar: 'رقم العميل', en: 'Customer ID' },
  total_deals: { ar: 'عدد الصفقات', en: 'Total deals' },
  total_spend: { ar: 'إجمالي الإنفاق', en: 'Total spend' },
  first_deal: { ar: 'أول صفقة', en: 'First deal' },
  last_deal: { ar: 'آخر صفقة', en: 'Last deal' },
  models_purchased: { ar: 'الموديلات المشتراة', en: 'Models purchased' },
  segment: { ar: 'الشريحة', en: 'Segment' },
  seg_standard: { ar: 'عادي', en: 'Standard' },
  seg_vip: { ar: 'VIP', en: 'VIP' },
  seg_repeat: { ar: 'مكرر', en: 'Repeat' },

  // Pipeline stages
  stage: { ar: 'المرحلة', en: 'Stage' },
  stg_lead: { ar: 'عميل محتمل', en: 'Lead' },
  stg_negotiation: { ar: 'تفاوض', en: 'Negotiation' },
  stg_pending_delivery: { ar: 'بانتظار التسليم', en: 'Pending Delivery' },
  stg_converted: { ar: 'تم التحويل', en: 'Converted' },
  stg_lost: { ar: 'خاسرة', en: 'Lost' },
  assigned_to: { ar: 'الموظف المسؤول', en: 'Assigned to' },
  follow_up_date: { ar: 'موعد المتابعة', en: 'Follow-up date' },
  price: { ar: 'السعر', en: 'Price' },
  convert_to_deal: { ar: 'تحويل إلى صفقة', en: 'Convert to Deal' },
  convert_desc: { ar: 'سيتم إنشاء عميل وصفقة جديدين مرتبطين', en: 'A new Customer and Deal will be created.' },
  kanban: { ar: 'كانبان', en: 'Kanban' },
  list_view: { ar: 'قائمة', en: 'List' },

  // Stock
  stock_id: { ar: 'رقم المخزون', en: 'Stock ID' },
  location: { ar: 'الموقع', en: 'Location' },
  year: { ar: 'السنة', en: 'Year' },
  keys: { ar: 'عدد المفاتيح', en: 'Keys' },
  comment: { ar: 'ملاحظة', en: 'Comment' },
  stk_in_stock: { ar: 'في المخزن', en: 'In Stock' },
  stk_with_safia: { ar: 'لدى صفية', en: 'With Safia' },
  stk_out_client: { ar: 'لدى العميل', en: 'Out / With Client' },
  stk_sold: { ar: 'مُباع', en: 'Sold' },
  stk_reserved: { ar: 'محجوز', en: 'Reserved' },
  move_in: { ar: 'وارد', en: 'Movement In' },
  move_out: { ar: 'صادر', en: 'Movement Out' },

  // Payment
  payment_id: { ar: 'رقم الدفعة', en: 'Payment ID' },
  method: { ar: 'وسيلة الدفع', en: 'Method' },
  method_cash: { ar: 'نقدي', en: 'Cash' },
  method_bank: { ar: 'تحويل بنكي', en: 'Bank' },
  method_unknown: { ar: 'غير محدد', en: 'Unspecified' },
  link_to_deal: { ar: 'ربط بصفقة', en: 'Link to deal' },

  // Partners
  partner: { ar: 'شريك', en: 'Partner' },
  share_total: { ar: 'إجمالي العمولة', en: 'Total share' },
  share_count: { ar: 'عدد الصفقات', en: 'Deals' },
  share_avg: { ar: 'متوسط العمولة', en: 'Avg share' },

  // Months (AR)
  m_Jan: { ar: 'يناير', en: 'Jan' }, m_Feb: { ar: 'فبراير', en: 'Feb' },
  m_Mar: { ar: 'مارس', en: 'Mar' }, m_Apr: { ar: 'أبريل', en: 'Apr' },
  m_May: { ar: 'مايو', en: 'May' }, m_Jun: { ar: 'يونيو', en: 'Jun' },
  m_Jul: { ar: 'يوليو', en: 'Jul' }, m_Aug: { ar: 'أغسطس', en: 'Aug' },
  m_Sep: { ar: 'سبتمبر', en: 'Sep' }, m_Oct: { ar: 'أكتوبر', en: 'Oct' },
  m_Nov: { ar: 'نوفمبر', en: 'Nov' }, m_Dec: { ar: 'ديسمبر', en: 'Dec' },

  // Attachments
  drop_or_click: { ar: 'اسحب ملفات هنا أو اضغط للاختيار', en: 'Drop files or click to select' },
  any_format: { ar: 'أي صيغة · حتى ١٠ ميجا للملف', en: 'Any format · up to 10 MB per file' },
  no_attachments: { ar: 'لا توجد مرفقات', en: 'No attachments yet' },

  // Misc
  showing: { ar: 'عرض', en: 'Showing' },
  of: { ar: 'من', en: 'of' },
  records: { ar: 'سجل', en: 'records' },
  search: { ar: 'بحث', en: 'Search' },
  contract: { ar: 'عقد البيع', en: 'Sales Contract' },
  receipt: { ar: 'إيصال الدفع', en: 'Payment Receipt' },
  stock_card: { ar: 'بطاقة السيارة', en: 'Vehicle Card' },
  overview_tab: { ar: 'نظرة عامة', en: 'Overview' },
  convert_success: { ar: 'تم التحويل بنجاح', en: 'Converted successfully' },
  add: { ar: 'إضافة', en: 'Add' },
  remove: { ar: 'حذف', en: 'Remove' },
  uploaded_by: { ar: 'رفعه', en: 'Uploaded by' },
  printed_on: { ar: 'طُبع في', en: 'Printed' },
  thanks: { ar: 'شكراً لتعاملكم مع أبو غالي لتجارة السيارات', en: 'Thank you for your business with Abou Ghali Car Sales' },
  hq_line: { ar: '— طريق القاهرة/الإسكندرية الصحراوي · هاتف ١٦٢٢٤ —', en: '— Cairo-Alex Desert Rd · Tel: 16224 —' },
  balance: { ar: 'المتبقي', en: 'Balance' },
  collected: { ar: 'المحصل', en: 'Collected' },
  vs: { ar: 'مقابل', en: 'vs' },
  recent: { ar: 'الأحدث', en: 'Recent' },
  all_deals: { ar: 'كل الصفقات', en: 'All deals' },
  all_stages: { ar: 'كل المراحل', en: 'All stages' },
  all_methods: { ar: 'كل الوسائل', en: 'All methods' },
  all_years: { ar: 'كل السنوات', en: 'All years' },
  all_statuses: { ar: 'كل الحالات', en: 'All statuses' },
  card_view: { ar: 'بطاقات', en: 'Cards' },
  timeline: { ar: 'الجدول الزمني', en: 'Timeline' },
};

const useT = (locale) => (key) => {
  const e = DICT[key];
  if (!e) return key;
  return e[locale] ?? e.en ?? key;
};

// ==================== HELPERS ====================
const AR_DIGITS = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];

function toArabicDigits(s) {
  return String(s).replace(/\d/g, d => AR_DIGITS[+d]);
}

function fmtNumber(n, useAr) {
  if (n == null || isNaN(n)) return '—';
  const s = new Intl.NumberFormat('en-US').format(Math.round(n));
  return useAr ? toArabicDigits(s) : s;
}

function fmtCurrency(n, useAr) {
  if (n == null || isNaN(n)) return '—';
  const sign = n < 0 ? '-' : '';
  const abs = Math.abs(n);
  const body = new Intl.NumberFormat('en-US').format(Math.round(abs));
  const final = sign + body;
  return (useAr ? toArabicDigits(final) : final) + ' ' + (useAr ? 'ج.م' : 'EGP');
}

function fmtCurrencyShort(n, useAr) {
  if (n == null || isNaN(n)) return '—';
  const sign = n < 0 ? '-' : '';
  const abs = Math.abs(n);
  let body;
  if (abs >= 1e6) body = (abs / 1e6).toFixed(2) + 'M';
  else if (abs >= 1e3) body = (abs / 1e3).toFixed(0) + 'K';
  else body = Math.round(abs).toString();
  const final = sign + body;
  return (useAr ? toArabicDigits(final) : final) + ' ' + (useAr ? 'ج.م' : 'EGP');
}

function fmtDate(d, locale, useAr) {
  if (!d) return '—';
  try {
    const dt = typeof d === 'string' ? new Date(d) : d;
    if (isNaN(dt.getTime())) return String(d);
    const day = String(dt.getDate()).padStart(2, '0');
    const mo  = String(dt.getMonth() + 1).padStart(2, '0');
    const yr  = dt.getFullYear();
    const s = `${day}/${mo}/${yr}`;
    return useAr ? toArabicDigits(s) : s;
  } catch { return String(d); }
}

function initials(name) {
  if (!name) return '··';
  return name.split(/\s+/).slice(0, 2).map(w => w.charAt(0)).join('').toUpperCase();
}

function uid(prefix = 'x') {
  return prefix + '-' + Math.random().toString(36).slice(2, 9);
}

function readFileAsDataURL(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsDataURL(file);
  });
}

// Month normalization for Monthly Summary
const MONTH_MAP = {
  'January':'m_Jan','february':'m_Feb','March':'m_Mar','April':'m_Apr',
  'May':'m_May','Jun':'m_Jun','Jul':'m_Jul','Aug':'m_Aug',
  'Sept':'m_Sep','Oct':'m_Oct','Nov':'m_Nov','Dec':'m_Dec'
};

// Color mapping from Arabic swatches seen in the data
const COLOR_MAP = {
  'فيراني':   '#7a2c2c', // maroon/dark red
  'أزرق':     '#244b8f',
  'أبيض':     '#f4f4f2',
  'أسود':     '#1a1a1a',
  'فضي':      '#b5b5b5',
  'بترولي':   '#1f5b5e', // petrol
  'زيتي':     '#6b6a2c', // olive
  'بستاج':    '#8aa878', // pistachio
  'ناردو جراي':'#636466',
  'Grey':     '#636466','grey':'#636466','White':'#f4f4f2','white':'#f4f4f2',
  'Black':    '#1a1a1a','black':'#1a1a1a','blue':'#244b8f','read':'#7a2c2c',
  'gery':     '#636466','balck':'#1a1a1a','silver':'#b5b5b5','asmanty':'#6b4a2a',
};
const colorSwatch = (c) => COLOR_MAP[c] || '#888780';

// ==================== STYLES (verbatim from the remix dashboard) ====================
const CSS = `
:root {
  --color-background-primary: #ffffff;
  --color-background-secondary: #f5f4ef;
  --color-background-tertiary: #faf9f5;
  --color-background-info: #E6F1FB;
  --color-background-success: #E1F5EE;
  --color-background-warning: #FAEEDA;
  --color-background-danger: #FCEBEB;
  --color-text-primary: #141413;
  --color-text-secondary: #5f5e5a;
  --color-text-tertiary: #888780;
  --color-text-info: #0C447C;
  --color-text-success: #0F6E56;
  --color-text-warning: #854F0B;
  --color-text-danger: #A32D2D;
  --color-border-tertiary: rgba(20, 20, 19, 0.12);
  --color-border-secondary: rgba(20, 20, 19, 0.22);
  --color-border-primary: rgba(20, 20, 19, 0.35);
  --color-border-info: #378ADD;
  --color-border-success: #1D9E75;
  --color-border-warning: #BA7517;
  --color-border-danger: #E24B4A;
  --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  --font-mono: "SF Mono", Monaco, "Cascadia Code", "Roboto Mono", Consolas, monospace;
  --r-md: 8px; --r-lg: 12px; --r-xl: 16px;
}
@media (prefers-color-scheme: dark) {
  :root {
    --color-background-primary: #1f1e1d;
    --color-background-secondary: #2a2926;
    --color-background-tertiary: #141413;
    --color-background-info: #042C53;
    --color-background-success: #04342C;
    --color-background-warning: #412402;
    --color-background-danger: #501313;
    --color-text-primary: #f5f4ef;
    --color-text-secondary: #b4b2a9;
    --color-text-tertiary: #888780;
    --color-text-info: #B5D4F4;
    --color-text-success: #9FE1CB;
    --color-text-warning: #FAC775;
    --color-text-danger: #F7C1C1;
    --color-border-tertiary: rgba(245, 244, 239, 0.15);
    --color-border-secondary: rgba(245, 244, 239, 0.3);
    --color-border-primary: rgba(245, 244, 239, 0.4);
  }
}
.ag-root * { box-sizing: border-box; }
.ag-root { font-family: var(--font-sans); color: var(--color-text-primary); background: var(--color-background-tertiary); min-height: 100vh; }
.ag-root [dir="rtl"] { font-feature-settings: "ss01"; }

/* App shell */
.shell { display: grid; grid-template-columns: 240px 1fr; min-height: 100vh; }
.shell.rtl { grid-template-columns: 1fr 240px; }
@media (max-width: 900px) { .shell, .shell.rtl { grid-template-columns: 1fr; } .sidebar { display: none; } }
.sidebar { background: var(--color-background-secondary); border-right: 0.5px solid var(--color-border-tertiary); padding: 18px 12px; position: sticky; top: 0; height: 100vh; overflow-y: auto; }
.shell.rtl .sidebar { border-right: none; border-left: 0.5px solid var(--color-border-tertiary); }
.brand-block { padding: 4px 8px 14px; border-bottom: 0.5px solid var(--color-border-tertiary); margin-bottom: 10px; }
.brand-name { font-size: 15px; font-weight: 500; }
.brand-sub { font-size: 11px; color: var(--color-text-secondary); margin-top: 2px; }
.nav-item { display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: var(--r-md); font-size: 13px; color: var(--color-text-secondary); cursor: pointer; border: none; background: none; width: 100%; text-align: start; font-family: inherit; margin-bottom: 1px; }
.nav-item:hover { background: var(--color-background-primary); color: var(--color-text-primary); }
.nav-item.active { background: var(--color-text-primary); color: var(--color-background-primary); font-weight: 500; }
.nav-item.active svg { color: var(--color-background-primary); }
.nav-item svg { width: 15px; height: 15px; flex-shrink: 0; }
.nav-badge { margin-inline-start: auto; font-size: 10px; background: var(--color-background-primary); color: var(--color-text-secondary); padding: 1px 6px; border-radius: 100px; }
.nav-item.active .nav-badge { background: rgba(255,255,255,0.2); color: var(--color-background-primary); }

/* Main column */
.main { display: flex; flex-direction: column; min-width: 0; }
.topbar { display: flex; align-items: center; gap: 12px; padding: 12px 20px; background: var(--color-background-primary); border-bottom: 0.5px solid var(--color-border-tertiary); position: sticky; top: 0; z-index: 40; }
.search-box { flex: 1; max-width: 520px; position: relative; }
.search-box input { width: 100%; height: 34px; padding: 0 12px 0 34px; border: 0.5px solid var(--color-border-secondary); border-radius: var(--r-md); background: var(--color-background-tertiary); color: var(--color-text-primary); font-size: 13px; font-family: inherit; }
[dir="rtl"] .search-box input { padding: 0 34px 0 12px; }
.search-box svg { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); width: 15px; height: 15px; color: var(--color-text-tertiary); }
[dir="rtl"] .search-box svg { left: auto; right: 10px; }
.search-results { position: absolute; top: calc(100% + 4px); left: 0; right: 0; background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-md); box-shadow: 0 8px 24px rgba(0,0,0,0.08); z-index: 60; max-height: 400px; overflow-y: auto; }
.sr-group { padding: 6px 10px 4px; font-size: 10px; color: var(--color-text-tertiary); text-transform: uppercase; letter-spacing: .04em; font-weight: 500; }
.sr-item { padding: 8px 12px; cursor: pointer; font-size: 12.5px; display: flex; justify-content: space-between; gap: 10px; }
.sr-item:hover { background: var(--color-background-secondary); }
.sr-item .sub { color: var(--color-text-secondary); font-size: 11px; }

.topbar-actions { display: flex; gap: 8px; align-items: center; margin-inline-start: auto; }
.icon-btn { width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center; border: 0.5px solid var(--color-border-secondary); background: var(--color-background-primary); border-radius: var(--r-md); cursor: pointer; color: var(--color-text-primary); }
.icon-btn:hover { background: var(--color-background-secondary); }

.btn { padding: 0 14px; height: 34px; font-size: 13px; border-radius: var(--r-md); cursor: pointer; border: 0.5px solid var(--color-border-secondary); background: var(--color-background-primary); color: var(--color-text-primary); white-space: nowrap; font-family: inherit; display: inline-flex; align-items: center; gap: 6px; }
.btn:hover { background: var(--color-background-secondary); }
.btn.prim { background: var(--color-text-primary); color: var(--color-background-primary); border-color: var(--color-text-primary); }
.btn.prim:hover { opacity: .85; }
.btn.danger { color: var(--color-text-danger); }
.btn.sm { height: 28px; padding: 0 10px; font-size: 12px; }
.btn svg { width: 14px; height: 14px; }

.dropdown { position: relative; display: inline-block; }
.dd-menu { position: absolute; top: calc(100% + 4px); min-width: 180px; background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-md); box-shadow: 0 8px 24px rgba(0,0,0,0.08); padding: 4px; z-index: 60; }
[dir="ltr"] .dd-menu.end { right: 0; }
[dir="rtl"] .dd-menu.end { left: 0; }
.dd-item { display: flex; align-items: center; gap: 8px; padding: 7px 10px; border-radius: 6px; font-size: 13px; cursor: pointer; border: none; background: none; width: 100%; text-align: start; font-family: inherit; color: var(--color-text-primary); }
.dd-item:hover { background: var(--color-background-secondary); }
.dd-item svg { width: 14px; height: 14px; color: var(--color-text-secondary); }

/* Content area */
.content { padding: 18px 20px; flex: 1; }
.page-hd { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; gap: 10px; flex-wrap: wrap; }
.page-title { font-size: 20px; font-weight: 500; }
.page-sub { font-size: 12.5px; color: var(--color-text-secondary); margin-top: 2px; }

/* KPI grid */
.kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; margin-bottom: 14px; }
.kpi { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-md); padding: 12px 14px; }
.kpi-label { font-size: 11px; color: var(--color-text-secondary); margin-bottom: 4px; text-transform: uppercase; letter-spacing: .04em; }
.kpi-val { font-size: 22px; font-weight: 500; line-height: 1.1; }
.kpi-val.sm { font-size: 15px; }
.kpi-val.success { color: var(--color-text-success); }
.kpi-val.warn { color: var(--color-text-warning); }
.kpi-val.danger { color: var(--color-text-danger); }
.kpi-val.info { color: var(--color-text-info); }
.kpi-sub { font-size: 11px; color: var(--color-text-tertiary); margin-top: 4px; }
.kpi-delta { display: inline-flex; align-items: center; gap: 3px; font-size: 11px; margin-inline-start: 6px; }
.kpi-delta.up { color: var(--color-text-success); }
.kpi-delta.down { color: var(--color-text-danger); }

.section { margin-top: 18px; }
.section-hd { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 10px; gap: 10px; flex-wrap: wrap; }
.section-title { font-size: 14px; font-weight: 500; }
.section-sub { font-size: 12px; color: var(--color-text-secondary); }

.card { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-lg); padding: 16px 18px; }
.card + .card { margin-top: 10px; }
.two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.three-col { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
.span-2 { grid-column: span 2; }
@media (max-width: 900px) { .two-col, .three-col { grid-template-columns: 1fr; } .span-2 { grid-column: auto; } }

/* Bars */
.bar-row { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; font-size: 12.5px; }
.bar-label { width: 130px; color: var(--color-text-secondary); text-align: end; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.bar-track { flex: 1; height: 14px; background: var(--color-background-secondary); border-radius: 3px; overflow: hidden; }
.bar-fill { height: 100%; border-radius: 3px; transition: width 0.4s ease; }
.bar-val { min-width: 100px; font-weight: 500; text-align: end; font-size: 12.5px; }

/* Table */
.tbl-wrap { border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-lg); overflow: hidden; overflow-x: auto; }
.tbl { width: 100%; border-collapse: collapse; font-size: 13px; }
.tbl th { background: var(--color-background-secondary); color: var(--color-text-secondary); font-weight: 500; padding: 10px 11px; text-align: start; border-bottom: 0.5px solid var(--color-border-tertiary); font-size: 11px; text-transform: uppercase; letter-spacing: .03em; white-space: nowrap; }
.tbl th.r, .tbl td.r { text-align: end; }
.tbl th.c, .tbl td.c { text-align: center; }
.tbl td { padding: 10px 11px; border-bottom: 0.5px solid var(--color-border-tertiary); vertical-align: middle; }
.tbl td.nowrap { white-space: nowrap; }
.tbl tr:last-child td { border-bottom: none; }
.tbl tr.clickable:hover td { background: var(--color-background-secondary); cursor: pointer; }
.tbl td.mono { font-family: var(--font-mono); font-size: 11px; color: var(--color-text-secondary); }

/* Controls */
.controls { display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap; align-items: center; }
.controls input[type="text"], .controls input[type="number"], .controls input[type="date"], .controls select, .controls textarea, .field input, .field select, .field textarea { font-size: 13px; height: 34px; padding: 0 10px; border: 0.5px solid var(--color-border-secondary); border-radius: var(--r-md); background: var(--color-background-primary); color: var(--color-text-primary); font-family: inherit; }
.controls input[type="text"] { flex: 1; min-width: 180px; }
.controls select { min-width: 130px; }
.field textarea, .controls textarea { height: auto; min-height: 60px; padding: 8px 10px; resize: vertical; }

/* Badges */
.badge { display: inline-block; font-size: 11px; font-weight: 500; padding: 2px 8px; border-radius: 100px; line-height: 1.4; white-space: nowrap; }
.b-done { background: var(--color-background-success); color: var(--color-text-success); }
.b-wait { background: var(--color-background-warning); color: var(--color-text-warning); }
.b-cancel { background: var(--color-background-danger); color: var(--color-text-danger); }
.b-info { background: var(--color-background-info); color: var(--color-text-info); }
.b-none { background: var(--color-background-secondary); color: var(--color-text-secondary); }

/* Avatar */
.avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--color-background-info); color: var(--color-text-info); display: inline-flex; align-items: center; justify-content: center; font-weight: 500; font-size: 12px; flex-shrink: 0; }
.avatar.lg { width: 48px; height: 48px; font-size: 15px; }

/* Kanban */
.kanban { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
@media (max-width: 1100px) { .kanban { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 640px) { .kanban { grid-template-columns: 1fr; } }
.kan-col { background: var(--color-background-secondary); border-radius: var(--r-lg); padding: 10px; min-height: 260px; }
.kan-col.drag-over { outline: 2px dashed var(--color-border-primary); outline-offset: -4px; }
.kan-hd { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 500; color: var(--color-text-secondary); margin-bottom: 10px; padding-bottom: 8px; border-bottom: 0.5px solid var(--color-border-tertiary); }
.kan-card { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-md); padding: 10px 12px; margin-bottom: 7px; cursor: grab; }
.kan-card:hover { border-color: var(--color-border-primary); }
.kan-card.dragging { opacity: 0.4; }
.kan-name { font-size: 12.5px; font-weight: 500; }
.kan-sub { font-size: 11px; color: var(--color-text-secondary); margin-top: 2px; }
.kan-amt { font-size: 12px; margin-top: 6px; font-weight: 500; }

/* Stock cards */
.stock-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 10px; }
.stock-card { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-md); padding: 12px 14px; position: relative; cursor: pointer; }
.stock-card:hover { border-color: var(--color-border-primary); }
.stock-card.with-safia { background: var(--color-background-warning); border-color: var(--color-border-warning); }
.stock-card.out-client { background: var(--color-background-info); border-color: var(--color-border-info); }
.stock-model { font-size: 13px; font-weight: 500; margin-bottom: 2px; }
.stock-color { font-size: 11px; color: var(--color-text-secondary); margin-bottom: 8px; display: flex; align-items: center; gap: 6px; }
.color-dot { width: 10px; height: 10px; border-radius: 50%; border: 0.5px solid var(--color-border-secondary); }
.stock-meta { font-size: 10.5px; color: var(--color-text-tertiary); margin-top: 4px; font-family: var(--font-mono); }
.stock-badge { position: absolute; top: 10px; inset-inline-end: 10px; font-size: 10px; font-weight: 500; padding: 2px 8px; border-radius: 100px; background: var(--color-background-success); color: var(--color-text-success); text-transform: uppercase; letter-spacing: .03em; }

/* Detail page */
.detail { display: grid; grid-template-columns: 1fr 280px; gap: 14px; }
@media (max-width: 1100px) { .detail { grid-template-columns: 1fr; } }
.detail-head { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-lg); padding: 16px 18px; margin-bottom: 14px; }
.detail-head-top { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }
.detail-head-title { font-size: 18px; font-weight: 500; }
.detail-head-sub { font-size: 12.5px; color: var(--color-text-secondary); margin-top: 2px; }
.detail-head-meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; padding-top: 10px; border-top: 0.5px solid var(--color-border-tertiary); }
.meta-lbl { font-size: 10px; color: var(--color-text-tertiary); text-transform: uppercase; letter-spacing: .03em; margin-bottom: 2px; }
.meta-val { font-size: 13px; font-weight: 500; }

.tabs { display: flex; gap: 0; border-bottom: 0.5px solid var(--color-border-tertiary); margin-bottom: 14px; }
.tab { padding: 9px 14px; font-size: 13px; color: var(--color-text-secondary); background: none; border: none; cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -0.5px; font-family: inherit; }
.tab.active { color: var(--color-text-primary); border-bottom-color: var(--color-text-primary); font-weight: 500; }
.tab:hover:not(.active) { color: var(--color-text-primary); }

.sidebar-card { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-lg); padding: 14px 16px; margin-bottom: 10px; }
.sidebar-card h4 { font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: var(--color-text-secondary); font-weight: 500; margin-bottom: 10px; }
.qa-btn { display: flex; align-items: center; gap: 8px; width: 100%; padding: 7px 10px; border-radius: var(--r-md); font-size: 12.5px; color: var(--color-text-primary); cursor: pointer; background: none; border: 0.5px solid var(--color-border-tertiary); margin-bottom: 5px; font-family: inherit; text-align: start; }
.qa-btn:hover { background: var(--color-background-secondary); }
.qa-btn svg { width: 14px; height: 14px; color: var(--color-text-secondary); }

.detail-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 0.5px solid var(--color-border-tertiary); font-size: 13px; gap: 10px; }
.detail-row:last-child { border-bottom: none; }
.detail-lbl { color: var(--color-text-secondary); }
.detail-val { font-weight: 500; text-align: end; max-width: 60%; word-break: break-word; }

/* Timeline */
.timeline { position: relative; padding-inline-start: 20px; }
.timeline::before { content: ''; position: absolute; inset-inline-start: 6px; top: 4px; bottom: 4px; width: 1px; background: var(--color-border-tertiary); }
.tl-item { position: relative; padding-bottom: 14px; font-size: 12.5px; }
.tl-dot { position: absolute; inset-inline-start: -17px; top: 4px; width: 10px; height: 10px; border-radius: 50%; background: var(--color-text-primary); border: 2px solid var(--color-background-primary); box-shadow: 0 0 0 0.5px var(--color-border-secondary); }
.tl-title { font-weight: 500; }
.tl-meta { color: var(--color-text-secondary); font-size: 11px; margin-top: 2px; }

/* Modal */
.modal-wrap { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: flex-start; justify-content: center; padding: 40px 16px; z-index: 100; overflow-y: auto; }
.modal { background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--r-lg); padding: 20px 22px; width: 100%; max-width: 540px; }
.modal.wide { max-width: 780px; }
.modal h3 { font-size: 16px; font-weight: 500; margin-bottom: 14px; }
.modal-btn-row { display: flex; gap: 8px; justify-content: flex-end; margin-top: 16px; padding-top: 12px; border-top: 0.5px solid var(--color-border-tertiary); }

.field { display: flex; flex-direction: column; gap: 4px; }
.field label { font-size: 11px; color: var(--color-text-secondary); }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.form-grid .span-2 { grid-column: span 2; }
@media (max-width: 540px) { .form-grid { grid-template-columns: 1fr; } .form-grid .span-2 { grid-column: auto; } }

/* Alert */
.alert { display: flex; gap: 10px; padding: 11px 14px; border-radius: var(--r-md); font-size: 13px; margin-bottom: 8px; border: 0.5px solid; }
.alert-warn { background: var(--color-background-warning); border-color: var(--color-border-warning); color: var(--color-text-warning); }
.alert-danger { background: var(--color-background-danger); border-color: var(--color-border-danger); color: var(--color-text-danger); }
.alert-info { background: var(--color-background-info); border-color: var(--color-border-info); color: var(--color-text-info); }
.alert-success { background: var(--color-background-success); border-color: var(--color-border-success); color: var(--color-text-success); }

/* Attachment drop zone */
.dropzone { border: 1.5px dashed var(--color-border-secondary); border-radius: var(--r-md); padding: 20px; text-align: center; color: var(--color-text-secondary); font-size: 12.5px; cursor: pointer; transition: background 0.15s, border-color 0.15s; }
.dropzone:hover, .dropzone.over { background: var(--color-background-secondary); border-color: var(--color-border-primary); color: var(--color-text-primary); }
.attach-list { display: flex; flex-direction: column; gap: 6px; margin-top: 10px; }
.attach-item { display: flex; align-items: center; gap: 10px; padding: 8px 10px; background: var(--color-background-secondary); border-radius: var(--r-md); font-size: 12px; }
.attach-item .fn { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.attach-item .sz { color: var(--color-text-tertiary); font-size: 11px; }
.attach-item button { background: none; border: none; color: var(--color-text-secondary); cursor: pointer; padding: 2px; border-radius: 4px; display: inline-flex; align-items: center; }
.attach-item button:hover { background: var(--color-background-primary); color: var(--color-text-primary); }

.empty { text-align: center; padding: 40px 20px; font-size: 13px; color: var(--color-text-secondary); }

/* Print */
@media print {
  body { background: white; }
  .ag-root .shell, .ag-root .shell.rtl { grid-template-columns: 1fr !important; }
  .sidebar, .topbar, .tabs, .sidebar-card, .modal-wrap, .controls, .page-hd > .btn, .page-hd button { display: none !important; }
  .content { padding: 0 !important; }
  .printable { padding: 20px; }
  .no-print { display: none !important; }
  .card, .detail-head { border: 1px solid #000 !important; page-break-inside: avoid; }
}
.print-doc { background: white; color: black; max-width: 720px; margin: 0 auto; padding: 32px; font-size: 13px; }
.print-doc h1 { font-size: 22px; font-weight: 500; margin-bottom: 4px; }
.print-doc h2 { font-size: 16px; font-weight: 500; margin: 18px 0 8px; border-bottom: 1px solid #000; padding-bottom: 4px; }
.print-doc .p-hd { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 2px solid #000; padding-bottom: 12px; }
.print-doc table { width: 100%; border-collapse: collapse; margin-top: 8px; }
.print-doc table th, .print-doc table td { padding: 8px 10px; border: 1px solid #aaa; text-align: start; font-size: 12px; }
.print-doc .p-foot { margin-top: 40px; display: flex; justify-content: space-between; gap: 40px; font-size: 11px; color: #444; }
.print-doc .sig { margin-top: 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
.print-doc .sig div { border-top: 1px solid #000; padding-top: 6px; font-size: 12px; }

/* ==================== SIGN IN ==================== */
.signin-screen {
  position: fixed; inset: 0; display: flex; align-items: center; justify-content: center;
  background: var(--color-bg-primary);
  padding: 32px 16px; overflow-y: auto;
}
.signin-langbar {
  position: absolute; top: 18px; inset-inline-end: 22px;
  font-size: 11px; color: var(--color-text-secondary); letter-spacing: 0.04em;
}
.signin-lang { background: none; border: none; padding: 4px 6px; cursor: pointer; color: var(--color-text-secondary); font-family: inherit; font-size: 11px; }
.signin-lang.active { color: var(--color-text-primary); font-weight: 500; }
.signin-lang-sep { opacity: 0.4; padding: 0 2px; }
.signin-card {
  width: 100%; max-width: 380px;
  background: var(--color-bg-secondary);
  border: 0.5px solid var(--color-border-tertiary);
  border-radius: 4px;
  padding: 36px 32px 24px;
}
.signin-brand { margin-bottom: 28px; padding-bottom: 18px; border-bottom: 0.5px solid var(--color-border-tertiary); }
.signin-brand-name { font-size: 16px; font-weight: 500; color: var(--color-text-primary); letter-spacing: 0.01em; margin-bottom: 4px; }
.signin-brand-sub { font-size: 11px; color: var(--color-text-secondary); letter-spacing: 0.04em; text-transform: uppercase; }
.signin-form { display: flex; flex-direction: column; gap: 14px; }
.signin-field { display: flex; flex-direction: column; gap: 6px; }
.signin-field label { font-size: 10px; color: var(--color-text-secondary); letter-spacing: 0.06em; text-transform: uppercase; }
.signin-field input {
  border: 0.5px solid var(--color-border-secondary);
  background: var(--color-bg-primary);
  border-radius: 3px;
  padding: 9px 10px;
  font-size: 13px;
  font-family: inherit;
  color: var(--color-text-primary);
  outline: none;
  transition: border-color 0.12s;
}
.signin-field input:focus { border-color: var(--color-accent-primary); }
.signin-error {
  display: flex; align-items: center; gap: 6px;
  padding: 8px 10px; border-radius: 3px;
  background: #fdf6f4; color: #8b3a2a; border: 0.5px solid #e6c8be;
  font-size: 11px;
}
.signin-submit {
  margin-top: 6px;
  background: var(--color-text-primary);
  color: var(--color-bg-primary);
  border: 0.5px solid var(--color-text-primary);
  border-radius: 3px;
  padding: 10px 14px;
  font-family: inherit;
  font-size: 12px;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  font-weight: 500;
  cursor: pointer;
  transition: opacity 0.12s;
}
.signin-submit:hover { opacity: 0.85; }
.signin-divider {
  display: flex; align-items: center; gap: 10px;
  margin: 22px 0 12px;
  font-size: 10px; color: var(--color-text-secondary); letter-spacing: 0.06em; text-transform: uppercase;
}
.signin-divider::before, .signin-divider::after { content: ''; flex: 1; height: 0.5px; background: var(--color-border-tertiary); }
.signin-demo { display: flex; flex-direction: column; gap: 6px; }
.signin-demo-row {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 10px 12px;
  border: 0.5px solid var(--color-border-tertiary);
  background: var(--color-bg-primary);
  border-radius: 3px;
  cursor: pointer;
  font-family: inherit;
  text-align: start;
  transition: border-color 0.12s, background 0.12s;
}
.signin-demo-row:hover { border-color: var(--color-border-primary); background: var(--color-bg-tertiary); }
.signin-demo-meta { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.signin-demo-role { font-size: 12px; color: var(--color-text-primary); font-weight: 500; }
.signin-demo-creds { font-size: 10px; color: var(--color-text-secondary); font-family: ui-monospace, "SF Mono", Menlo, monospace; letter-spacing: 0.02em; }
.signin-demo-cta { font-size: 10px; color: var(--color-accent-primary); letter-spacing: 0.06em; text-transform: uppercase; white-space: nowrap; }
.signin-warning {
  margin-top: 14px;
  display: flex; align-items: center; gap: 6px;
  font-size: 10px; color: var(--color-text-secondary); letter-spacing: 0.02em;
  padding-top: 12px; border-top: 0.5px solid var(--color-border-tertiary);
}

/* ==================== USER PILL ==================== */
.user-pill {
  display: flex; align-items: center; gap: 8px;
  padding: 5px 10px 5px 6px;
  border: 0.5px solid var(--color-border-tertiary);
  background: var(--color-bg-primary);
  border-radius: 999px;
  cursor: pointer;
  font-family: inherit;
  transition: border-color 0.12s, background 0.12s;
}
.shell.rtl .user-pill { padding: 5px 6px 5px 10px; }
.user-pill:hover { border-color: var(--color-border-secondary); background: var(--color-bg-tertiary); }
.user-avatar {
  width: 24px; height: 24px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  background: var(--color-accent-primary);
  color: var(--color-bg-primary);
  font-size: 11px; font-weight: 600; letter-spacing: 0;
}
.user-meta { display: flex; flex-direction: column; align-items: flex-start; gap: 1px; line-height: 1.1; }
.user-name { font-size: 11px; color: var(--color-text-primary); font-weight: 500; max-width: 110px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-role { font-size: 9px; color: var(--color-text-secondary); letter-spacing: 0.06em; text-transform: uppercase; }
.dd-header { padding: 8px 12px; }
.dd-header-name { font-size: 12px; color: var(--color-text-primary); font-weight: 500; }
.dd-header-sub { font-size: 10px; color: var(--color-text-secondary); letter-spacing: 0.04em; text-transform: uppercase; margin-top: 2px; }

@media (max-width: 640px) {
  .user-meta { display: none; }
  .signin-card { padding: 28px 22px 20px; }
}
`;

// ==================== USERS (partners + staff) ====================
const SEED_USERS = [
  { id: 'u3', name: 'Montaser Abou Ghali',  nameAr: 'منتصر أبو غالي',    role: 'owner',       commissionPct: 0,    username: 'montaser', password: 'owner123' },
  { id: 'u1', name: 'Jean/Yasmine Ghali',   nameAr: 'جان/ياسمين غالي',  role: 'partner',     commissionPct: 25,   username: 'jean',     password: 'partner123' },
  { id: 'u2', name: 'Ahmed Mohsen',         nameAr: 'أحمد محسن',         role: 'partner',     commissionPct: 6.25, username: 'ahmed',    password: 'partner123' },
  { id: 'u5', name: 'Sales Agent',          nameAr: 'موظف مبيعات',       role: 'sales_agent', commissionPct: 0,    username: 'sales',    password: 'sales123' },
  { id: 'u4', name: 'Reception',            nameAr: 'الاستقبال',          role: 'reception',   commissionPct: 0,    username: 'reception',password: 'recep123' },
];

// Role → allowed modules. Anything not listed here is hidden from the sidebar
// and bounced if accessed via deep-link or programmatic navigation.
const ROLE_MODULES = {
  owner:       ['dashboard', 'deals', 'customers', 'pipeline', 'stock', 'movements', 'payments', 'partners', 'reports'],
  partner:     ['dashboard', 'deals', 'customers', 'pipeline', 'stock', 'movements', 'payments', 'partners', 'reports'],
  sales_agent: ['stock', 'pipeline', 'payments'],
  reception:   ['stock', 'pipeline', 'payments'],
};
const canAccess = (user, mod) => !!user && (ROLE_MODULES[user.role] || []).includes(mod);
const firstAllowedModule = (user) => (ROLE_MODULES[user?.role] || ['dashboard'])[0];

// ==================== SEED DATA (from Abou_ghali_CRM_Database_Full.xlsx) ====================
const SEED_DEALS = [{"id": "DEAL-2025-001", "year": 2025, "date": "2025-01-19", "customerName": "أحمد محلروس عبد اللطيف", "nationalId": "28706258800791", "mobile": "01018855613", "vehicleModel": "Audi A5", "chassis": "113668", "color": "فيراني", "listPrice": 3500000, "salePrice": 3538700, "profit": 38700, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-002", "year": 2025, "date": "2025-01-20", "customerName": "عزيزة وهبة سوريال", "nationalId": "27307041300426", "mobile": "01224064631", "vehicleModel": "ateca", "chassis": "6504091", "color": "فيراني", "listPrice": 1780000, "salePrice": 1790000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-003", "year": 2025, "date": "2025-02-28", "customerName": "مصطف محمد عبد الحميد", "nationalId": "27903010100391", "mobile": null, "vehicleModel": "Traco", "chassis": "12117", "color": "فيراني", "listPrice": 2300000, "salePrice": 2330000, "profit": 30000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-004", "year": 2025, "date": "2025-03-06", "customerName": "تامر عبد الرحمن زكي", "nationalId": "27402170104172", "mobile": null, "vehicleModel": "BMW 520", "chassis": "76779", "color": "فيراني", "listPrice": 5400000, "salePrice": 5500000, "profit": 100000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-005", "year": 2025, "date": "2025-03-18", "customerName": "جمال عادل أبو ضيف", "nationalId": "25810150102452", "mobile": null, "vehicleModel": "Tigwan 2024", "chassis": "521097", "color": "فيراني", "listPrice": 2630000, "salePrice": 2650000, "profit": 20000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-006", "year": 2025, "date": "2025-04-23", "customerName": "عبد الرحمن علي محمد", "nationalId": "30104010105697", "mobile": null, "vehicleModel": "ateca", "chassis": "6513217", "color": "أزرق", "listPrice": 1785000, "salePrice": 1795000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-007", "year": 2025, "date": "2025-05-13", "customerName": "أحمد بلال أحمد بلال", "nationalId": "30110203300519", "mobile": null, "vehicleModel": "Audi Q8", "chassis": "11843", "color": "أزرق", "listPrice": 7250000, "salePrice": 7500000, "profit": 250000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-008", "year": 2025, "date": "2025-05-20", "customerName": "كريم نبيل أحمد محمد", "nationalId": "28308280100056", "mobile": null, "vehicleModel": "Traco", "chassis": "14143", "color": "زيتي", "listPrice": 2290000, "salePrice": 2305000, "profit": 15000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-009", "year": 2025, "date": "2025-05-22", "customerName": "راندا محمود محمد محمود", "nationalId": "27606050102685", "mobile": null, "vehicleModel": "BMW X1", "chassis": "205088766", "color": "أسود", "listPrice": 3200000, "salePrice": 3300000, "profit": 100000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-010", "year": 2025, "date": "2025-06-04", "customerName": "ماريا رامي رفعت غالي", "nationalId": "30405180105365", "mobile": null, "vehicleModel": "Leon", "chassis": "38204", "color": "فيراني", "listPrice": 1480000, "salePrice": 1520000, "profit": 40000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-011", "year": 2025, "date": "2025-06-03", "customerName": "أسامة ميلاد عوض", "nationalId": "27010290101414", "mobile": null, "vehicleModel": "Arona", "chassis": "506150", "color": "فيراني", "listPrice": 1315000, "salePrice": 1325000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-012", "year": 2025, "date": "2025-06-04", "customerName": "وليد محمد علي لاشين", "nationalId": "26610041200931", "mobile": null, "vehicleModel": "Traco", "chassis": "12437", "color": "زيتي", "listPrice": 2290000, "salePrice": 2328000, "profit": 38000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-013", "year": 2025, "date": null, "customerName": "رمونده فوزي عبد القدوس", "nationalId": "28507040103409", "mobile": null, "vehicleModel": "Traco", "chassis": "13616", "color": "أزرق", "listPrice": 2290000, "salePrice": 2350000, "profit": 60000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-014", "year": 2025, "date": "2025-06-12", "customerName": "أحمد مصطفي إبراهيم مصطفي", "nationalId": "27010120100898", "mobile": null, "vehicleModel": "AUDI Q3", "chassis": "1125512", "color": "فيراني", "listPrice": 2950000, "salePrice": 2950000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-015", "year": 2025, "date": "2025-06-10", "customerName": "أسماء زين العابدين موسي", "nationalId": "29304040100162", "mobile": null, "vehicleModel": "Ibiza", "chassis": "508192", "color": "أزرق", "listPrice": 1265000, "salePrice": 1300000, "profit": 35000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-016", "year": 2025, "date": "2025-06-30", "customerName": "أشرف الكبابجي", "nationalId": null, "mobile": "خاص / سالم / مستعملة", "vehicleModel": "ateca", "chassis": "6503204", "color": "فيراني", "listPrice": 1720000, "salePrice": 1720000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-017", "year": 2025, "date": "2025-07-10", "customerName": "محمود أنور فكري إبراهيم", "nationalId": "28608270104138", "mobile": "خاص / سالم / مستعملة", "vehicleModel": "Cupra Terrmara", "chassis": "1031137", "color": "أبيض", "listPrice": 2350000, "salePrice": 2350000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-018", "year": 2025, "date": "2025-07-09", "customerName": "ألاء نزية مصطفي محمد", "nationalId": "29801150103527", "mobile": null, "vehicleModel": "Leon", "chassis": "36543", "color": "فيراني", "listPrice": 1460000, "salePrice": 1470000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-019", "year": 2025, "date": "2025-07-15", "customerName": "سيفين عصام زكي", "nationalId": "29407070102511", "mobile": null, "vehicleModel": "AUDI Q3", "chassis": "1125780", "color": "فيراني", "listPrice": 2850000, "salePrice": 3050000, "profit": 200000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-020", "year": 2025, "date": "2025-08-06", "customerName": "عبد الرحمن عثمان هلال", "nationalId": "30406142103991", "mobile": null, "vehicleModel": "Leon", "chassis": "69473", "color": "بترولي", "listPrice": 1465000, "salePrice": 1470000, "profit": 5000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-021", "year": 2025, "date": "2025-08-12", "customerName": "اسلام ياسر برئ محمد", "nationalId": "27808120106111", "mobile": null, "vehicleModel": "Audi A3", "chassis": "124364", "color": "فيراني", "listPrice": 2300000, "salePrice": 2300000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-022", "year": 2025, "date": "2025-08-12", "customerName": "ماهر عجيب عزيز", "nationalId": "25202172500699", "mobile": null, "vehicleModel": "ateca", "chassis": "6528412", "color": "فضي", "listPrice": 1700000, "salePrice": 1730000, "profit": 30000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-023", "year": 2025, "date": "2025-08-17", "customerName": "شذي رجائي بطرس عبد السيد", "nationalId": "27711022401063", "mobile": "مستعملة / سالم", "vehicleModel": "curra Terrmara", "chassis": "1029820", "color": "أسود", "listPrice": 2300000, "salePrice": 2350000, "profit": 50000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-024", "year": 2025, "date": "2025-09-01", "customerName": "فاتن هشام فتحي", "nationalId": "29901230201621", "mobile": null, "vehicleModel": "ateca", "chassis": "6529997", "color": "فيراني", "listPrice": 1700000, "salePrice": 1700000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-025", "year": 2025, "date": "2025-09-14", "customerName": "اسلام أحمد مجدي إبراهيم", "nationalId": "28807120102059", "mobile": null, "vehicleModel": "AUDI Q3", "chassis": "1085241", "color": "فيراني", "listPrice": 2800000, "salePrice": 2825000, "profit": 25000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-026", "year": 2025, "date": "2025-09-22", "customerName": "سارا هاني محمد", "nationalId": "29903130101304", "mobile": null, "vehicleModel": "Ibiza", "chassis": "581489", "color": "فيراني", "listPrice": 1200000, "salePrice": 1210000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-027", "year": 2025, "date": "2025-09-04", "customerName": "ماريز علاء ميخائيل", "nationalId": "28511190100065", "mobile": null, "vehicleModel": "Ibiza", "chassis": "579969", "color": "أزرق", "listPrice": 1200000, "salePrice": 1205000, "profit": 5000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-028", "year": 2025, "date": "2025-10-19", "customerName": "مارك عادل يوسف أنور", "nationalId": "30003110102791", "mobile": null, "vehicleModel": "Leon", "chassis": "11015", "color": "أزرق", "listPrice": 1470000, "salePrice": 1480000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-029", "year": 2025, "date": "2025-10-26", "customerName": "أحمد بلال أحمد بلال", "nationalId": "30110203300519", "mobile": null, "vehicleModel": "Cupra Terrmara", "chassis": "1030715", "color": "أبيض", "listPrice": 2250000, "salePrice": 2300000, "profit": 50000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-030", "year": 2025, "date": "2025-10-27", "customerName": "مي علي محمد عبد الباقي", "nationalId": "30312100106465", "mobile": null, "vehicleModel": "Leon", "chassis": "9921", "color": "فيراني", "listPrice": 1460000, "salePrice": 1475000, "profit": 15000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-031", "year": 2025, "date": "2025-10-30", "customerName": "ابرأم رجائي لطيف سعد", "nationalId": "29510012429778", "mobile": null, "vehicleModel": "Leon", "chassis": "355214", "color": "فيراني", "listPrice": 1400000, "salePrice": 1400000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-032", "year": 2025, "date": "2025-12-06", "customerName": "محمد نعمان ماضي الرخاوي", "nationalId": "26001118800138", "mobile": null, "vehicleModel": "Ibiza", "chassis": "530276", "color": "فيراني", "listPrice": 975000, "salePrice": 975000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-033", "year": 2025, "date": "2025-12-17", "customerName": "محمد لطفي عبد الغني", "nationalId": "28702281403052", "mobile": null, "vehicleModel": "curra Terrmara", "chassis": "1029996", "color": "أسود", "listPrice": 2000000, "salePrice": 2050000, "profit": 50000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2025-034", "year": 2025, "date": "2025-12-21", "customerName": "شركة ال ام محمد وحسام لتجارة السيارات", "nationalId": null, "mobile": null, "vehicleModel": "Mercedes E200 2026", "chassis": "235603", "color": "أسود", "listPrice": 5000000, "salePrice": 5050000, "profit": 50000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2026-001", "year": 2026, "date": null, "customerName": "أسامة حسن عيسي عاشور", "nationalId": "26208290103795", "mobile": "01223797414", "vehicleModel": "Toyota urban Cruiser2026", "chassis": "104382", "color": "فضي", "listPrice": 1350000, "salePrice": 1365000, "profit": 15000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 7500, "ahmedMohsenShare": 1875, "notes": null}, {"id": "DEAL-2026-002", "year": 2026, "date": null, "customerName": "محمود محمد ربيع محمود", "nationalId": "29509270400298", "mobile": null, "vehicleModel": "ateca", "chassis": "651933", "color": "أزرق", "listPrice": 1580000, "salePrice": 1580000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2026-003", "year": 2026, "date": null, "customerName": "شريف نعيم فرج بولس", "nationalId": "275008010008", "mobile": "01001458030", "vehicleModel": "Tigwan 2026", "chassis": "537198", "color": "فيراني", "listPrice": 2320000, "salePrice": 2350000, "profit": 30000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 15000, "ahmedMohsenShare": 3750, "notes": null}, {"id": "DEAL-2026-004", "year": 2026, "date": null, "customerName": "حازم احمد محمود محمد", "nationalId": "30010220103676", "mobile": null, "vehicleModel": "CupraTeramar", "chassis": "1042236", "color": "أسود", "listPrice": 1950000, "salePrice": 1940000, "profit": -10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": -5000, "ahmedMohsenShare": -1250, "notes": null}, {"id": "DEAL-2026-005", "year": 2026, "date": null, "customerName": "نيفين وفا حامد حجازي", "nationalId": "2800120102969", "mobile": "01016657666", "vehicleModel": "CupraTeramar", "chassis": "1041683", "color": "أبيض", "listPrice": 1950000, "salePrice": 1940000, "profit": -10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": -5000, "ahmedMohsenShare": -1250, "notes": null}, {"id": "DEAL-2026-006", "year": 2026, "date": null, "customerName": "مازن مروان محمد ابو المعاطي", "nationalId": "29712150102331", "mobile": "01020630939", "vehicleModel": "CupraTeramar", "chassis": "1009453", "color": "أسود", "listPrice": 2090000, "salePrice": 2100000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 5000, "ahmedMohsenShare": 1250, "notes": null}, {"id": "DEAL-2026-007", "year": 2026, "date": null, "customerName": "بيتر نبيه لبيب", "nationalId": "27810082403373", "mobile": "01222459050", "vehicleModel": "ateca", "chassis": "6509997", "color": "فيراني", "listPrice": 1650000, "salePrice": 1650000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 0, "ahmedMohsenShare": 0, "notes": null}, {"id": "DEAL-2026-008", "year": 2026, "date": null, "customerName": "مدحت منير سدرة مجلع", "nationalId": "26601212800131", "mobile": null, "vehicleModel": "Ibiza", "chassis": "575803", "color": "بستاج", "listPrice": 1215000, "salePrice": 1230000, "profit": 15000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 7500, "ahmedMohsenShare": 1875, "notes": null}, {"id": "DEAL-2026-009", "year": 2026, "date": null, "customerName": "مايكل ممدوح نصيف زخاري", "nationalId": "27811270104495", "mobile": "01015303034", "vehicleModel": "Leon", "chassis": "37873", "color": "أبيض", "listPrice": 1445000, "salePrice": 1450000, "profit": 5000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 2500, "ahmedMohsenShare": 625, "notes": null}, {"id": "DEAL-2026-010", "year": 2026, "date": null, "customerName": "فيبي عبد الملاك صليب غطاس", "nationalId": "28801142402643", "mobile": "01000000000", "vehicleModel": "Toyota urban Cruiser2026", "chassis": "105097", "color": "فضي", "listPrice": 1350000, "salePrice": 1370000, "profit": 20000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 10000, "ahmedMohsenShare": 2500, "notes": null}, {"id": "DEAL-2026-011", "year": 2026, "date": null, "customerName": "هاني محمد جمال الدين احمد", "nationalId": "2680060101951", "mobile": "01001401077", "vehicleModel": "Arona", "chassis": "572205", "color": "فيراني", "listPrice": 1200000, "salePrice": 1215000, "profit": 15000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 7500, "ahmedMohsenShare": 1875, "notes": null}, {"id": "DEAL-2026-012", "year": 2026, "date": null, "customerName": "الرضا موتورز لتجارة السيارات", "nationalId": null, "mobile": null, "vehicleModel": "Ibiza", "chassis": "572970", "color": "فيراني", "listPrice": 1200000, "salePrice": 1210000, "profit": 10000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 5000, "ahmedMohsenShare": 1250, "notes": null}, {"id": "DEAL-2026-013", "year": 2026, "date": null, "customerName": "فادي شنودة أنور", "nationalId": "29106152700557", "mobile": null, "vehicleModel": "curra Terrmara", "chassis": "1017880", "color": "أزرق", "listPrice": 2230000, "salePrice": 2210000, "profit": -20000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 5000, "ahmedMohsenShare": 1250, "notes": null}, {"id": "DEAL-2026-014", "year": 2026, "date": null, "customerName": "هايدي عادل جرجس", "nationalId": "27809240101828", "mobile": "01060606223", "vehicleModel": "curra Terrmara", "chassis": "1042335", "color": "أسود", "listPrice": 2100000, "salePrice": 2170000, "profit": 70000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 35000, "ahmedMohsenShare": 8750, "notes": null}, {"id": "DEAL-2026-015", "year": 2026, "date": null, "customerName": "أحمد محمود محمد توفيق", "nationalId": "2950210200518", "mobile": null, "vehicleModel": "curra Terrmara", "chassis": "1012063", "color": "أزرق", "listPrice": 2230000, "salePrice": 2250000, "profit": 20000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 10000, "ahmedMohsenShare": 2500, "notes": null}, {"id": "DEAL-2026-016", "year": 2026, "date": null, "customerName": "عيسي عياد مسعود بشير", "nationalId": "27008152102758", "mobile": null, "vehicleModel": "Tayron 2026", "chassis": "21635", "color": "فضي", "listPrice": 2875000, "salePrice": 2930000, "profit": 55000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 40000, "ahmedMohsenShare": 10000, "notes": null}, {"id": "DEAL-2026-017", "year": 2026, "date": null, "customerName": "باكينام شريف متولي محمد", "nationalId": "30008280104405", "mobile": null, "vehicleModel": "Cupra formintor 2026", "chassis": "47163", "color": "أبيض", "listPrice": 1850000, "salePrice": 1975000, "profit": 125000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 62500, "ahmedMohsenShare": 15625, "notes": null}, {"id": "DEAL-2026-018", "year": 2026, "date": null, "customerName": "مراد ياسر حسني أحمد عبد الرحمن", "nationalId": "3050319010577", "mobile": null, "vehicleModel": "Arona", "chassis": "563658", "color": "أسود", "listPrice": 1250000, "salePrice": 1275000, "profit": 25000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 12500, "ahmedMohsenShare": 3125, "notes": null}, {"id": "DEAL-2026-019", "year": 2026, "date": null, "customerName": "محمد محمد السيد محمود", "nationalId": "20406050300294", "mobile": null, "vehicleModel": "Cupra formintor 2026", "chassis": "49890", "color": "ناردو جراي", "listPrice": 1850000, "salePrice": 2150000, "profit": 300000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 142500, "ahmedMohsenShare": 35625, "notes": null}, {"id": "DEAL-2026-020", "year": 2026, "date": null, "customerName": "صفية أوتوموتيف", "nationalId": null, "mobile": null, "vehicleModel": "curra Terrmara", "chassis": "1043715", "color": "أبيض", "listPrice": 2245000, "salePrice": 2245000, "profit": 0, "deliveryStatus": "تم التسليم", "jeanYasmineShare": -2500, "ahmedMohsenShare": -625, "notes": null}, {"id": "DEAL-2026-021", "year": 2026, "date": null, "customerName": "ياسمين طارق سيد يوسف", "nationalId": "28804020100289", "mobile": null, "vehicleModel": "curra Terrmara 2026", "chassis": "1015007", "color": "أزرق", "listPrice": 2350000, "salePrice": 2300000, "profit": -50000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": -25000, "ahmedMohsenShare": -6250, "notes": null}, {"id": "DEAL-2026-022", "year": 2026, "date": null, "customerName": "محمد السيد فيصل محمد", "nationalId": "28508050102539", "mobile": null, "vehicleModel": "curra Terrmara 2026", "chassis": "1013038", "color": "أزرق", "listPrice": 2350000, "salePrice": 2300000, "profit": -50000, "deliveryStatus": null, "jeanYasmineShare": -25000, "ahmedMohsenShare": -6250, "notes": null}, {"id": "DEAL-2026-023", "year": 2026, "date": null, "customerName": "معرض / رضا", "nationalId": null, "mobile": null, "vehicleModel": "curra Terrmara 2026", "chassis": "1011674", "color": "أزرق", "listPrice": 2500000, "salePrice": 2475000, "profit": -25000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": -12500, "ahmedMohsenShare": -3125, "notes": null}, {"id": "DEAL-2026-024", "year": 2026, "date": null, "customerName": "شرين عاطف فاروق طانيوس", "nationalId": "28506010102941", "mobile": null, "vehicleModel": "Arona", "chassis": "587779", "color": "فيراني", "listPrice": 1400000, "salePrice": 1450000, "profit": 50000, "deliveryStatus": "تم التسليم", "jeanYasmineShare": 25000, "ahmedMohsenShare": 0, "notes": null}] ;

const SEED_CUSTOMERS = [{"id": "CUST-001", "name": "أحمد محلروس عبد اللطيف", "nationalId": "28706258800791", "mobile": "01018855613", "totalDeals": 1, "totalSpend": 3538700, "totalProfit": 38700, "firstDealDate": "2025-01-19", "lastDealDate": "2025-01-19", "modelsPurchased": "Audi A5", "segment": "Standard"}, {"id": "CUST-002", "name": "عزيزة وهبة سوريال", "nationalId": "27307041300426", "mobile": "01224064631", "totalDeals": 1, "totalSpend": 1790000, "totalProfit": 10000, "firstDealDate": "2025-01-20", "lastDealDate": "2025-01-20", "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-003", "name": "مصطف محمد عبد الحميد", "nationalId": "27903010100391", "mobile": null, "totalDeals": 1, "totalSpend": 2330000, "totalProfit": 30000, "firstDealDate": "2025-02-28", "lastDealDate": "2025-02-28", "modelsPurchased": "Traco", "segment": "Standard"}, {"id": "CUST-004", "name": "تامر عبد الرحمن زكي", "nationalId": "27402170104172", "mobile": null, "totalDeals": 1, "totalSpend": 5500000, "totalProfit": 100000, "firstDealDate": "2025-03-06", "lastDealDate": "2025-03-06", "modelsPurchased": "BMW 520", "segment": "Standard"}, {"id": "CUST-005", "name": "جمال عادل أبو ضيف", "nationalId": "25810150102452", "mobile": null, "totalDeals": 1, "totalSpend": 2650000, "totalProfit": 20000, "firstDealDate": "2025-03-18", "lastDealDate": "2025-03-18", "modelsPurchased": "Tigwan 2024", "segment": "Standard"}, {"id": "CUST-006", "name": "عبد الرحمن علي محمد", "nationalId": "30104010105697", "mobile": null, "totalDeals": 1, "totalSpend": 1795000, "totalProfit": 10000, "firstDealDate": "2025-04-23", "lastDealDate": "2025-04-23", "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-007", "name": "أحمد بلال أحمد بلال", "nationalId": "30110203300519", "mobile": null, "totalDeals": 2, "totalSpend": 9800000, "totalProfit": 300000, "firstDealDate": "2025-05-13", "lastDealDate": "2025-10-26", "modelsPurchased": "Audi Q8, Cupra Terrmara", "segment": "VIP"}, {"id": "CUST-008", "name": "كريم نبيل أحمد محمد", "nationalId": "28308280100056", "mobile": null, "totalDeals": 1, "totalSpend": 2305000, "totalProfit": 15000, "firstDealDate": "2025-05-20", "lastDealDate": "2025-05-20", "modelsPurchased": "Traco", "segment": "Standard"}, {"id": "CUST-009", "name": "راندا محمود محمد محمود", "nationalId": "27606050102685", "mobile": null, "totalDeals": 1, "totalSpend": 3300000, "totalProfit": 100000, "firstDealDate": "2025-05-22", "lastDealDate": "2025-05-22", "modelsPurchased": "BMW X1", "segment": "Standard"}, {"id": "CUST-010", "name": "ماريا رامي رفعت غالي", "nationalId": "30405180105365", "mobile": null, "totalDeals": 1, "totalSpend": 1520000, "totalProfit": 40000, "firstDealDate": "2025-06-04", "lastDealDate": "2025-06-04", "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-011", "name": "أسامة ميلاد عوض", "nationalId": "27010290101414", "mobile": null, "totalDeals": 1, "totalSpend": 1325000, "totalProfit": 10000, "firstDealDate": "2025-06-03", "lastDealDate": "2025-06-03", "modelsPurchased": "Arona", "segment": "Standard"}, {"id": "CUST-012", "name": "وليد محمد علي لاشين", "nationalId": "26610041200931", "mobile": null, "totalDeals": 1, "totalSpend": 2328000, "totalProfit": 38000, "firstDealDate": "2025-06-04", "lastDealDate": "2025-06-04", "modelsPurchased": "Traco", "segment": "Standard"}, {"id": "CUST-013", "name": "رمونده فوزي عبد القدوس", "nationalId": "28507040103409", "mobile": null, "totalDeals": 1, "totalSpend": 2350000, "totalProfit": 60000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Traco", "segment": "Standard"}, {"id": "CUST-014", "name": "أحمد مصطفي إبراهيم مصطفي", "nationalId": "27010120100898", "mobile": null, "totalDeals": 1, "totalSpend": 2950000, "totalProfit": 0, "firstDealDate": "2025-06-12", "lastDealDate": "2025-06-12", "modelsPurchased": "AUDI Q3", "segment": "Standard"}, {"id": "CUST-015", "name": "أسماء زين العابدين موسي", "nationalId": "29304040100162", "mobile": null, "totalDeals": 1, "totalSpend": 1300000, "totalProfit": 35000, "firstDealDate": "2025-06-10", "lastDealDate": "2025-06-10", "modelsPurchased": "Ibiza", "segment": "Standard"}, {"id": "CUST-016", "name": "أشرف الكبابجي", "nationalId": null, "mobile": "خاص / سالم / مستعملة", "totalDeals": 1, "totalSpend": 1720000, "totalProfit": 0, "firstDealDate": "2025-06-30", "lastDealDate": "2025-06-30", "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-017", "name": "محمود أنور فكري إبراهيم", "nationalId": "28608270104138", "mobile": "خاص / سالم / مستعملة", "totalDeals": 1, "totalSpend": 2350000, "totalProfit": 0, "firstDealDate": "2025-07-10", "lastDealDate": "2025-07-10", "modelsPurchased": "Cupra Terrmara", "segment": "Standard"}, {"id": "CUST-018", "name": "ألاء نزية مصطفي محمد", "nationalId": "29801150103527", "mobile": null, "totalDeals": 1, "totalSpend": 1470000, "totalProfit": 10000, "firstDealDate": "2025-07-09", "lastDealDate": "2025-07-09", "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-019", "name": "سيفين عصام زكي", "nationalId": "29407070102511", "mobile": null, "totalDeals": 1, "totalSpend": 3050000, "totalProfit": 200000, "firstDealDate": "2025-07-15", "lastDealDate": "2025-07-15", "modelsPurchased": "AUDI Q3", "segment": "Standard"}, {"id": "CUST-020", "name": "عبد الرحمن عثمان هلال", "nationalId": "30406142103991", "mobile": null, "totalDeals": 1, "totalSpend": 1470000, "totalProfit": 5000, "firstDealDate": "2025-08-06", "lastDealDate": "2025-08-06", "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-021", "name": "اسلام ياسر برئ محمد", "nationalId": "27808120106111", "mobile": null, "totalDeals": 1, "totalSpend": 2300000, "totalProfit": 0, "firstDealDate": "2025-08-12", "lastDealDate": "2025-08-12", "modelsPurchased": "Audi A3", "segment": "Standard"}, {"id": "CUST-022", "name": "ماهر عجيب عزيز", "nationalId": "25202172500699", "mobile": null, "totalDeals": 1, "totalSpend": 1730000, "totalProfit": 30000, "firstDealDate": "2025-08-12", "lastDealDate": "2025-08-12", "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-023", "name": "شذي رجائي بطرس عبد السيد", "nationalId": "27711022401063", "mobile": "مستعملة / سالم", "totalDeals": 1, "totalSpend": 2350000, "totalProfit": 50000, "firstDealDate": "2025-08-17", "lastDealDate": "2025-08-17", "modelsPurchased": "curra Terrmara", "segment": "Standard"}, {"id": "CUST-024", "name": "فاتن هشام فتحي", "nationalId": "29901230201621", "mobile": null, "totalDeals": 1, "totalSpend": 1700000, "totalProfit": 0, "firstDealDate": "2025-09-01", "lastDealDate": "2025-09-01", "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-025", "name": "اسلام أحمد مجدي إبراهيم", "nationalId": "28807120102059", "mobile": null, "totalDeals": 1, "totalSpend": 2825000, "totalProfit": 25000, "firstDealDate": "2025-09-14", "lastDealDate": "2025-09-14", "modelsPurchased": "AUDI Q3", "segment": "Standard"}, {"id": "CUST-026", "name": "سارا هاني محمد", "nationalId": "29903130101304", "mobile": null, "totalDeals": 1, "totalSpend": 1210000, "totalProfit": 10000, "firstDealDate": "2025-09-22", "lastDealDate": "2025-09-22", "modelsPurchased": "Ibiza", "segment": "Standard"}, {"id": "CUST-027", "name": "ماريز علاء ميخائيل", "nationalId": "28511190100065", "mobile": null, "totalDeals": 1, "totalSpend": 1205000, "totalProfit": 5000, "firstDealDate": "2025-09-04", "lastDealDate": "2025-09-04", "modelsPurchased": "Ibiza", "segment": "Standard"}, {"id": "CUST-028", "name": "مارك عادل يوسف أنور", "nationalId": "30003110102791", "mobile": null, "totalDeals": 1, "totalSpend": 1480000, "totalProfit": 10000, "firstDealDate": "2025-10-19", "lastDealDate": "2025-10-19", "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-029", "name": "مي علي محمد عبد الباقي", "nationalId": "30312100106465", "mobile": null, "totalDeals": 1, "totalSpend": 1475000, "totalProfit": 15000, "firstDealDate": "2025-10-27", "lastDealDate": "2025-10-27", "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-030", "name": "ابرأم رجائي لطيف سعد", "nationalId": "29510012429778", "mobile": null, "totalDeals": 1, "totalSpend": 1400000, "totalProfit": 0, "firstDealDate": "2025-10-30", "lastDealDate": "2025-10-30", "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-031", "name": "محمد نعمان ماضي الرخاوي", "nationalId": "26001118800138", "mobile": null, "totalDeals": 1, "totalSpend": 975000, "totalProfit": 0, "firstDealDate": "2025-12-06", "lastDealDate": "2025-12-06", "modelsPurchased": "Ibiza", "segment": "Standard"}, {"id": "CUST-032", "name": "محمد لطفي عبد الغني", "nationalId": "28702281403052", "mobile": null, "totalDeals": 1, "totalSpend": 2050000, "totalProfit": 50000, "firstDealDate": "2025-12-17", "lastDealDate": "2025-12-17", "modelsPurchased": "curra Terrmara", "segment": "Standard"}, {"id": "CUST-033", "name": "شركة ال ام محمد وحسام لتجارة السيارات", "nationalId": null, "mobile": null, "totalDeals": 1, "totalSpend": 5050000, "totalProfit": 50000, "firstDealDate": "2025-12-21", "lastDealDate": "2025-12-21", "modelsPurchased": "Mercedes E200 2026", "segment": "Standard"}, {"id": "CUST-034", "name": "أسامة حسن عيسي عاشور", "nationalId": "26208290103795", "mobile": "01223797414", "totalDeals": 1, "totalSpend": 1365000, "totalProfit": 15000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Toyota urban Cruiser2026", "segment": "Standard"}, {"id": "CUST-035", "name": "محمود محمد ربيع محمود", "nationalId": "29509270400298", "mobile": null, "totalDeals": 1, "totalSpend": 1580000, "totalProfit": 0, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-036", "name": "شريف نعيم فرج بولس", "nationalId": "275008010008", "mobile": "01001458030", "totalDeals": 1, "totalSpend": 2350000, "totalProfit": 30000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Tigwan 2026", "segment": "Standard"}, {"id": "CUST-037", "name": "حازم احمد محمود محمد", "nationalId": "30010220103676", "mobile": null, "totalDeals": 1, "totalSpend": 1940000, "totalProfit": -10000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "CupraTeramar", "segment": "Standard"}, {"id": "CUST-038", "name": "نيفين وفا حامد حجازي", "nationalId": "2800120102969", "mobile": "01016657666", "totalDeals": 1, "totalSpend": 1940000, "totalProfit": -10000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "CupraTeramar", "segment": "Standard"}, {"id": "CUST-039", "name": "مازن مروان محمد ابو المعاطي", "nationalId": "29712150102331", "mobile": "01020630939", "totalDeals": 1, "totalSpend": 2100000, "totalProfit": 10000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "CupraTeramar", "segment": "Standard"}, {"id": "CUST-040", "name": "بيتر نبيه لبيب", "nationalId": "27810082403373", "mobile": "01222459050", "totalDeals": 1, "totalSpend": 1650000, "totalProfit": 0, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "ateca", "segment": "Standard"}, {"id": "CUST-041", "name": "مدحت منير سدرة مجلع", "nationalId": "26601212800131", "mobile": null, "totalDeals": 1, "totalSpend": 1230000, "totalProfit": 15000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Ibiza", "segment": "Standard"}, {"id": "CUST-042", "name": "مايكل ممدوح نصيف زخاري", "nationalId": "27811270104495", "mobile": "01015303034", "totalDeals": 1, "totalSpend": 1450000, "totalProfit": 5000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Leon", "segment": "Standard"}, {"id": "CUST-043", "name": "فيبي عبد الملاك صليب غطاس", "nationalId": "28801142402643", "mobile": "01000000000", "totalDeals": 1, "totalSpend": 1370000, "totalProfit": 20000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Toyota urban Cruiser2026", "segment": "Standard"}, {"id": "CUST-044", "name": "هاني محمد جمال الدين احمد", "nationalId": "2680060101951", "mobile": "01001401077", "totalDeals": 1, "totalSpend": 1215000, "totalProfit": 15000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Arona", "segment": "Standard"}, {"id": "CUST-045", "name": "الرضا موتورز لتجارة السيارات", "nationalId": null, "mobile": null, "totalDeals": 1, "totalSpend": 1210000, "totalProfit": 10000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Ibiza", "segment": "Standard"}, {"id": "CUST-046", "name": "فادي شنودة أنور", "nationalId": "29106152700557", "mobile": null, "totalDeals": 1, "totalSpend": 2210000, "totalProfit": -20000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara", "segment": "Standard"}, {"id": "CUST-047", "name": "هايدي عادل جرجس", "nationalId": "27809240101828", "mobile": "01060606223", "totalDeals": 1, "totalSpend": 2170000, "totalProfit": 70000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara", "segment": "Standard"}, {"id": "CUST-048", "name": "أحمد محمود محمد توفيق", "nationalId": "2950210200518", "mobile": null, "totalDeals": 1, "totalSpend": 2250000, "totalProfit": 20000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara", "segment": "Standard"}, {"id": "CUST-049", "name": "عيسي عياد مسعود بشير", "nationalId": "27008152102758", "mobile": null, "totalDeals": 1, "totalSpend": 2930000, "totalProfit": 55000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Tayron 2026", "segment": "Standard"}, {"id": "CUST-050", "name": "باكينام شريف متولي محمد", "nationalId": "30008280104405", "mobile": null, "totalDeals": 1, "totalSpend": 1975000, "totalProfit": 125000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Cupra formintor 2026", "segment": "Standard"}, {"id": "CUST-051", "name": "مراد ياسر حسني أحمد عبد الرحمن", "nationalId": "3050319010577", "mobile": null, "totalDeals": 1, "totalSpend": 1275000, "totalProfit": 25000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Arona", "segment": "Standard"}, {"id": "CUST-052", "name": "محمد محمد السيد محمود", "nationalId": "20406050300294", "mobile": null, "totalDeals": 1, "totalSpend": 2150000, "totalProfit": 300000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Cupra formintor 2026", "segment": "Standard"}, {"id": "CUST-053", "name": "صفية أوتوموتيف", "nationalId": null, "mobile": null, "totalDeals": 1, "totalSpend": 2245000, "totalProfit": 0, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara", "segment": "Standard"}, {"id": "CUST-054", "name": "ياسمين طارق سيد يوسف", "nationalId": "28804020100289", "mobile": null, "totalDeals": 1, "totalSpend": 2300000, "totalProfit": -50000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara 2026", "segment": "Standard"}, {"id": "CUST-055", "name": "محمد السيد فيصل محمد", "nationalId": "28508050102539", "mobile": null, "totalDeals": 1, "totalSpend": 2300000, "totalProfit": -50000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara 2026", "segment": "Standard"}, {"id": "CUST-056", "name": "معرض / رضا", "nationalId": null, "mobile": null, "totalDeals": 1, "totalSpend": 2475000, "totalProfit": -25000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "curra Terrmara 2026", "segment": "Standard"}, {"id": "CUST-057", "name": "شرين عاطف فاروق طانيوس", "nationalId": "28506010102941", "mobile": null, "totalDeals": 1, "totalSpend": 1450000, "totalProfit": 50000, "firstDealDate": null, "lastDealDate": null, "modelsPurchased": "Arona", "segment": "Standard"}] ;

const SEED_PAYMENTS = [{"id": "PAY-2025-001", "year": 2025, "date": "2025-01-04", "amount": 2000000, "method": "Cash"}, {"id": "PAY-2025-002", "year": 2025, "date": "2025-01-06", "amount": 485000, "method": "Bank"}, {"id": "PAY-2025-003", "year": 2025, "date": "2025-01-14", "amount": 266000, "method": "Cash"}, {"id": "PAY-2025-004", "year": 2025, "date": "2025-01-16", "amount": 900000, "method": "Bank"}, {"id": "PAY-2025-005", "year": 2025, "date": "2025-01-28", "amount": 700000, "method": "Bank"}, {"id": "PAY-2025-006", "year": 2025, "date": "2024-01-29", "amount": 1000000, "method": "Bank"}, {"id": "PAY-2025-007", "year": 2025, "date": "2025-01-29", "amount": 550000, "method": "Cash"}, {"id": "PAY-2025-008", "year": 2025, "date": "2025-01-19", "amount": 3500000, "method": "Cash"}, {"id": "PAY-2025-009", "year": 2025, "date": "Total", "amount": 9401000, "method": null}, {"id": "PAY-2025-010", "year": 2025, "date": "2025-02-20", "amount": 1900000, "method": "Bank"}, {"id": "PAY-2025-011", "year": 2025, "date": "2025-02-22", "amount": 300000, "method": "Cash"}, {"id": "PAY-2025-012", "year": 2025, "date": "Total", "amount": 2200000, "method": null}, {"id": "PAY-2025-013", "year": 2025, "date": "2025-03-05", "amount": 1600000, "method": "Bank"}, {"id": "PAY-2025-014", "year": 2025, "date": "2025-03-11", "amount": 3100000, "method": "Bank"}, {"id": "PAY-2025-015", "year": 2025, "date": "2025-03-27", "amount": 500000, "method": "Cash"}, {"id": "PAY-2025-016", "year": 2025, "date": "Sub Total", "amount": 5200000, "method": null}, {"id": "PAY-2025-017", "year": 2025, "date": null, "amount": 5330000, "method": null}, {"id": "PAY-2025-018", "year": 2025, "date": "2025-04-22", "amount": 700000, "method": "Bank"}, {"id": "PAY-2025-019", "year": 2025, "date": "2025-04-23", "amount": 800000, "method": "Bank"}, {"id": "PAY-2025-020", "year": 2025, "date": "2025-04-29", "amount": 200000, "method": "Cash"}, {"id": "PAY-2025-021", "year": 2025, "date": "SubTotal", "amount": 1700000, "method": null}, {"id": "PAY-2025-022", "year": 2025, "date": "Total", "amount": 3037708, "method": null}, {"id": "PAY-2025-023", "year": 2025, "date": "2025-05-11", "amount": 2000000, "method": "Bank"}, {"id": "PAY-2025-024", "year": 2025, "date": "2025-05-14", "amount": 5250000, "method": "Bank"}, {"id": "PAY-2025-025", "year": 2025, "date": "2025-05-20", "amount": 1880000, "method": "Bank"}, {"id": "PAY-2025-026", "year": 2025, "date": "2025-05-25", "amount": 50000, "method": "Bank"}, {"id": "PAY-2025-027", "year": 2025, "date": "2025-05-26", "amount": 1400000, "method": "Bank"}, {"id": "PAY-2025-028", "year": 2025, "date": "2025-05-28", "amount": 190000, "method": "Bank"}, {"id": "PAY-2025-029", "year": 2025, "date": "Sub Total", "amount": 10770000, "method": null}, {"id": "PAY-2025-030", "year": 2025, "date": "Total", "amount": 12040000, "method": null}, {"id": "PAY-2025-031", "year": 2025, "date": "2025-06-04", "amount": 1254550, "method": "Cash"}, {"id": "PAY-2025-032", "year": 2025, "date": "2025-06-10", "amount": 2000000, "method": "Bank"}, {"id": "PAY-2025-033", "year": 2025, "date": "2025-06-10", "amount": 317800, "method": "Cash"}, {"id": "PAY-2025-034", "year": 2025, "date": "2025-06-12", "amount": 600000, "method": "Bank"}, {"id": "PAY-2025-035", "year": 2025, "date": "2025-06-18", "amount": 1000000, "method": "Bank"}, {"id": "PAY-2025-036", "year": 2025, "date": "2025-06-19", "amount": 140000, "method": "Cash"}, {"id": "PAY-2025-037", "year": 2025, "date": "2025-06-24", "amount": 500000, "method": "Bank"}, {"id": "PAY-2025-038", "year": 2025, "date": "2025-06-30", "amount": 1000155, "method": "Cash"}, {"id": "PAY-2025-039", "year": 2025, "date": "SubTotal", "amount": 6812505, "method": null}, {"id": "PAY-2025-040", "year": 2025, "date": "Total", "amount": 8912505, "method": null}, {"id": "PAY-2025-041", "year": 2025, "date": "2025-07-01", "amount": 600000, "method": "Bank"}, {"id": "PAY-2025-042", "year": 2025, "date": "2025-07-07", "amount": 550000, "method": "Bank"}, {"id": "PAY-2025-043", "year": 2025, "date": "2025-07-07", "amount": 900000, "method": "Bank"}, {"id": "PAY-2025-044", "year": 2025, "date": "2025-07-09", "amount": 100000, "method": "Bank"}, {"id": "PAY-2025-045", "year": 2025, "date": "2025-07-09", "amount": 200000, "method": "Cash"}, {"id": "PAY-2025-046", "year": 2025, "date": "2025-07-10", "amount": 2350000, "method": null}, {"id": "PAY-2025-047", "year": 2025, "date": "2025-07-13", "amount": 600000, "method": "Cash"}, {"id": "PAY-2025-048", "year": 2025, "date": "2025-07-15", "amount": 1000000, "method": "Bank"}, {"id": "PAY-2025-049", "year": 2025, "date": "2025-07-16", "amount": 869000, "method": "Bank"}, {"id": "PAY-2025-050", "year": 2025, "date": "2025-07-17", "amount": 500000, "method": "Bank"}, {"id": "PAY-2025-051", "year": 2025, "date": "2025-07-20", "amount": 780000, "method": "Bank"}, {"id": "PAY-2025-052", "year": 2025, "date": "2025-07-23", "amount": 940000, "method": "Cash"}, {"id": "PAY-2025-053", "year": 2025, "date": "2025-07-10", "amount": 620750, "method": null}, {"id": "PAY-2025-054", "year": 2025, "date": "Total", "amount": 10009750, "method": null}, {"id": "PAY-2025-055", "year": 2025, "date": "2025-08-06", "amount": 1400000, "method": "Bank"}, {"id": "PAY-2025-056", "year": 2025, "date": "2025-08-12", "amount": 740000, "method": "Bank"}, {"id": "PAY-2025-057", "year": 2025, "date": "/8/2025", "amount": 780000, "method": "Bank"}, {"id": "PAY-2025-058", "year": 2025, "date": "2025-08-11", "amount": 850000, "method": "Bank"}, {"id": "PAY-2025-059", "year": 2025, "date": "2025-08-11", "amount": 650000, "method": "Cash"}, {"id": "PAY-2025-060", "year": 2025, "date": "2025-08-13", "amount": 1400000, "method": "Bank"}, {"id": "PAY-2025-061", "year": 2025, "date": "2025-08-17", "amount": 1550000, "method": "Bank"}, {"id": "PAY-2025-062", "year": 2025, "date": "2025-08-26", "amount": 140000, "method": "Bank"}, {"id": "PAY-2025-063", "year": 2025, "date": "Total", "amount": 7510000, "method": null}, {"id": "PAY-2025-064", "year": 2025, "date": "2025-09-02", "amount": 1700000, "method": "Bank"}, {"id": "PAY-2025-065", "year": 2025, "date": "2025-09-15", "amount": 1670000, "method": "Bank"}, {"id": "PAY-2025-066", "year": 2025, "date": "2025-09-17", "amount": 1100000, "method": "Bank"}, {"id": "PAY-2025-067", "year": 2025, "date": "2025-09-22", "amount": 800000, "method": "Bank"}, {"id": "PAY-2025-068", "year": 2025, "date": "2025-09-22", "amount": 106500, "method": "Bank"}, {"id": "PAY-2025-069", "year": 2025, "date": "2025-09-24", "amount": 1095000, "method": "Bank"}, {"id": "PAY-2025-070", "year": 2025, "date": "2025-09-30", "amount": 160000, "method": "Cash"}, {"id": "PAY-2025-071", "year": 2025, "date": "Total", "amount": 6631500, "method": null}, {"id": "PAY-2025-072", "year": 2025, "date": "2025-10-06", "amount": 1100000, "method": "Bank"}, {"id": "PAY-2025-073", "year": 2025, "date": "2025-10-12", "amount": 1470000, "method": "Bank"}, {"id": "PAY-2025-074", "year": 2025, "date": "2025-10-28", "amount": 1465000, "method": "Bank"}, {"id": "PAY-2025-075", "year": 2025, "date": "2025-10-29", "amount": 1150000, "method": "Bank"}, {"id": "PAY-2025-076", "year": 2025, "date": "Total", "amount": 5185000, "method": null}, {"id": "PAY-2025-077", "year": 2025, "date": "2025-11-03", "amount": 200000, "method": "Cash"}, {"id": "PAY-2025-078", "year": 2025, "date": "2025-11-04", "amount": 360000, "method": "Cash"}, {"id": "PAY-2025-079", "year": 2025, "date": "2025-11-05", "amount": 800000, "method": "Bank"}, {"id": "PAY-2025-080", "year": 2025, "date": "2025-11-09", "amount": 980000, "method": "Bank"}, {"id": "PAY-2025-081", "year": 2025, "date": "2025-11-10", "amount": 90000, "method": "Cash"}, {"id": "PAY-2025-082", "year": 2025, "date": "Total", "amount": 2430000, "method": null}, {"id": "PAY-2025-083", "year": 2025, "date": "2025-12-09", "amount": 952750, "method": "Bank"}, {"id": "PAY-2025-084", "year": 2025, "date": "2025-12-16", "amount": 300000, "method": "Cash"}, {"id": "PAY-2025-085", "year": 2025, "date": "2025-12-18", "amount": 4050000, "method": "Cash"}, {"id": "PAY-2025-086", "year": 2025, "date": "2025-12-18", "amount": 700000, "method": "Bank"}, {"id": "PAY-2025-087", "year": 2025, "date": "2025-12-21", "amount": 800000, "method": "Bank"}, {"id": "PAY-2025-088", "year": 2025, "date": "2025-12-24", "amount": 1688000, "method": "Bank"}, {"id": "PAY-2025-089", "year": 2025, "date": "Total", "amount": 8490750, "method": null}, {"id": "PAY-2026-001", "year": 2026, "date": "2026-01-13", "amount": 1350000, "method": "Cash"}, {"id": "PAY-2026-002", "year": 2026, "date": "2026-01-20", "amount": 500000, "method": "Bank"}, {"id": "PAY-2026-003", "year": 2026, "date": "2026-01-31", "amount": 880000, "method": "Cash"}, {"id": "PAY-2026-004", "year": 2026, "date": null, "amount": 2730000, "method": null}, {"id": "PAY-2026-005", "year": 2026, "date": "2026-02-03", "amount": 700000, "method": "Cash"}, {"id": "PAY-2026-006", "year": 2026, "date": "2026-02-10", "amount": 3500000, "method": "Bank"}, {"id": "PAY-2026-007", "year": 2026, "date": "2026-02-10", "amount": 800000, "method": "Cash"}, {"id": "PAY-2026-008", "year": 2026, "date": "2026-02-12", "amount": 720000, "method": "Bank"}, {"id": "PAY-2026-009", "year": 2026, "date": "2026-02-12", "amount": 750000, "method": "Bank"}, {"id": "PAY-2026-010", "year": 2026, "date": "2026-02-14", "amount": 250000, "method": "Cash"}, {"id": "PAY-2026-011", "year": 2026, "date": "2026-02-16", "amount": 1000000, "method": "Bank"}, {"id": "PAY-2026-012", "year": 2026, "date": "2026-02-23", "amount": 950000, "method": "Bank"}, {"id": "PAY-2026-013", "year": 2026, "date": "2026-02-25", "amount": 362000, "method": "Bank"}, {"id": "PAY-2026-014", "year": 2026, "date": null, "amount": 9032000, "method": null}, {"id": "PAY-2026-015", "year": 2026, "date": "2025-03-03", "amount": 1100000, "method": "Cash"}, {"id": "PAY-2026-016", "year": 2026, "date": "2025-03-04", "amount": 950000, "method": "Bank"}, {"id": "PAY-2026-017", "year": 2026, "date": "2025-03-05", "amount": 1210000, "method": "Cash"}, {"id": "PAY-2026-018", "year": 2026, "date": "2026-03-09", "amount": 3300000, "method": "Bank"}, {"id": "PAY-2026-019", "year": 2026, "date": "2026-03-07", "amount": 1000000, "method": "Bank"}, {"id": "PAY-2026-020", "year": 2026, "date": "2026-03-10", "amount": 497000, "method": "Cash"}, {"id": "PAY-2026-021", "year": 2026, "date": "2026-03-10", "amount": 2000000, "method": "Bank"}, {"id": "PAY-2026-022", "year": 2026, "date": "2026-03-10", "amount": 920000, "method": "Cash"}, {"id": "PAY-2026-023", "year": 2026, "date": "2026-03-11", "amount": 3000, "method": "Bank"}, {"id": "PAY-2026-024", "year": 2026, "date": "2026-03-15", "amount": 3000000, "method": "Bank"}, {"id": "PAY-2026-025", "year": 2026, "date": "2026-03-16", "amount": 3700000, "method": null}, {"id": "PAY-2026-026", "year": 2026, "date": "2026-03-24", "amount": 650000, "method": "Bank"}, {"id": "PAY-2026-027", "year": 2026, "date": "2026-03-26", "amount": 2100000, "method": "Bank"}, {"id": "PAY-2026-028", "year": 2026, "date": "2026-03-28", "amount": 550000, "method": "Bank"}, {"id": "PAY-2026-029", "year": 2026, "date": "2026-03-28", "amount": 35000, "method": "Bank"}, {"id": "PAY-2026-030", "year": 2026, "date": "2026-03-29", "amount": 800000, "method": "Bank"}, {"id": "PAY-2026-031", "year": 2026, "date": "2026-03-30", "amount": 348600, "method": "Bank"}, {"id": "PAY-2026-032", "year": 2026, "date": "2026-03-31", "amount": 400000, "method": "Bank"}, {"id": "PAY-2026-033", "year": 2026, "date": "2026-03-31", "amount": 272000, "method": "Bank"}, {"id": "PAY-2026-034", "year": 2026, "date": null, "amount": 22835600, "method": null}, {"id": "PAY-2026-035", "year": 2026, "date": "2026-04-04", "amount": 2000000, "method": "Cash"}, {"id": "PAY-2026-036", "year": 2026, "date": "2026-04-06", "amount": 2700000, "method": "Bank"}, {"id": "PAY-2026-037", "year": 2026, "date": "2026-04-06", "amount": 1100000, "method": "Bank"}, {"id": "PAY-2026-038", "year": 2026, "date": "2026-04-07", "amount": 1300000, "method": "Cash"}, {"id": "PAY-2026-039", "year": 2026, "date": "2026-04-16", "amount": 1400000, "method": "Bank"}, {"id": "PAY-2026-040", "year": 2026, "date": "2026-04-16", "amount": 117100, "method": "Cash"}, {"id": "PAY-2026-041", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-042", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-043", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-044", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-045", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-046", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-047", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-048", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-049", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-050", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-051", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-052", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-053", "year": 2026, "date": null, "amount": 0, "method": null}, {"id": "PAY-2026-054", "year": 2026, "date": null, "amount": 8617100, "method": null}] ;

const SEED_STOCK = [{"id": "STK-AG-001", "location": "Abou Ghali", "vehicleModel": "audi Q8", "year": 2024, "color": "blue", "chassis": "11808", "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-002", "location": "Abou Ghali", "vehicleModel": "audi Q8", "year": 2024, "color": "gery", "chassis": "13062", "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-003", "location": "Abou Ghali", "vehicleModel": "mercedes G500", "year": 2023, "color": "balck", "chassis": "460014", "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-004", "location": "Abou Ghali", "vehicleModel": "mercedes Cla200", "year": 2024, "color": "white", "chassis": null, "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-005", "location": "Abou Ghali", "vehicleModel": "mercedescle200", "year": 2024, "color": "read", "chassis": "15442", "keys": 1, "comment": "صفيه  1", "status": "With Safia"}, {"id": "STK-AG-006", "location": "Abou Ghali", "vehicleModel": "porche macan", "year": 2023, "color": "balck", "chassis": "5097", "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-007", "location": "Abou Ghali", "vehicleModel": "mercedes s450", "year": 2021, "color": "black&grey", "chassis": "46120", "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-008", "location": "Abou Ghali", "vehicleModel": "pagero", "year": 2022, "color": "white", "chassis": null, "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-009", "location": "Abou Ghali", "vehicleModel": "lexus", "year": 2019, "color": "read", "chassis": null, "keys": 1, "comment": null, "status": "In Stock"}, {"id": "STK-AG-010", "location": "Abou Ghali", "vehicleModel": "Bestune", "year": 2025, "color": "white", "chassis": "7570", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-011", "location": "Abou Ghali", "vehicleModel": "Bestune", "year": 2025, "color": "white", "chassis": "7475", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-012", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2026, "color": "white", "chassis": "1017948", "keys": 2, "comment": "صفيه  1", "status": "With Safia"}, {"id": "STK-AG-013", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2026, "color": "blue", "chassis": "1013038", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-014", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2026, "color": "blue", "chassis": "1015007", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-015", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2026, "color": "blue", "chassis": "1013144", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-016", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2026, "color": "gery", "chassis": "1010073", "keys": 2, "comment": "صفيه 1", "status": "With Safia"}, {"id": "STK-AG-017", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2026, "color": "gery", "chassis": "1014173", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-018", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2025, "color": "asmanty", "chassis": "1042261", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-019", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2025, "color": "asmanty", "chassis": "1041286", "keys": 2, "comment": "صفيه 1", "status": "With Safia"}, {"id": "STK-AG-020", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2025, "color": "white", "chassis": "1043238", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-021", "location": "Abou Ghali", "vehicleModel": "CupraTermmar", "year": 2025, "color": "white", "chassis": "1043786", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-022", "location": "Abou Ghali", "vehicleModel": "volikswagen TORAG", "year": 2026, "color": "white", "chassis": "9085", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-023", "location": "Abou Ghali", "vehicleModel": "cupra leon", "year": 2026, "color": "ceramy", "chassis": "59932", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-024", "location": "Abou Ghali", "vehicleModel": "cupra leon", "year": 2026, "color": "gery", "chassis": "69453", "keys": 2, "comment": "صفيه 1", "status": "With Safia"}, {"id": "STK-AG-025", "location": "Abou Ghali", "vehicleModel": "volikswagen Tiguan", "year": 2026, "color": "white", "chassis": "561669", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-026", "location": "Abou Ghali", "vehicleModel": "volikswagen Tayron", "year": 2026, "color": "silver", "chassis": "22908", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-027", "location": "Abou Ghali", "vehicleModel": "cupra Termmar", "year": 2025, "color": "asmanty", "chassis": "1032203", "keys": 2, "comment": null, "status": "In Stock"}, {"id": "STK-AG-028", "location": "Abou Ghali", "vehicleModel": "toyota Urban cruiser", "year": 2026, "color": "silver", "chassis": "105973", "keys": 2, "comment": null, "status": "In Stock"}] ;

const SEED_MOVEMENTS = [{"id": "STK-ALL-001", "vehicleModel": "audi rs q8", "year": 2025, "color": "read", "chassis": "37939", "keys": 2, "movement": "خروج الي والي 14/2/2026", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-002", "vehicleModel": "voliks touareg", "year": 2025, "color": "gery", "chassis": "15985", "keys": 2, "movement": "14/3/2026 خورج الي والي", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-003", "vehicleModel": "audi Q8", "year": 2024, "color": "blue", "chassis": "11808", "keys": 1, "movement": null, "inDate": null, "comment": null, "status": "In Stock"}, {"id": "STK-ALL-004", "vehicleModel": "audi Q8", "year": 2024, "color": "gery", "chassis": "13062", "keys": 1, "movement": null, "inDate": null, "comment": null, "status": "In Stock"}, {"id": "STK-ALL-005", "vehicleModel": "mercedes Cla200", "year": 2024, "color": "white", "chassis": "خارج والي", "keys": 1, "movement": null, "inDate": null, "comment": null, "status": "In Stock"}, {"id": "STK-ALL-006", "vehicleModel": "mercedescle200", "year": 2024, "color": "read", "chassis": "15442", "keys": 1, "movement": "24/3خرجت الي صفيه", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-007", "vehicleModel": "mercedes G500", "year": 2023, "color": "balck", "chassis": "460014", "keys": 1, "movement": null, "inDate": null, "comment": null, "status": "In Stock"}, {"id": "STK-ALL-008", "vehicleModel": "porche macan", "year": 2023, "color": "balck", "chassis": "5097", "keys": 1, "movement": null, "inDate": null, "comment": null, "status": "In Stock"}, {"id": "STK-ALL-009", "vehicleModel": "CupraTermmar", "year": 2026, "color": "white", "chassis": "1007003", "keys": 2, "movement": "5/3/2026 خروج الي معرض ابو زيد", "inDate": null, "comment": "خرجت لصفيه بمفتاح 28/2/2026", "status": "Out / With Client"}, {"id": "STK-ALL-010", "vehicleModel": "cupra Termmar", "year": 2026, "color": "gery", "chassis": "1017433", "keys": 2, "movement": "14/3/2026 خورج الي والي", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-011", "vehicleModel": "mercede G63", "year": 2024, "color": "black", "chassis": "499553", "keys": 1, "movement": "24/2/2026خرجت لعميل/طه حسين", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-012", "vehicleModel": "cupra Termmar", "year": 2025, "color": "white", "chassis": "1041673", "keys": 2, "movement": "8/2/2026 خرجت الي والي", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-013", "vehicleModel": "cupra Termmar", "year": 2026, "color": "black", "chassis": "1009453", "keys": 2, "movement": "خرجت مع عميل 15/2/2026", "inDate": null, "comment": "اتباعت مع صفيه", "status": "Sold"}, {"id": "STK-ALL-014", "vehicleModel": "seat ataca", "year": 2025, "color": "blue", "chassis": "6512933", "keys": 2, "movement": "15/2/2026لصفيه", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-015", "vehicleModel": "toyota Urban cruiser", "year": 2026, "color": "blue", "chassis": "103527", "keys": 2, "movement": "2/3/2026خروج الي والي", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-016", "vehicleModel": "cupra Termmar", "year": 2026, "color": "gery", "chassis": "1011646", "keys": 2, "movement": "15/3/2026 خروج الي والي", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-017", "vehicleModel": "cupra Termmar", "year": 2026, "color": "petroleum", "chassis": "1010441", "keys": 2, "movement": "15/1/26خرجت لصفيه  بمفتاح", "inDate": null, "comment": "خرجت الي والي11/02/2026", "status": "Out / With Client"}, {"id": "STK-ALL-018", "vehicleModel": "seat ataca", "year": 2026, "color": "gery", "chassis": "6509703", "keys": 2, "movement": "1/2/ 2026خروج الي الغلبان", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-019", "vehicleModel": "seat ataca", "year": 2026, "color": "black", "chassis": "6509780", "keys": 2, "movement": "خروج الي القرش1/3/2026", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-020", "vehicleModel": "volikswagen Tiguan", "year": 2026, "color": "black", "chassis": "537691", "keys": 2, "movement": "خرجت /معرض طنطاوي", "inDate": null, "comment": "11/02/2026 خروج", "status": "Out / With Client"}, {"id": "STK-ALL-021", "vehicleModel": "saet leon", "year": 2026, "color": "gery", "chassis": "10676", "keys": 2, "movement": "خروج لمعرض قرار الاستلام مع امير", "inDate": null, "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-022", "vehicleModel": "CupraTermmar", "year": 2026, "color": "blue", "chassis": "1006614", "keys": 2, "movement": "6/3/خروج الي معرض وجيه والى", "inDate": null, "comment": "خروج لصفيه بمفتاح", "status": "Out / With Client"}, {"id": "STK-ALL-023", "vehicleModel": "mercedes s450", "year": 2021, "color": "black&grey", "chassis": "46120", "keys": 1, "movement": null, "inDate": null, "comment": null, "status": "In Stock"}, {"id": "STK-ALL-024", "vehicleModel": "volikswagen Tayron", "year": 2026, "color": "wihte", "chassis": "13823", "keys": 2, "movement": "5/3/2026 خروج", "inDate": "26/01/2026 دخول", "comment": "معرض عبدو البازار", "status": "Out / With Client"}, {"id": "STK-ALL-025", "vehicleModel": "seat ateca", "year": 2026, "color": "silver", "chassis": "6509731", "keys": 2, "movement": "خروج محمد نور 2/3//2026", "inDate": "13/01/2026دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-026", "vehicleModel": "seat ateca", "year": 2026, "color": "black", "chassis": "6508989", "keys": 2, "movement": "خرجت لصفيه  بمفتاح", "inDate": "13/01/2026دخول", "comment": "خرجت الي والي10/2/2026", "status": "Out / With Client"}, {"id": "STK-ALL-027", "vehicleModel": "cupra Termmar", "year": 2025, "color": "black", "chassis": "1042236", "keys": 2, "movement": "خروج عميل 5/2/2026", "inDate": "1/2/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-028", "vehicleModel": "cupraleon", "year": 2026, "color": "caremy", "chassis": "34920", "keys": 2, "movement": "خروج 1/3/2026", "inDate": "03/02/2026دخول", "comment": "الي معرض الاحمدي", "status": "Out / With Client"}, {"id": "STK-ALL-029", "vehicleModel": "seat ibiza", "year": 2026, "color": "gery", "chassis": "550525", "keys": 2, "movement": "خروج والي 17/2/2026", "inDate": "03/02/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-030", "vehicleModel": "cupra Termmar", "year": 2026, "color": "petroleum", "chassis": "1017276", "keys": 2, "movement": "الي والي", "inDate": "5/1/2026 خروج", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-031", "vehicleModel": "seat ibiza", "year": 2026, "color": "petroleum", "chassis": "551071", "keys": 2, "movement": "5/2/ خرجت لصفيه", "inDate": "05/02/2026 دخول", "comment": "خروج الي كمال موتورز 25/2/2026", "status": "Out / With Client"}, {"id": "STK-ALL-032", "vehicleModel": "seat leon", "year": 2026, "color": "white", "chassis": "37873", "keys": 2, "movement": "5/3/2026 خرجت لعميل/مايكل ممدوح", "inDate": "05/02/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-033", "vehicleModel": "seat leon", "year": 2026, "color": "gery", "chassis": "29088", "keys": 2, "movement": "5/2/ خرجت لصفيه", "inDate": "05/02/2026 دخول", "comment": "14/3/2026 خورج الي والي", "status": "Out / With Client"}, {"id": "STK-ALL-034", "vehicleModel": "cupra Termmar", "year": 2026, "color": "white", "chassis": "1041683", "keys": 2, "movement": "خرجت لعميل/نفين 10/2", "inDate": "8/2/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-035", "vehicleModel": "volikswagen Tiguan", "year": 2026, "color": "gery", "chassis": "537198", "keys": 2, "movement": "17/2خرجت لعميل/شريف", "inDate": "9/2/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-036", "vehicleModel": "CupraTermmar", "year": 2026, "color": "white", "chassis": "1017948", "keys": 2, "movement": "2/4خرجت لصفيه", "inDate": "15/02/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-037", "vehicleModel": "CupraTermmar", "year": 2026, "color": "gery", "chassis": "1017265", "keys": 2, "movement": "8/3/2026 خروج الي والي", "inDate": "15/02/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-038", "vehicleModel": "seat leon", "year": 2026, "color": "gery", "chassis": "36287", "keys": 2, "movement": "1/3/ سيد مكاوي خروج", "inDate": "15/02/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-039", "vehicleModel": "seat leon", "year": 2026, "color": "white", "chassis": "38693", "keys": 2, "movement": "16/3/2026خروج الي معرض كمال", "inDate": "15/02/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-040", "vehicleModel": "seat ibiza fr", "year": 2026, "color": "mintgaren", "chassis": "575803", "keys": 2, "movement": "4/3/2026خرجت لعميل/مدحت منير", "inDate": "22/02/2026دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-041", "vehicleModel": "seat ibiza fr", "year": 2026, "color": "petroleum", "chassis": "575012", "keys": 2, "movement": "خروج الي اكثتريم 2/3/2026", "inDate": "22/02/2026 دخول", "comment": "خرجت لصفيه  بمفتاح22/2", "status": "Out / With Client"}, {"id": "STK-ALL-042", "vehicleModel": "seat arona", "year": 2026, "color": "gery", "chassis": "572205", "keys": 2, "movement": "8/3/2026خرجت لعميل/هاني محمد", "inDate": "22/02/2026 دخول", "comment": "خرجت لصفيه بمفتاح 28/2/2026", "status": "Out / With Client"}, {"id": "STK-ALL-043", "vehicleModel": "mercede G63", "year": 2023, "color": "read", "chassis": "45564", "keys": 1, "movement": "5/4/2026خروج الي معرض/دسوقي", "inDate": "28/2/2026دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-044", "vehicleModel": "toyota Urban cruiser", "year": 2026, "color": "silver", "chassis": "105097", "keys": 2, "movement": "10/3/2026رجت لعميل/مايكل صبري", "inDate": "دخول27/02/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-045", "vehicleModel": "seat ibiza fr", "year": 2026, "color": "gery", "chassis": "572970", "keys": 2, "movement": "7/3/2026خرجت  لعميل/محمد جمال", "inDate": "02/03/2026 دخول", "comment": "خرجت لصفيه  بمفتاح2/3", "status": "Out / With Client"}, {"id": "STK-ALL-046", "vehicleModel": "volikswagen Tayron", "year": 2026, "color": "silver", "chassis": "21635", "keys": 2, "movement": "29/3/2026  خروج لعميل/عيي عياد", "inDate": "02/03/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-047", "vehicleModel": "CupraTermmar", "year": 2025, "color": "white", "chassis": "1039201", "keys": 1, "movement": "خروج الي كينج موتورز 3/3/2026", "inDate": "02/03/2026 دخول", "comment": "بمفتاح/900كيلو", "status": "Out / With Client"}, {"id": "STK-ALL-048", "vehicleModel": "seat ateca", "year": 2026, "color": "gery", "chassis": "6509997", "keys": 2, "movement": "10/3/2026خرجت لعميل/راندا بهجت", "inDate": "3/03/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-049", "vehicleModel": "seat leon", "year": 2026, "color": "bule", "chassis": "36259", "keys": 2, "movement": "1/4/2026 خروج الي معرض وجيه نجيب", "inDate": "04/03/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-050", "vehicleModel": "seat leon", "year": 2026, "color": "balck", "chassis": "38224", "keys": 2, "movement": "25/3/0026خروج الي معرض وجيه نجيب", "inDate": "04/03/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-051", "vehicleModel": "seat leon", "year": 2026, "color": "gery", "chassis": "38686", "keys": 2, "movement": "12/3/2026 خروج الي معرض بريم", "inDate": "04/03/2026 دخول", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-052", "vehicleModel": "cupra Termmar", "year": 2026, "color": "blak", "chassis": "1042335", "keys": 2, "movement": "17/3/2026خروج لعميل/هايدي", "inDate": "2026-10-03 00:00:00", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-053", "vehicleModel": "cupra Termmar", "year": 2026, "color": "blue", "chassis": "1012063", "keys": 2, "movement": "4/4/2026 خروج لعميل/سما", "inDate": "2026-10-03 00:00:00", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-054", "vehicleModel": "cupra Termmar", "year": 2026, "color": "blue", "chassis": "1017880", "keys": 2, "movement": "16/3/2026خروج لعميل /فادي", "inDate": "2026-10-03 00:00:00", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-055", "vehicleModel": "toyota Urban cruiser", "year": 2026, "color": "white", "chassis": "103754", "keys": 2, "movement": "15/03/2026 خروج الي القرش", "inDate": "2026-12-03 00:00:00", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-056", "vehicleModel": "pagero", "year": 2022, "color": "white", "chassis": null, "keys": 1, "movement": null, "inDate": "دخول من والي", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-057", "vehicleModel": "lexus", "year": 2019, "color": "read", "chassis": null, "keys": 1, "movement": null, "inDate": "دخول من والي", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-058", "vehicleModel": "seat arona", "year": 2025, "color": "balck", "chassis": "563658", "keys": 2, "movement": "29/3/2026 خروج لعميل/ياسر", "inDate": "15/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-059", "vehicleModel": "capra farmantor", "year": 2026, "color": "white", "chassis": "47163", "keys": 2, "movement": "16/3/20206خروج لعميل/باكنيام", "inDate": "16/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-060", "vehicleModel": "capra farmantor", "year": 2026, "color": "asmanty", "chassis": "49890", "keys": 2, "movement": "30/3/2026 خروج لعميل/محمد محمد", "inDate": "16/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-061", "vehicleModel": "cupra Termmar", "year": 2026, "color": "gery", "chassis": "1016761", "keys": 2, "movement": "15/3/2026خروج الي والي بمفتاح", "inDate": "17/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-062", "vehicleModel": "toyota Fortuner", "year": 2026, "color": "gery", "chassis": "309120", "keys": 2, "movement": "26/3/2026خروج ال كمال موتورز", "inDate": "17/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-063", "vehicleModel": "cupra Termmar", "year": 2025, "color": "white", "chassis": "1043786", "keys": 2, "movement": null, "inDate": "26/3/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-064", "vehicleModel": "cupra Termmar", "year": 2025, "color": "white", "chassis": "1043238", "keys": 2, "movement": null, "inDate": "26/3/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-065", "vehicleModel": "cupra Termmar", "year": 2025, "color": "white", "chassis": "1043715", "keys": 2, "movement": "خرجت لعميل 26/3خرجت لصفيه", "inDate": "26/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-066", "vehicleModel": "cupra Termmar", "year": 2025, "color": "asmanty", "chassis": "1041295", "keys": 2, "movement": "31/3/2026  خروج الي الفرج", "inDate": "26/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-067", "vehicleModel": "cupra Termmar", "year": 2025, "color": "asmanty", "chassis": "1041286", "keys": 2, "movement": "26/3خرجت لصفيه", "inDate": "26/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-068", "vehicleModel": "cupra Termmar", "year": 2025, "color": "asmanty", "chassis": "1039457", "keys": 2, "movement": "9/4/2026 خروج الي والي", "inDate": "26/3/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-069", "vehicleModel": "cupra Termmar", "year": 2026, "color": "bule", "chassis": "1015007", "keys": 2, "movement": null, "inDate": "31/3/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-070", "vehicleModel": "Bestune", "year": 2025, "color": "white", "chassis": "7570", "keys": 1, "movement": null, "inDate": "31/3/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-071", "vehicleModel": "Bestune", "year": 2025, "color": "white", "chassis": "7475", "keys": 1, "movement": null, "inDate": "31/3/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-072", "vehicleModel": "cupra Termmar", "year": 2026, "color": "blue", "chassis": "1013038", "keys": 2, "movement": null, "inDate": "2026-01-04 00:00:00", "comment": "جنط  19", "status": "In Stock"}, {"id": "STK-ALL-073", "vehicleModel": "cupra Termmar", "year": 2025, "color": "asmanty", "chassis": "1042261", "keys": 2, "movement": null, "inDate": "2026-02-04 00:00:00", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-074", "vehicleModel": "cupra Termmar", "year": 2026, "color": "gery", "chassis": "1014173", "keys": 2, "movement": null, "inDate": "2026-02-04 00:00:00", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-075", "vehicleModel": "cupra Termmar", "year": 2026, "color": "bule", "chassis": "1013144", "keys": 2, "movement": null, "inDate": "2026-04-04 00:00:00", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-076", "vehicleModel": "cupra Termmar", "year": 2026, "color": "gery", "chassis": "1010073", "keys": 2, "movement": "8/4 خرجت لصفيه", "inDate": "2026-04-04 00:00:00", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-077", "vehicleModel": "cupra Termmar", "year": 2026, "color": "bule", "chassis": "1011674", "keys": 2, "movement": "5/4/2026 خروج الي /رضا الحسيني", "inDate": "2026-05-04 00:00:00", "comment": "control", "status": "Out / With Client"}, {"id": "STK-ALL-078", "vehicleModel": "volikswagen TORAG", "year": 2026, "color": "white", "chassis": "9085", "keys": 2, "movement": null, "inDate": "2026-07-04 00:00:00", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-079", "vehicleModel": "seat ataca", "year": 2026, "color": "gery", "chassis": "6509862", "keys": 2, "movement": "14/4خروج الي /الوطنيه", "inDate": "2026-07-04 00:00:00", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-080", "vehicleModel": "seat arona", "year": 2026, "color": "gery", "chassis": "587779", "keys": 2, "movement": "14/4خروج الي العميل/شيرين", "inDate": "14/4/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-081", "vehicleModel": "cupra leon", "year": 2026, "color": "ceramy", "chassis": "59932", "keys": 2, "movement": null, "inDate": "16/4/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-082", "vehicleModel": "cupra leon", "year": 2026, "color": "gery", "chassis": "69453", "keys": 2, "movement": "17/4صفيه 1", "inDate": "16/4/2026", "comment": null, "status": "Out / With Client"}, {"id": "STK-ALL-083", "vehicleModel": "volikswagen Tiguan", "year": 2026, "color": "white", "chassis": "561669", "keys": 2, "movement": null, "inDate": "16/4/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-084", "vehicleModel": "volikswagen Tayron", "year": 2026, "color": "silver", "chassis": "22908", "keys": 2, "movement": null, "inDate": "16/4/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-085", "vehicleModel": "cupra Termmar", "year": 2025, "color": "asmanty", "chassis": "1032203", "keys": 2, "movement": null, "inDate": "16/4/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-086", "vehicleModel": "toyota Urban cruiser", "year": 2026, "color": "silver", "chassis": "105973", "keys": 2, "movement": null, "inDate": "17/4/2026", "comment": null, "status": "In Stock"}, {"id": "STK-ALL-087", "vehicleModel": "seat leon", "year": 2026, "color": "gery", "chassis": "69302", "keys": 2, "movement": null, "inDate": "18/4/2026", "comment": "يوجد خربوش باب اليمين", "status": "In Stock"}] ;

const SEED_MONTHLY = [{"month": "January", "y2025": 9401000, "y2026": 2730000}, {"month": "february", "y2025": 2200000, "y2026": 9032000}, {"month": "March", "y2025": 5330000, "y2026": 22835600}, {"month": "April", "y2025": 3037708, "y2026": 8617100}, {"month": "May", "y2025": 12040000, "y2026": 0}, {"month": "June", "y2025": 8912505, "y2026": 0}, {"month": "July", "y2025": 10009750, "y2026": 0}, {"month": "August", "y2025": 7510000, "y2026": 0}, {"month": "Sep", "y2025": 6631500, "y2026": 0}, {"month": "Oct", "y2025": 5185000, "y2026": 0}, {"month": "Nov", "y2025": 2430000, "y2026": 0}, {"month": "Dec", "y2025": 8490750, "y2026": 0}] ;

const SEED_PIPELINE = [{"id": "PIPE-001", "customerName": "—", "mobile": "—", "vehicleModel": "Cupra Terrmara 2026", "color": "Grey", "price": 2300000, "stage": "Negotiation", "assignedTo": "Jean/Yasmine", "followUpDate": "2026-04-25", "notes": "Called twice, interested"}, {"id": "PIPE-002", "customerName": "—", "mobile": "—", "vehicleModel": "Audi Q5", "color": "White", "price": 4500000, "stage": "Lead", "assignedTo": "Ahmed Mohsen", "followUpDate": "2026-04-28", "notes": "New lead from referral"}, {"id": "PIPE-003", "customerName": "—", "mobile": "—", "vehicleModel": "Seat Leon 2026", "color": "Black", "price": 1600000, "stage": "Pending Delivery", "assignedTo": "Jean/Yasmine", "followUpDate": "2026-04-22", "notes": "Payment done, awaiting car"}] ;

// ==================== NORMALISATION ====================
// Pipeline stage strings in the source ("Lead", "Negotiation", "Pending Delivery")
// get normalised to stable codes.
const STAGE_MAP = { 'Lead':'lead', 'Negotiation':'negotiation', 'Pending Delivery':'pending_delivery' };
const STAGES = ['lead','negotiation','pending_delivery','converted','lost'];
const STAGE_LABELS = {
  lead: 'stg_lead', negotiation: 'stg_negotiation',
  pending_delivery: 'stg_pending_delivery', converted: 'stg_converted', lost: 'stg_lost'
};
const STAGE_COLORS = { lead:'#378ADD', negotiation:'#BA7517', pending_delivery:'#534AB7', converted:'#1D9E75', lost:'#A32D2D' };

const STATUS_MAP = {
  'In Stock':'in_stock', 'With Safia':'with_safia',
  'Out / With Client':'out_with_client', 'Sold':'sold', 'Reserved':'reserved'
};
const STATUS_LABELS = {
  in_stock: 'stk_in_stock', with_safia: 'stk_with_safia',
  out_with_client: 'stk_out_client', sold: 'stk_sold', reserved: 'stk_reserved'
};

const METHOD_MAP = { 'Cash':'cash', 'Bank':'bank', null:'unknown', undefined:'unknown' };
const METHOD_LABELS = { cash:'method_cash', bank:'method_bank', unknown:'method_unknown' };

// Assign ownership based on shares (matches existing partner split)
function assignedFromShares(deal) {
  if (Math.abs(deal.jeanYasmineShare || 0) > 0) return 'u1';
  if (Math.abs(deal.ahmedMohsenShare || 0) > 0) return 'u2';
  return 'u3';
}

// Seed the initial state — turn flat seed into enriched shape
function buildInitialState() {
  const deals = SEED_DEALS.map(d => ({
    ...d,
    deliveryStatus: d.deliveryStatus === 'تم التسليم' ? 'delivered' : 'pending',
    assignedTo: assignedFromShares(d),
    customerId: null, // backfilled below
    linkedStockId: null,
    attachments: [],
  }));
  // Backfill customerId
  const custByName = Object.fromEntries(SEED_CUSTOMERS.map(c => [c.name, c.id]));
  deals.forEach(d => { d.customerId = custByName[d.customerName] || null; });

  const customers = SEED_CUSTOMERS.map(c => ({
    ...c,
    segment: c.totalDeals > 1 ? 'repeat' : (c.segment || 'Standard').toLowerCase(),
    attachments: [],
  }));

  const payments = SEED_PAYMENTS.map(p => ({
    ...p,
    method: METHOD_MAP[p.method] || 'unknown',
    dealId: null,
    attachments: [],
  }));

  const stock = SEED_STOCK.map(s => ({
    ...s,
    status: STATUS_MAP[s.status] || 'in_stock',
    attachments: [],
  }));

  const movements = SEED_MOVEMENTS.map(m => ({
    ...m,
    status: STATUS_MAP[m.status] || 'in_stock',
    direction: (m.movement && /خروج|خورج/.test(m.movement)) ? 'out' : 'in',
  }));

  const leads = SEED_PIPELINE.map(p => ({
    id: p.id,
    customerName: p.customerName === '—' ? '' : p.customerName,
    mobile: p.mobile === '—' ? '' : p.mobile,
    vehicleModel: p.vehicleModel,
    color: p.color,
    price: p.price,
    stage: STAGE_MAP[p.stage] || 'lead',
    assignedTo: p.assignedTo === 'Jean/Yasmine' ? 'u1' : p.assignedTo === 'Ahmed Mohsen' ? 'u2' : 'u3',
    followUpDate: p.followUpDate,
    notes: p.notes || '',
    createdAt: new Date().toISOString().slice(0, 10),
    attachments: [],
    convertedDealId: null,
    convertedCustomerId: null,
  }));

  return { deals, customers, payments, stock, movements, monthly: [...SEED_MONTHLY], leads };
}

// ==================== REACT PRIMITIVES ====================

function Badge({ kind = 'none', children }) {
  const cls = { done: 'b-done', wait: 'b-wait', cancel: 'b-cancel', info: 'b-info', none: 'b-none' }[kind] || 'b-none';
  return <span className={`badge ${cls}`}>{children}</span>;
}

function StatusBadge({ status, t }) {
  if (status === 'delivered' || status === 'sold' || status === 'converted') return <Badge kind="done">{t(status === 'delivered' ? 'delivered' : status === 'converted' ? 'stg_converted' : 'stk_sold')}</Badge>;
  if (status === 'pending' || status === 'in_stock') return <Badge kind="info">{t(status === 'pending' ? 'pending' : 'stk_in_stock')}</Badge>;
  if (status === 'with_safia') return <Badge kind="wait">{t('stk_with_safia')}</Badge>;
  if (status === 'out_with_client') return <Badge kind="info">{t('stk_out_client')}</Badge>;
  if (status === 'reserved') return <Badge kind="wait">{t('stk_reserved')}</Badge>;
  if (status === 'lost') return <Badge kind="cancel">{t('stg_lost')}</Badge>;
  return <Badge kind="none">{status}</Badge>;
}

function StageBadge({ stage, t }) {
  const color = STAGE_COLORS[stage];
  return <span className="badge" style={{ background: color + '22', color, fontWeight: 500 }}>{t(STAGE_LABELS[stage] || 'stg_lead')}</span>;
}

function Modal({ open, onClose, title, children, footer, wide, locale }) {
  if (!open) return null;
  return (
    <div className="modal-wrap" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={'modal' + (wide ? ' wide' : '')} dir={locale === 'ar' ? 'rtl' : 'ltr'}>
        {title && <h3>{title}</h3>}
        <div>{children}</div>
        {footer && <div className="modal-btn-row">{footer}</div>}
      </div>
    </div>
  );
}

function Dropdown({ button, children, end }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);
  return (
    <div className="dropdown" ref={ref}>
      <span onClick={() => setOpen(v => !v)}>{button}</span>
      {open && <div className={'dd-menu' + (end ? ' end' : '')}>{React.Children.map(children, c => c && React.cloneElement(c, { onClick: (e) => { c.props.onClick && c.props.onClick(e); setOpen(false); } }))}</div>}
    </div>
  );
}

function Tabs({ value, onChange, tabs }) {
  return (
    <div className="tabs">
      {tabs.map(tb => (
        <button key={tb.value} className={'tab' + (value === tb.value ? ' active' : '')} onClick={() => onChange(tb.value)}>
          {tb.label}
        </button>
      ))}
    </div>
  );
}

// ==================== ATTACHMENTS COMPONENT ====================
function Attachments({ items = [], onChange, t, locale, currentUser }) {
  const [over, setOver] = useState(false);
  const inputRef = useRef(null);

  async function handleFiles(files) {
    const add = [];
    for (const f of files) {
      if (f.size > 10 * 1024 * 1024) {
        alert((locale === 'ar' ? 'الملف أكبر من ١٠ ميجا: ' : 'File exceeds 10 MB: ') + f.name);
        continue;
      }
      const dataUrl = await readFileAsDataURL(f);
      add.push({
        id: uid('att'),
        filename: f.name,
        mimeType: f.type || 'application/octet-stream',
        size: f.size,
        dataUrl,
        uploadedBy: currentUser.name,
        uploadedAt: new Date().toISOString(),
      });
    }
    onChange([...items, ...add]);
  }

  const fmtSize = (n) => n < 1024 ? n + ' B' : n < 1024*1024 ? (n/1024).toFixed(1) + ' KB' : (n/1024/1024).toFixed(1) + ' MB';

  return (
    <div>
      <div
        className={'dropzone' + (over ? ' over' : '')}
        onClick={() => inputRef.current && inputRef.current.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); handleFiles(Array.from(e.dataTransfer.files)); }}
      >
        <Paperclip size={16} style={{ display: 'inline', verticalAlign: 'middle', marginInlineEnd: 6, opacity: 0.6 }} />
        <div style={{ fontWeight: 500, marginTop: 4 }}>{t('drop_or_click')}</div>
        <div style={{ fontSize: 11, marginTop: 3, color: 'var(--color-text-tertiary)' }}>{t('any_format')}</div>
        <input ref={inputRef} type="file" multiple style={{ display: 'none' }} onChange={(e) => handleFiles(Array.from(e.target.files || []))} />
      </div>
      {items.length > 0 ? (
        <div className="attach-list">
          {items.map(a => (
            <div key={a.id} className="attach-item">
              <Paperclip size={13} style={{ color: 'var(--color-text-secondary)' }} />
              <span className="fn" title={a.filename}>{a.filename}</span>
              <span className="sz">{fmtSize(a.size)}</span>
              <a href={a.dataUrl} download={a.filename} title={t('download')}>
                <button><Download size={13} /></button>
              </a>
              <button onClick={() => onChange(items.filter(x => x.id !== a.id))} title={t('remove')}>
                <X size={13} />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ textAlign: 'center', padding: '14px 0', fontSize: 12, color: 'var(--color-text-tertiary)' }}>{t('no_attachments')}</div>
      )}
    </div>
  );
}

// ==================== SIDEBAR ====================
function Sidebar({ module, setModule, state, t, locale, currentUser }) {
  const allItems = [
    { k: 'dashboard', icon: LayoutDashboard, count: null },
    { k: 'deals', icon: Handshake, count: state.deals.length },
    { k: 'customers', icon: Users, count: state.customers.length },
    { k: 'pipeline', icon: GitBranch, count: state.leads.filter(l => l.stage !== 'converted' && l.stage !== 'lost').length },
    { k: 'stock', icon: Car, count: state.stock.length },
    { k: 'movements', icon: Repeat, count: state.movements.length },
    { k: 'payments', icon: Wallet, count: state.payments.length },
    { k: 'partners', icon: UserCircle2, count: null },
    { k: 'reports', icon: BarChart3, count: null },
  ];
  const items = allItems.filter(it => canAccess(currentUser, it.k));
  return (
    <aside className="sidebar">
      <div className="brand-block">
        <div className="brand-name">{t('brand')}</div>
        <div className="brand-sub">{t('tagline')}</div>
      </div>
      <nav>
        {items.map(it => {
          const Icon = it.icon;
          return (
            <button key={it.k} className={'nav-item' + (module === it.k ? ' active' : '')} onClick={() => setModule(it.k)}>
              <Icon />
              <span>{t(it.k)}</span>
              {it.count != null && <span className="nav-badge">{fmtNumber(it.count, locale === 'ar')}</span>}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}

// ==================== TOPBAR ====================
function TopBar({ state, t, locale, setLocale, useArNum, setUseArNum, onGlobalOpen, setModule, setDetail, currentUser, onSignOut }) {
  const [q, setQ] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [quickOpen, setQuickOpen] = useState(null);
  const boxRef = useRef(null);

  useEffect(() => {
    if (!showResults) return;
    const h = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setShowResults(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [showResults]);

  const results = useMemo(() => {
    const qs = q.trim().toLowerCase();
    if (!qs) return null;
    const hits = { deals: [], customers: [], stock: [], leads: [] };
    const match = (s) => s && String(s).toLowerCase().includes(qs);
    state.deals.forEach(d => { if (match(d.customerName) || match(d.vehicleModel) || match(d.chassis) || match(d.mobile) || match(d.id)) hits.deals.push(d); });
    state.customers.forEach(c => { if (match(c.name) || match(c.mobile) || match(c.nationalId) || match(c.id)) hits.customers.push(c); });
    state.stock.forEach(s => { if (match(s.vehicleModel) || match(s.chassis) || match(s.color) || match(s.id)) hits.stock.push(s); });
    state.leads.forEach(l => { if (match(l.customerName) || match(l.vehicleModel) || match(l.id)) hits.leads.push(l); });
    Object.keys(hits).forEach(k => hits[k] = hits[k].slice(0, 5));
    return hits;
  }, [q, state]);

  return (
    <div className="topbar">
      <div className="search-box" ref={boxRef}>
        <Search />
        <input
          type="text"
          placeholder={t('search_placeholder')}
          value={q}
          onChange={(e) => { setQ(e.target.value); setShowResults(true); }}
          onFocus={() => setShowResults(true)}
        />
        {showResults && results && (results.deals.length + results.customers.length + results.stock.length + results.leads.length > 0) && (
          <div className="search-results">
            {results.deals.length > 0 && <>
              <div className="sr-group">{t('deals')}</div>
              {results.deals.map(d => (
                <div key={d.id} className="sr-item" onClick={() => { setModule('deals'); setDetail({ type:'deal', id:d.id }); setShowResults(false); setQ(''); }}>
                  <span><b>{d.customerName}</b> <span className="sub">· {d.vehicleModel}</span></span>
                  <span className="sub">{d.id}</span>
                </div>
              ))}
            </>}
            {results.customers.length > 0 && <>
              <div className="sr-group">{t('customers')}</div>
              {results.customers.map(c => (
                <div key={c.id} className="sr-item" onClick={() => { setModule('customers'); setDetail({ type:'customer', id:c.id }); setShowResults(false); setQ(''); }}>
                  <span><b>{c.name}</b> <span className="sub">· {c.mobile || '—'}</span></span>
                  <span className="sub">{c.id}</span>
                </div>
              ))}
            </>}
            {results.stock.length > 0 && <>
              <div className="sr-group">{t('stock')}</div>
              {results.stock.map(s => (
                <div key={s.id} className="sr-item" onClick={() => { setModule('stock'); setDetail({ type:'stock', id:s.id }); setShowResults(false); setQ(''); }}>
                  <span><b>{s.vehicleModel}</b> <span className="sub">· {s.color} · {s.chassis}</span></span>
                  <span className="sub">{s.id}</span>
                </div>
              ))}
            </>}
            {results.leads.length > 0 && <>
              <div className="sr-group">{t('pipeline')}</div>
              {results.leads.map(l => (
                <div key={l.id} className="sr-item" onClick={() => { setModule('pipeline'); setDetail({ type:'lead', id:l.id }); setShowResults(false); setQ(''); }}>
                  <span><b>{l.customerName || l.vehicleModel}</b> <span className="sub">· {l.vehicleModel}</span></span>
                  <span className="sub">{l.id}</span>
                </div>
              ))}
            </>}
          </div>
        )}
      </div>

      <div className="topbar-actions">
        <Dropdown end button={<button className="btn prim"><Plus size={14} /> {t('new')}</button>}>
          {canAccess(currentUser, 'deals')     && <button className="dd-item" onClick={() => onGlobalOpen('deal')}><Handshake size={14} /> {t('deals')}</button>}
          {canAccess(currentUser, 'customers') && <button className="dd-item" onClick={() => onGlobalOpen('customer')}><Users size={14} /> {t('customers')}</button>}
          {canAccess(currentUser, 'pipeline')  && <button className="dd-item" onClick={() => onGlobalOpen('lead')}><UserPlus size={14} /> {t('pipeline')}</button>}
          {canAccess(currentUser, 'stock')     && <button className="dd-item" onClick={() => onGlobalOpen('stock')}><Car size={14} /> {t('stock')}</button>}
          {canAccess(currentUser, 'payments')  && <button className="dd-item" onClick={() => onGlobalOpen('payment')}><Wallet size={14} /> {t('payments')}</button>}
        </Dropdown>

        <Dropdown end button={<button className="icon-btn" title={t('language')}><Globe size={15} /></button>}>
          <button className="dd-item" onClick={() => setLocale('ar')}>{locale === 'ar' ? '✓ ' : ''}عربي</button>
          <button className="dd-item" onClick={() => setLocale('en')}>{locale === 'en' ? '✓ ' : ''}English</button>
          <div style={{ borderTop: '0.5px solid var(--color-border-tertiary)', margin: '4px 0' }} />
          <button className="dd-item" onClick={() => setUseArNum(true)}>{useArNum ? '✓ ' : ''}{t('numerals_ar')}</button>
          <button className="dd-item" onClick={() => setUseArNum(false)}>{!useArNum ? '✓ ' : ''}{t('numerals_en')}</button>
        </Dropdown>

        {currentUser && (
          <Dropdown end button={
            <button className="user-pill" title={t('signed_in_as')}>
              <span className="user-avatar">{(locale === 'ar' ? currentUser.nameAr : currentUser.name).charAt(0)}</span>
              <span className="user-meta">
                <span className="user-name">{locale === 'ar' ? currentUser.nameAr : currentUser.name}</span>
                <span className="user-role">{t('role_' + currentUser.role)}</span>
              </span>
              <ChevronDown size={13} />
            </button>
          }>
            <div className="dd-header">
              <div className="dd-header-name">{locale === 'ar' ? currentUser.nameAr : currentUser.name}</div>
              <div className="dd-header-sub">{t('role_' + currentUser.role)}</div>
            </div>
            <div style={{ borderTop: '0.5px solid var(--color-border-tertiary)', margin: '4px 0' }} />
            <button className="dd-item" onClick={onSignOut}><X size={14} /> {t('sign_out')}</button>
          </Dropdown>
        )}
      </div>
    </div>
  );
}

// ==================== DASHBOARD ====================
function Dashboard({ state, t, locale, useArNum, setModule, setDetail }) {
  const deals = state.deals;
  const delivered = deals.filter(d => d.deliveryStatus === 'delivered');
  const pending = deals.filter(d => d.deliveryStatus === 'pending');
  const totalProfit = deals.reduce((a, d) => a + d.profit, 0);
  const y25 = state.monthly.reduce((a, m) => a + m.y2025, 0);
  const y26 = state.monthly.reduce((a, m) => a + m.y2026, 0);
  const jyShare = deals.reduce((a, d) => a + d.jeanYasmineShare, 0);
  const amShare = deals.reduce((a, d) => a + d.ahmedMohsenShare, 0);
  const avgProfit = deals.length ? totalProfit / deals.length : 0;
  const stockUnits = state.stock.length;
  const pipelineValue = state.leads.filter(l => l.stage !== 'converted' && l.stage !== 'lost').reduce((a, l) => a + l.price, 0);

  // monthly chart data (merge 2025 vs 2026)
  const monthlyData = state.monthly.map(m => ({
    month: m.month.slice(0, 3),
    '2025': m.y2025, '2026': m.y2026,
  }));

  // profit by model
  const byModel = {};
  deals.forEach(d => {
    const k = d.vehicleModel;
    if (!byModel[k]) byModel[k] = { count: 0, profit: 0, revenue: 0 };
    byModel[k].count++;
    byModel[k].profit += d.profit;
    byModel[k].revenue += d.salePrice;
  });
  const sortedModels = Object.entries(byModel).sort((a, b) => b[1].profit - a[1].profit).slice(0, 8);
  const maxProfit = sortedModels[0]?.[1].profit || 1;

  // pipeline by stage
  const pipelineData = STAGES.filter(s => s !== 'converted' && s !== 'lost').map(s => ({
    stage: t(STAGE_LABELS[s]),
    count: state.leads.filter(l => l.stage === s).length,
    value: state.leads.filter(l => l.stage === s).reduce((a, l) => a + l.price, 0),
    color: STAGE_COLORS[s],
  }));

  const recentDeals = [...deals].filter(d => d.date).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  const topCustomers = [...state.customers].sort((a, b) => b.totalSpend - a.totalSpend).slice(0, 6);

  // alerts
  const alerts = [];
  const withSafia = state.stock.filter(s => s.status === 'with_safia').length;
  if (withSafia > 0) alerts.push({ kind: 'warn', msg: `${fmtNumber(withSafia, useArNum)} ${locale==='ar' ? 'سيارات مع صفية — يُرجى المتابعة' : 'vehicles held with Safia — please follow up'}` });
  const lossDeals = deals.filter(d => d.profit < 0).length;
  if (lossDeals > 0) alerts.push({ kind: 'danger', msg: `${fmtNumber(lossDeals, useArNum)} ${locale==='ar' ? 'صفقات خاسرة — مراجعة التسعير' : 'loss-making deals — review pricing'}` });
  const pendingOver = pending.length;
  if (pendingOver > 0) alerts.push({ kind: 'info', msg: `${fmtNumber(pendingOver, useArNum)} ${locale==='ar' ? 'صفقات بانتظار التسليم' : 'deals still awaiting delivery'}` });

  const yoyDelta = y25 > 0 ? ((y26 - y25) / y25) * 100 : 0;

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('dashboard')}</div>
          <div className="page-sub">{t('overview_tab')} · {t('live')}</div>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi"><div className="kpi-label">{t('kpi_deals_closed')}</div><div className="kpi-val">{fmtNumber(deals.length, useArNum)}</div><div className="kpi-sub">{fmtNumber(delivered.length, useArNum)} {t('delivered')}</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_customers')}</div><div className="kpi-val">{fmtNumber(state.customers.length, useArNum)}</div><div className="kpi-sub">{fmtNumber(state.customers.filter(c => c.totalDeals > 1).length, useArNum)} {locale==='ar' ? 'عميل متكرر' : 'repeat'}</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_collections_2026')}</div><div className="kpi-val sm success">{fmtCurrencyShort(y26, useArNum)}</div><div className="kpi-sub"><span className={'kpi-delta ' + (yoyDelta >= 0 ? 'up' : 'down')}>{yoyDelta >= 0 ? <ArrowUpRight size={11}/> : <ArrowDownRight size={11}/>} {fmtNumber(Math.abs(yoyDelta).toFixed(1), useArNum)}%</span> {t('vs')} 2025</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_collections_2025')}</div><div className="kpi-val sm">{fmtCurrencyShort(y25, useArNum)}</div><div className="kpi-sub">{fmtNumber(state.payments.filter(p => p.year === 2025).length, useArNum)} {locale==='ar' ? 'دفعة' : 'entries'}</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_total_profit')}</div><div className="kpi-val sm success">{fmtCurrencyShort(totalProfit, useArNum)}</div><div className="kpi-sub">{t('kpi_avg_profit')}: {fmtCurrencyShort(avgProfit, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_partner_shares')}</div><div className="kpi-val sm">{fmtCurrencyShort(jyShare + amShare, useArNum)}</div><div className="kpi-sub">J/Y {fmtCurrencyShort(jyShare, useArNum)} · A.M {fmtCurrencyShort(amShare, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_stock_units')}</div><div className="kpi-val">{fmtNumber(stockUnits, useArNum)}</div><div className="kpi-sub">{fmtNumber(state.stock.filter(s => s.status === 'in_stock').length, useArNum)} {t('stk_in_stock')}</div></div>
        <div className="kpi"><div className="kpi-label">{t('kpi_pipeline_value')}</div><div className="kpi-val sm info">{fmtCurrencyShort(pipelineValue, useArNum)}</div><div className="kpi-sub">{fmtNumber(state.leads.length, useArNum)} {locale==='ar' ? 'فرصة' : 'leads'}</div></div>
      </div>

      {alerts.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          {alerts.map((a, i) => (
            <div key={i} className={'alert alert-' + a.kind}>
              <AlertCircle size={16} style={{ flexShrink: 0, marginTop: 2 }} />
              <div><b>{locale === 'ar' ? 'تنبيه.' : 'Alert.'}</b> {a.msg}</div>
            </div>
          ))}
        </div>
      )}

      <div className="two-col">
        <div className="card">
          <div className="section-hd">
            <div>
              <div className="section-title">{t('collections_compare')}</div>
              <div className="section-sub">{locale === 'ar' ? 'شهر بشهر ٢٠٢٥ مقابل ٢٠٢٦' : 'Month-by-month, 2025 vs 2026'}</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border-tertiary)" />
              <XAxis dataKey="month" stroke="var(--color-text-secondary)" fontSize={11} />
              <YAxis stroke="var(--color-text-secondary)" fontSize={11} tickFormatter={(v) => (v >= 1e6 ? (v/1e6).toFixed(0)+'M' : v >= 1e3 ? (v/1e3).toFixed(0)+'K' : v)} />
              <Tooltip contentStyle={{ background: 'var(--color-background-primary)', border: '0.5px solid var(--color-border-tertiary)', borderRadius: 8, fontSize: 12 }} formatter={(v) => fmtCurrency(v, useArNum)} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="2025" fill="#BA7517" radius={[3, 3, 0, 0]} />
              <Bar dataKey="2026" fill="#1D9E75" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="section-hd">
            <div>
              <div className="section-title">{t('pipeline_by_stage')}</div>
              <div className="section-sub">{t('kpi_pipeline_value')}</div>
            </div>
            <button className="btn sm" onClick={() => setModule('pipeline')}>{t('view')} →</button>
          </div>
          <div>
            {pipelineData.map(p => (
              <div key={p.stage} className="bar-row">
                <div className="bar-label">{p.stage}</div>
                <div className="bar-track"><div className="bar-fill" style={{ width: (p.count / Math.max(1, ...pipelineData.map(x => x.count)) * 100) + '%', background: p.color }} /></div>
                <div className="bar-val">{fmtNumber(p.count, useArNum)} · {fmtCurrencyShort(p.value, useArNum)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-hd">
          <div className="section-title">{t('profit_by_model')}</div>
          <div className="section-sub">{locale === 'ar' ? 'أفضل ٨ موديلات' : 'Top 8 models'}</div>
        </div>
        <div className="card">
          {sortedModels.map(([name, d]) => (
            <div key={name} className="bar-row">
              <div className="bar-label" title={name}>{name}</div>
              <div className="bar-track"><div className="bar-fill" style={{ width: (Math.max(0, d.profit) / maxProfit * 100) + '%', background: d.profit < 0 ? '#A32D2D' : '#534AB7' }} /></div>
              <div className="bar-val">{fmtCurrencyShort(d.profit, useArNum)} <span style={{ color: 'var(--color-text-tertiary)', fontWeight: 400 }}>· {fmtNumber(d.count, useArNum)}</span></div>
            </div>
          ))}
        </div>
      </div>

      <div className="two-col section">
        <div>
          <div className="section-hd"><div className="section-title">{t('recent_deals')}</div><button className="btn sm" onClick={() => setModule('deals')}>{t('view')} →</button></div>
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr><th>{t('customer_name')}</th><th>{t('vehicle_model')}</th><th className="r">{t('sale_price')}</th><th>{t('status')}</th></tr></thead>
              <tbody>
                {recentDeals.map(d => (
                  <tr key={d.id} className="clickable" onClick={() => { setModule('deals'); setDetail({ type: 'deal', id: d.id }); }}>
                    <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.customerName}</td>
                    <td>{d.vehicleModel}</td>
                    <td className="r"><b>{fmtCurrencyShort(d.salePrice, useArNum)}</b></td>
                    <td><StatusBadge status={d.deliveryStatus} t={t} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <div className="section-hd"><div className="section-title">{t('top_customers')}</div><button className="btn sm" onClick={() => setModule('customers')}>{t('view')} →</button></div>
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr><th>{t('customer_name')}</th><th className="r">{t('total_deals')}</th><th className="r">{t('total_spend')}</th></tr></thead>
              <tbody>
                {topCustomers.map(c => (
                  <tr key={c.id} className="clickable" onClick={() => { setModule('customers'); setDetail({ type: 'customer', id: c.id }); }}>
                    <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</td>
                    <td className="r">{fmtNumber(c.totalDeals, useArNum)}</td>
                    <td className="r"><b>{fmtCurrencyShort(c.totalSpend, useArNum)}</b></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}

// ==================== DEALS MODULE ====================
function DealsList({ state, t, locale, useArNum, setDetail, onNew }) {
  const [q, setQ] = useState('');
  const [year, setYear] = useState('');
  const [status, setStatus] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [sortDir, setSortDir] = useState('desc');

  const rows = useMemo(() => {
    const qs = q.trim().toLowerCase();
    let r = state.deals.filter(d => {
      const hit = !qs || [d.customerName, d.vehicleModel, d.chassis, d.mobile, d.id, d.color].some(f => f && String(f).toLowerCase().includes(qs));
      const yr = !year || String(d.year) === year;
      const st = !status || d.deliveryStatus === status;
      return hit && yr && st;
    });
    r.sort((a, b) => {
      const va = a[sortBy] ?? '', vb = b[sortBy] ?? '';
      if (typeof va === 'number') return sortDir === 'asc' ? va - vb : vb - va;
      return sortDir === 'asc' ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
    });
    return r;
  }, [state.deals, q, year, status, sortBy, sortDir]);

  const toggleSort = (col) => {
    if (sortBy === col) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortBy(col); setSortDir('desc'); }
  };

  const years = [...new Set(state.deals.map(d => d.year))].sort();

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('deals')}</div>
          <div className="page-sub">{fmtNumber(rows.length, useArNum)} {t('of')} {fmtNumber(state.deals.length, useArNum)} {t('records')}</div>
        </div>
        <button className="btn prim" onClick={onNew}><Plus size={14} /> {t('new')}</button>
      </div>
      <div className="controls">
        <input type="text" placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={year} onChange={(e) => setYear(e.target.value)}>
          <option value="">{t('all_years')}</option>
          {years.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">{t('all_statuses')}</option>
          <option value="delivered">{t('delivered')}</option>
          <option value="pending">{t('pending')}</option>
        </select>
      </div>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('id')}>{t('deal_id')}</th>
              <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('date')}>{t('date')}</th>
              <th>{t('customer_name')}</th>
              <th>{t('vehicle_model')}</th>
              <th>{t('color')}</th>
              <th>{t('chassis')}</th>
              <th className="r" style={{ cursor: 'pointer' }} onClick={() => toggleSort('salePrice')}>{t('sale_price')}</th>
              <th className="r" style={{ cursor: 'pointer' }} onClick={() => toggleSort('profit')}>{t('profit')}</th>
              <th>{t('status')}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(d => (
              <tr key={d.id} className="clickable" onClick={() => setDetail({ type: 'deal', id: d.id })}>
                <td className="mono nowrap">{d.id}</td>
                <td className="nowrap">{fmtDate(d.date, locale, useArNum)}</td>
                <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={d.customerName}>{d.customerName}</td>
                <td className="nowrap">{d.vehicleModel}</td>
                <td className="nowrap"><span className="color-dot" style={{ background: colorSwatch(d.color), display: 'inline-block', marginInlineEnd: 6, verticalAlign: 'middle' }}></span>{d.color}</td>
                <td className="mono nowrap">{d.chassis || '—'}</td>
                <td className="r nowrap"><b>{fmtCurrencyShort(d.salePrice, useArNum)}</b></td>
                <td className="r nowrap" style={{ color: d.profit < 0 ? 'var(--color-text-danger)' : d.profit > 0 ? 'var(--color-text-success)' : 'var(--color-text-secondary)' }}>{fmtCurrencyShort(d.profit, useArNum)}</td>
                <td><StatusBadge status={d.deliveryStatus} t={t} /></td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={9} className="empty">{t('no_results')}</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function DealDetail({ deal, state, t, locale, useArNum, onEdit, onDelete, onPrint, onBack, onAttachmentsChange, currentUser, setDetail }) {
  const [tab, setTab] = useState('details');
  const customer = state.customers.find(c => c.id === deal.customerId);
  const assigned = SEED_USERS.find(u => u.id === deal.assignedTo);
  const stockItem = state.stock.find(s => s.chassis === deal.chassis) || state.movements.find(m => m.chassis === deal.chassis);
  const dealPayments = state.payments.filter(p => p.dealId === deal.id);
  const paid = dealPayments.reduce((a, p) => a + p.amount, 0);
  const balance = deal.salePrice - paid;

  return (
    <>
      <div className="page-hd">
        <button className="btn" onClick={onBack}><ArrowLeft size={14} style={{ transform: locale === 'ar' ? 'scaleX(-1)' : 'none' }}/> {t('back')}</button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" onClick={onPrint}><Printer size={14} /> {t('contract')}</button>
          <button className="btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
          <button className="btn danger" onClick={onDelete}><Trash2 size={14} /> {t('delete')}</button>
        </div>
      </div>

      <div className="detail-head">
        <div className="detail-head-top">
          <div className="avatar lg">{initials(deal.customerName)}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="detail-head-title">{deal.customerName}</div>
            <div className="detail-head-sub">{deal.id} · {deal.vehicleModel} · {deal.color}</div>
          </div>
          <StatusBadge status={deal.deliveryStatus} t={t} />
        </div>
        <div className="detail-head-meta">
          <div><div className="meta-lbl">{t('sale_price')}</div><div className="meta-val">{fmtCurrency(deal.salePrice, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('profit')}</div><div className="meta-val" style={{ color: deal.profit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrency(deal.profit, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('date')}</div><div className="meta-val">{fmtDate(deal.date, locale, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('assigned_to')}</div><div className="meta-val">{assigned ? (locale === 'ar' ? assigned.nameAr : assigned.name) : '—'}</div></div>
        </div>
      </div>

      <div className="detail">
        <div>
          <Tabs value={tab} onChange={setTab} tabs={[
            { value: 'details', label: t('details') },
            { value: 'related', label: t('related') },
            { value: 'activity', label: t('activity_tab') },
            { value: 'attachments', label: `${t('attachments')} (${deal.attachments.length})` },
          ]} />
          {tab === 'details' && (
            <div className="card">
              <div className="detail-row"><span className="detail-lbl">{t('deal_id')}</span><span className="detail-val mono">{deal.id}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('national_id')}</span><span className="detail-val mono">{deal.nationalId || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('mobile')}</span><span className="detail-val mono">{deal.mobile || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('vehicle_model')}</span><span className="detail-val">{deal.vehicleModel}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('color')}</span><span className="detail-val"><span className="color-dot" style={{ background: colorSwatch(deal.color), display: 'inline-block', marginInlineEnd: 6, verticalAlign: 'middle' }}></span>{deal.color}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('chassis')}</span><span className="detail-val mono">{deal.chassis || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('list_price')}</span><span className="detail-val">{fmtCurrency(deal.listPrice, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('sale_price')}</span><span className="detail-val">{fmtCurrency(deal.salePrice, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('profit')}</span><span className="detail-val" style={{ color: deal.profit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrency(deal.profit, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('jean_yasmine_share')}</span><span className="detail-val">{fmtCurrency(deal.jeanYasmineShare, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('ahmed_mohsen_share')}</span><span className="detail-val">{fmtCurrency(deal.ahmedMohsenShare, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('collected')}</span><span className="detail-val" style={{ color: 'var(--color-text-success)' }}>{fmtCurrency(paid, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('balance')}</span><span className="detail-val" style={{ color: balance > 0 ? 'var(--color-text-warning)' : 'var(--color-text-success)' }}>{fmtCurrency(balance, useArNum)}</span></div>
              {deal.notes && <div className="detail-row"><span className="detail-lbl">{t('notes')}</span><span className="detail-val">{deal.notes}</span></div>}
            </div>
          )}
          {tab === 'related' && (
            <div>
              {customer && (
                <div className="card" style={{ marginBottom: 10 }}>
                  <div className="section-hd"><div className="section-title">{t('customers')}</div></div>
                  <div className="tbl-wrap">
                    <table className="tbl">
                      <tbody>
                        <tr className="clickable" onClick={() => setDetail({ type: 'customer', id: customer.id })}>
                          <td><b>{customer.name}</b> <span style={{ color: 'var(--color-text-secondary)' }}>· {customer.id}</span></td>
                          <td className="r">{fmtNumber(customer.totalDeals, useArNum)} {locale === 'ar' ? 'صفقة' : 'deals'}</td>
                          <td className="r"><b>{fmtCurrencyShort(customer.totalSpend, useArNum)}</b></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              {stockItem && (
                <div className="card" style={{ marginBottom: 10 }}>
                  <div className="section-hd"><div className="section-title">{t('stock')}</div></div>
                  <div className="tbl-wrap">
                    <table className="tbl">
                      <tbody>
                        <tr className="clickable" onClick={() => stockItem.id.startsWith('STK-AG') && setDetail({ type: 'stock', id: stockItem.id })}>
                          <td className="mono">{stockItem.id}</td>
                          <td>{stockItem.vehicleModel}</td>
                          <td>{stockItem.color}</td>
                          <td><StatusBadge status={stockItem.status} t={t} /></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              <div className="card">
                <div className="section-hd"><div className="section-title">{t('payments')}</div></div>
                {dealPayments.length > 0 ? (
                  <div className="tbl-wrap">
                    <table className="tbl">
                      <thead><tr><th>{t('payment_id')}</th><th>{t('date')}</th><th className="r">{t('amount')}</th><th>{t('method')}</th></tr></thead>
                      <tbody>
                        {dealPayments.map(p => (
                          <tr key={p.id} className="clickable" onClick={() => setDetail({ type: 'payment', id: p.id })}>
                            <td className="mono">{p.id}</td>
                            <td>{fmtDate(p.date, locale, useArNum)}</td>
                            <td className="r"><b>{fmtCurrency(p.amount, useArNum)}</b></td>
                            <td>{t(METHOD_LABELS[p.method] || 'method_unknown')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : <div className="empty">{locale === 'ar' ? 'لا توجد دفعات مرتبطة' : 'No payments linked to this deal'}</div>}
              </div>
            </div>
          )}
          {tab === 'activity' && (
            <div className="card">
              <div className="timeline">
                <div className="tl-item">
                  <div className="tl-dot" style={{ background: '#1D9E75' }}></div>
                  <div className="tl-title">{locale === 'ar' ? 'تم إنشاء الصفقة' : 'Deal created'}</div>
                  <div className="tl-meta">{fmtDate(deal.date, locale, useArNum)}</div>
                </div>
                {deal.deliveryStatus === 'delivered' && (
                  <div className="tl-item">
                    <div className="tl-dot" style={{ background: '#378ADD' }}></div>
                    <div className="tl-title">{t('delivered')}</div>
                    <div className="tl-meta">{fmtDate(deal.date, locale, useArNum)}</div>
                  </div>
                )}
                {dealPayments.map(p => (
                  <div key={p.id} className="tl-item">
                    <div className="tl-dot" style={{ background: '#BA7517' }}></div>
                    <div className="tl-title">{locale === 'ar' ? 'دفعة' : 'Payment'}: {fmtCurrency(p.amount, useArNum)}</div>
                    <div className="tl-meta">{fmtDate(p.date, locale, useArNum)} · {t(METHOD_LABELS[p.method])}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab === 'attachments' && (
            <div className="card">
              <Attachments items={deal.attachments} onChange={onAttachmentsChange} t={t} locale={locale} currentUser={currentUser} />
            </div>
          )}
        </div>

        <div>
          <div className="sidebar-card">
            <h4>{t('quick_actions')}</h4>
            <button className="qa-btn" onClick={onPrint}><Printer size={14} /> {t('contract')}</button>
            <button className="qa-btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
            {customer && <button className="qa-btn" onClick={() => setDetail({ type: 'customer', id: customer.id })}><Users size={14} /> {t('customers')}</button>}
            <button className="qa-btn" onClick={() => setTab('attachments')}><Paperclip size={14} /> {t('attach_file')}</button>
          </div>
          <div className="sidebar-card">
            <h4>{t('summary' in DICT ? 'summary' : 'overview_tab')}</h4>
            <div className="detail-row"><span className="detail-lbl">{t('sale_price')}</span><span className="detail-val">{fmtCurrencyShort(deal.salePrice, useArNum)}</span></div>
            <div className="detail-row"><span className="detail-lbl">{t('collected')}</span><span className="detail-val" style={{ color: 'var(--color-text-success)' }}>{fmtCurrencyShort(paid, useArNum)}</span></div>
            <div className="detail-row"><span className="detail-lbl">{t('balance')}</span><span className="detail-val" style={{ color: balance > 0 ? 'var(--color-text-warning)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(balance, useArNum)}</span></div>
          </div>
        </div>
      </div>
    </>
  );
}

function DealForm({ deal, state, t, locale, useArNum, onSave, onClose }) {
  const [f, setF] = useState(deal || {
    id: 'DEAL-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random() * 999) + 1).padStart(3, '0'),
    year: new Date().getFullYear(), date: new Date().toISOString().slice(0, 10),
    customerName: '', nationalId: '', mobile: '', vehicleModel: '', chassis: '', color: '',
    listPrice: 0, salePrice: 0, profit: 0, deliveryStatus: 'pending',
    jeanYasmineShare: 0, ahmedMohsenShare: 0, notes: '', assignedTo: 'u1', customerId: null, attachments: [],
  });
  const upd = (k, v) => setF({ ...f, [k]: v });
  // auto-compute profit
  useEffect(() => {
    setF(prev => ({ ...prev, profit: (Number(prev.salePrice) || 0) - (Number(prev.listPrice) || 0) }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [f.listPrice, f.salePrice]);

  return (
    <Modal open onClose={onClose} wide locale={locale}
      title={deal ? (locale === 'ar' ? 'تعديل صفقة' : 'Edit deal') : (locale === 'ar' ? 'صفقة جديدة' : 'New deal')}
      footer={<>
        <button className="btn" onClick={onClose}>{t('cancel')}</button>
        <button className="btn prim" onClick={() => onSave(f)}><Save size={14} /> {t('save')}</button>
      </>}>
      <div className="form-grid">
        <div className="field"><label>{t('deal_id')}</label><input value={f.id} onChange={(e) => upd('id', e.target.value)} /></div>
        <div className="field"><label>{t('date')}</label><input type="date" value={f.date || ''} onChange={(e) => upd('date', e.target.value)} /></div>
        <div className="field span-2"><label>{t('customer_name')}</label><input value={f.customerName} onChange={(e) => upd('customerName', e.target.value)} /></div>
        <div className="field"><label>{t('national_id')}</label><input value={f.nationalId || ''} onChange={(e) => upd('nationalId', e.target.value)} /></div>
        <div className="field"><label>{t('mobile')}</label><input value={f.mobile || ''} onChange={(e) => upd('mobile', e.target.value)} /></div>
        <div className="field"><label>{t('vehicle_model')}</label><input value={f.vehicleModel} onChange={(e) => upd('vehicleModel', e.target.value)} /></div>
        <div className="field"><label>{t('color')}</label><input value={f.color} onChange={(e) => upd('color', e.target.value)} /></div>
        <div className="field"><label>{t('chassis')}</label><input value={f.chassis || ''} onChange={(e) => upd('chassis', e.target.value)} /></div>
        <div className="field"><label>{t('list_price')}</label><input type="number" value={f.listPrice} onChange={(e) => upd('listPrice', Number(e.target.value))} /></div>
        <div className="field"><label>{t('sale_price')}</label><input type="number" value={f.salePrice} onChange={(e) => upd('salePrice', Number(e.target.value))} /></div>
        <div className="field"><label>{t('profit')}</label><input type="number" value={f.profit} readOnly style={{ background: 'var(--color-background-secondary)' }} /></div>
        <div className="field"><label>{t('jean_yasmine_share')}</label><input type="number" value={f.jeanYasmineShare} onChange={(e) => upd('jeanYasmineShare', Number(e.target.value))} /></div>
        <div className="field"><label>{t('ahmed_mohsen_share')}</label><input type="number" value={f.ahmedMohsenShare} onChange={(e) => upd('ahmedMohsenShare', Number(e.target.value))} /></div>
        <div className="field"><label>{t('delivery_status')}</label>
          <select value={f.deliveryStatus} onChange={(e) => upd('deliveryStatus', e.target.value)}>
            <option value="pending">{t('pending')}</option>
            <option value="delivered">{t('delivered')}</option>
          </select>
        </div>
        <div className="field"><label>{t('assigned_to')}</label>
          <select value={f.assignedTo} onChange={(e) => upd('assignedTo', e.target.value)}>
            {SEED_USERS.map(u => <option key={u.id} value={u.id}>{locale === 'ar' ? u.nameAr : u.name}</option>)}
          </select>
        </div>
        <div className="field span-2"><label>{t('notes')}</label><textarea value={f.notes || ''} onChange={(e) => upd('notes', e.target.value)} rows={3} /></div>
      </div>
    </Modal>
  );
}

// ==================== CUSTOMERS MODULE ====================
function CustomersList({ state, t, locale, useArNum, setDetail, onNew }) {
  const [q, setQ] = useState('');
  const [segment, setSegment] = useState('');
  const rows = state.customers.filter(c => {
    const qs = q.trim().toLowerCase();
    const hit = !qs || [c.name, c.mobile, c.nationalId, c.id, c.modelsPurchased].some(f => f && String(f).toLowerCase().includes(qs));
    const sg = !segment || c.segment === segment;
    return hit && sg;
  }).sort((a, b) => b.totalSpend - a.totalSpend);

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('customers')}</div>
          <div className="page-sub">{fmtNumber(rows.length, useArNum)} {t('of')} {fmtNumber(state.customers.length, useArNum)} {t('records')}</div>
        </div>
        <button className="btn prim" onClick={onNew}><Plus size={14} /> {t('new')}</button>
      </div>
      <div className="controls">
        <input type="text" placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={segment} onChange={(e) => setSegment(e.target.value)}>
          <option value="">{locale === 'ar' ? 'كل الشرائح' : 'All segments'}</option>
          <option value="standard">{t('seg_standard')}</option>
          <option value="repeat">{t('seg_repeat')}</option>
          <option value="vip">{t('seg_vip')}</option>
        </select>
      </div>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead><tr>
            <th>{t('customer_id')}</th><th>{t('customer_name')}</th><th>{t('mobile')}</th>
            <th className="r">{t('total_deals')}</th><th className="r">{t('total_spend')}</th>
            <th className="r">{t('profit')}</th><th>{t('models_purchased')}</th><th>{t('segment')}</th>
          </tr></thead>
          <tbody>
            {rows.map(c => (
              <tr key={c.id} className="clickable" onClick={() => setDetail({ type: 'customer', id: c.id })}>
                <td className="mono nowrap">{c.id}</td>
                <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={c.name}>{c.name}</td>
                <td className="mono nowrap">{c.mobile || '—'}</td>
                <td className="r nowrap">{fmtNumber(c.totalDeals, useArNum)}</td>
                <td className="r nowrap"><b>{fmtCurrencyShort(c.totalSpend, useArNum)}</b></td>
                <td className="r nowrap" style={{ color: c.totalProfit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(c.totalProfit, useArNum)}</td>
                <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.modelsPurchased}</td>
                <td>{c.segment === 'repeat' ? <Badge kind="info">{t('seg_repeat')}</Badge> : c.segment === 'vip' ? <Badge kind="done">{t('seg_vip')}</Badge> : <Badge kind="none">{t('seg_standard')}</Badge>}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="empty">{t('no_results')}</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function CustomerDetail({ customer, state, t, locale, useArNum, onEdit, onDelete, onBack, onAttachmentsChange, currentUser, setDetail }) {
  const [tab, setTab] = useState('details');
  const deals = state.deals.filter(d => d.customerId === customer.id || d.customerName === customer.name);

  return (
    <>
      <div className="page-hd">
        <button className="btn" onClick={onBack}><ArrowLeft size={14} style={{ transform: locale === 'ar' ? 'scaleX(-1)' : 'none' }} /> {t('back')}</button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
          <button className="btn danger" onClick={onDelete}><Trash2 size={14} /> {t('delete')}</button>
        </div>
      </div>

      <div className="detail-head">
        <div className="detail-head-top">
          <div className="avatar lg">{initials(customer.name)}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="detail-head-title">{customer.name}</div>
            <div className="detail-head-sub">{customer.id} · {customer.mobile || '—'}</div>
          </div>
          {customer.segment === 'repeat' ? <Badge kind="info">{t('seg_repeat')}</Badge> : customer.segment === 'vip' ? <Badge kind="done">{t('seg_vip')}</Badge> : <Badge kind="none">{t('seg_standard')}</Badge>}
        </div>
        <div className="detail-head-meta">
          <div><div className="meta-lbl">{t('total_deals')}</div><div className="meta-val">{fmtNumber(customer.totalDeals, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('total_spend')}</div><div className="meta-val">{fmtCurrencyShort(customer.totalSpend, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('profit')}</div><div className="meta-val" style={{ color: customer.totalProfit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(customer.totalProfit, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('last_deal')}</div><div className="meta-val">{fmtDate(customer.lastDealDate, locale, useArNum)}</div></div>
        </div>
      </div>

      <div className="detail">
        <div>
          <Tabs value={tab} onChange={setTab} tabs={[
            { value: 'details', label: t('details') },
            { value: 'related', label: `${t('deals')} (${deals.length})` },
            { value: 'attachments', label: `${t('attachments')} (${customer.attachments.length})` },
          ]} />
          {tab === 'details' && (
            <div className="card">
              <div className="detail-row"><span className="detail-lbl">{t('customer_id')}</span><span className="detail-val mono">{customer.id}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('national_id')}</span><span className="detail-val mono">{customer.nationalId || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('mobile')}</span><span className="detail-val mono">{customer.mobile || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('first_deal')}</span><span className="detail-val">{fmtDate(customer.firstDealDate, locale, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('last_deal')}</span><span className="detail-val">{fmtDate(customer.lastDealDate, locale, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('models_purchased')}</span><span className="detail-val">{customer.modelsPurchased}</span></div>
            </div>
          )}
          {tab === 'related' && (
            <div className="card">
              {deals.length > 0 ? (
                <div className="tbl-wrap">
                  <table className="tbl">
                    <thead><tr><th>{t('deal_id')}</th><th>{t('date')}</th><th>{t('vehicle_model')}</th><th className="r">{t('sale_price')}</th><th>{t('status')}</th></tr></thead>
                    <tbody>
                      {deals.map(d => (
                        <tr key={d.id} className="clickable" onClick={() => setDetail({ type: 'deal', id: d.id })}>
                          <td className="mono">{d.id}</td>
                          <td>{fmtDate(d.date, locale, useArNum)}</td>
                          <td>{d.vehicleModel} · {d.color}</td>
                          <td className="r"><b>{fmtCurrencyShort(d.salePrice, useArNum)}</b></td>
                          <td><StatusBadge status={d.deliveryStatus} t={t} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div className="empty">{t('no_data')}</div>}
            </div>
          )}
          {tab === 'attachments' && (
            <div className="card">
              <Attachments items={customer.attachments} onChange={onAttachmentsChange} t={t} locale={locale} currentUser={currentUser} />
            </div>
          )}
        </div>

        <div>
          <div className="sidebar-card">
            <h4>{t('quick_actions')}</h4>
            {customer.mobile && <a href={'tel:' + customer.mobile} style={{ textDecoration: 'none' }}><button className="qa-btn"><Phone size={14} /> {customer.mobile}</button></a>}
            <button className="qa-btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
            <button className="qa-btn" onClick={() => setTab('attachments')}><Paperclip size={14} /> {t('attach_file')}</button>
          </div>
        </div>
      </div>
    </>
  );
}

function CustomerForm({ customer, t, locale, onSave, onClose }) {
  const [f, setF] = useState(customer || {
    id: 'CUST-' + String(Math.floor(Math.random() * 999) + 58).padStart(3, '0'),
    name: '', nationalId: '', mobile: '', totalDeals: 0, totalSpend: 0, totalProfit: 0,
    firstDealDate: null, lastDealDate: null, modelsPurchased: '', segment: 'standard', attachments: [],
  });
  const upd = (k, v) => setF({ ...f, [k]: v });
  return (
    <Modal open onClose={onClose} locale={locale}
      title={customer ? (locale === 'ar' ? 'تعديل عميل' : 'Edit customer') : (locale === 'ar' ? 'عميل جديد' : 'New customer')}
      footer={<>
        <button className="btn" onClick={onClose}>{t('cancel')}</button>
        <button className="btn prim" onClick={() => onSave(f)}><Save size={14} /> {t('save')}</button>
      </>}>
      <div className="form-grid">
        <div className="field"><label>{t('customer_id')}</label><input value={f.id} onChange={(e) => upd('id', e.target.value)} /></div>
        <div className="field"><label>{t('segment')}</label>
          <select value={f.segment} onChange={(e) => upd('segment', e.target.value)}>
            <option value="standard">{t('seg_standard')}</option>
            <option value="repeat">{t('seg_repeat')}</option>
            <option value="vip">{t('seg_vip')}</option>
          </select>
        </div>
        <div className="field span-2"><label>{t('customer_name')}</label><input value={f.name} onChange={(e) => upd('name', e.target.value)} /></div>
        <div className="field"><label>{t('national_id')}</label><input value={f.nationalId || ''} onChange={(e) => upd('nationalId', e.target.value)} /></div>
        <div className="field"><label>{t('mobile')}</label><input value={f.mobile || ''} onChange={(e) => upd('mobile', e.target.value)} /></div>
        <div className="field span-2"><label>{t('models_purchased')}</label><input value={f.modelsPurchased || ''} onChange={(e) => upd('modelsPurchased', e.target.value)} /></div>
      </div>
    </Modal>
  );
}

// ==================== PIPELINE MODULE (Leads + Kanban + Conversion) ====================
function PipelineBoard({ state, t, locale, useArNum, setDetail, onStageChange, onNew }) {
  const [view, setView] = useState('kanban');
  const [dragId, setDragId] = useState(null);
  const [dragOver, setDragOver] = useState(null);

  const activeStages = STAGES;

  const byStage = {};
  activeStages.forEach(s => byStage[s] = state.leads.filter(l => l.stage === s));
  const totalOpen = state.leads.filter(l => l.stage !== 'converted' && l.stage !== 'lost');
  const totalValue = totalOpen.reduce((a, l) => a + l.price, 0);

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('pipeline')}</div>
          <div className="page-sub">{fmtNumber(totalOpen.length, useArNum)} {locale === 'ar' ? 'فرص نشطة' : 'active leads'} · {fmtCurrencyShort(totalValue, useArNum)}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div style={{ display: 'flex', gap: 0, border: '0.5px solid var(--color-border-secondary)', borderRadius: 'var(--r-md)', overflow: 'hidden' }}>
            <button className="btn sm" style={view === 'kanban' ? { background: 'var(--color-text-primary)', color: 'var(--color-background-primary)', border: 'none' } : { border: 'none' }} onClick={() => setView('kanban')}>{t('kanban')}</button>
            <button className="btn sm" style={view === 'list' ? { background: 'var(--color-text-primary)', color: 'var(--color-background-primary)', border: 'none' } : { border: 'none' }} onClick={() => setView('list')}>{t('list_view')}</button>
          </div>
          <button className="btn prim" onClick={onNew}><Plus size={14} /> {t('new')}</button>
        </div>
      </div>

      <div className="kpi-grid">
        {activeStages.map(s => (
          <div key={s} className="kpi">
            <div className="kpi-label"><span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: STAGE_COLORS[s], marginInlineEnd: 6 }}></span>{t(STAGE_LABELS[s])}</div>
            <div className="kpi-val sm">{fmtNumber(byStage[s].length, useArNum)}</div>
            <div className="kpi-sub">{fmtCurrencyShort(byStage[s].reduce((a, l) => a + l.price, 0), useArNum)}</div>
          </div>
        ))}
      </div>

      {view === 'kanban' ? (
        <div className="kanban">
          {activeStages.map(s => (
            <div
              key={s}
              className={'kan-col' + (dragOver === s ? ' drag-over' : '')}
              onDragOver={(e) => { e.preventDefault(); setDragOver(s); }}
              onDragLeave={() => setDragOver(null)}
              onDrop={(e) => { e.preventDefault(); setDragOver(null); if (dragId) onStageChange(dragId, s); setDragId(null); }}
            >
              <div className="kan-hd">
                <span><span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: STAGE_COLORS[s], marginInlineEnd: 6 }}></span>{t(STAGE_LABELS[s])} · {fmtNumber(byStage[s].length, useArNum)}</span>
                <span>{fmtCurrencyShort(byStage[s].reduce((a, l) => a + l.price, 0), useArNum)}</span>
              </div>
              {byStage[s].map(l => (
                <div
                  key={l.id}
                  className={'kan-card' + (dragId === l.id ? ' dragging' : '')}
                  draggable
                  onDragStart={() => setDragId(l.id)}
                  onDragEnd={() => setDragId(null)}
                  onClick={() => setDetail({ type: 'lead', id: l.id })}
                >
                  <div className="kan-name">{l.customerName || '—'}</div>
                  <div className="kan-sub">{l.vehicleModel} · <span className="color-dot" style={{ background: colorSwatch(l.color), display: 'inline-block', verticalAlign: 'middle' }}></span> {l.color}</div>
                  <div className="kan-amt">{fmtCurrencyShort(l.price, useArNum)}</div>
                  {l.followUpDate && <div style={{ fontSize: 11, color: 'var(--color-text-tertiary)', marginTop: 4 }}><Clock size={10} style={{ verticalAlign: 'middle', marginInlineEnd: 3 }} />{fmtDate(l.followUpDate, locale, useArNum)}</div>}
                </div>
              ))}
              {byStage[s].length === 0 && <div style={{ padding: 16, textAlign: 'center', fontSize: 12, color: 'var(--color-text-tertiary)' }}>{t('no_data')}</div>}
            </div>
          ))}
        </div>
      ) : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>{t('deal_id')}</th><th>{t('customer_name')}</th><th>{t('vehicle_model')}</th><th>{t('color')}</th><th className="r">{t('price')}</th><th>{t('stage')}</th><th>{t('follow_up_date')}</th><th>{t('assigned_to')}</th></tr></thead>
            <tbody>
              {state.leads.map(l => {
                const u = SEED_USERS.find(x => x.id === l.assignedTo);
                return (
                  <tr key={l.id} className="clickable" onClick={() => setDetail({ type: 'lead', id: l.id })}>
                    <td className="mono nowrap">{l.id}</td>
                    <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.customerName || '—'}</td>
                    <td className="nowrap">{l.vehicleModel}</td>
                    <td className="nowrap"><span className="color-dot" style={{ background: colorSwatch(l.color), display: 'inline-block', marginInlineEnd: 6, verticalAlign: 'middle' }}></span>{l.color}</td>
                    <td className="r nowrap"><b>{fmtCurrencyShort(l.price, useArNum)}</b></td>
                    <td><StageBadge stage={l.stage} t={t} /></td>
                    <td className="nowrap">{fmtDate(l.followUpDate, locale, useArNum)}</td>
                    <td>{u ? (locale === 'ar' ? u.nameAr : u.name) : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

function LeadDetail({ lead, state, t, locale, useArNum, onEdit, onDelete, onBack, onConvert, onAttachmentsChange, onStageChange, currentUser, setDetail }) {
  const [tab, setTab] = useState('details');
  const [convertOpen, setConvertOpen] = useState(false);
  const u = SEED_USERS.find(x => x.id === lead.assignedTo);
  const canConvert = lead.stage !== 'converted' && lead.stage !== 'lost';

  return (
    <>
      <div className="page-hd">
        <button className="btn" onClick={onBack}><ArrowLeft size={14} style={{ transform: locale === 'ar' ? 'scaleX(-1)' : 'none' }} /> {t('back')}</button>
        <div style={{ display: 'flex', gap: 8 }}>
          {canConvert && <button className="btn prim" onClick={() => setConvertOpen(true)}><Sparkles size={14} /> {t('convert_to_deal')}</button>}
          <button className="btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
          <button className="btn danger" onClick={onDelete}><Trash2 size={14} /> {t('delete')}</button>
        </div>
      </div>

      <div className="detail-head">
        <div className="detail-head-top">
          <div className="avatar lg">{initials(lead.customerName || lead.vehicleModel)}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="detail-head-title">{lead.customerName || lead.vehicleModel}</div>
            <div className="detail-head-sub">{lead.id} · {lead.vehicleModel} · {lead.color}</div>
          </div>
          <StageBadge stage={lead.stage} t={t} />
        </div>
        <div className="detail-head-meta">
          <div><div className="meta-lbl">{t('price')}</div><div className="meta-val">{fmtCurrency(lead.price, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('mobile')}</div><div className="meta-val mono">{lead.mobile || '—'}</div></div>
          <div><div className="meta-lbl">{t('follow_up_date')}</div><div className="meta-val">{fmtDate(lead.followUpDate, locale, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('assigned_to')}</div><div className="meta-val">{u ? (locale === 'ar' ? u.nameAr : u.name) : '—'}</div></div>
        </div>
      </div>

      <div className="detail">
        <div>
          <Tabs value={tab} onChange={setTab} tabs={[
            { value: 'details', label: t('details') },
            { value: 'attachments', label: `${t('attachments')} (${lead.attachments.length})` },
          ]} />
          {tab === 'details' && (
            <div className="card">
              <div className="detail-row"><span className="detail-lbl">{t('deal_id')}</span><span className="detail-val mono">{lead.id}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('customer_name')}</span><span className="detail-val">{lead.customerName || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('mobile')}</span><span className="detail-val mono">{lead.mobile || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('vehicle_model')}</span><span className="detail-val">{lead.vehicleModel}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('color')}</span><span className="detail-val">{lead.color}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('price')}</span><span className="detail-val">{fmtCurrency(lead.price, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('stage')}</span><span className="detail-val"><StageBadge stage={lead.stage} t={t} /></span></div>
              <div className="detail-row"><span className="detail-lbl">{t('follow_up_date')}</span><span className="detail-val">{fmtDate(lead.followUpDate, locale, useArNum)}</span></div>
              {lead.notes && <div className="detail-row"><span className="detail-lbl">{t('notes')}</span><span className="detail-val">{lead.notes}</span></div>}
              {lead.convertedDealId && <div className="detail-row"><span className="detail-lbl">{t('stg_converted')}</span><span className="detail-val mono">→ {lead.convertedDealId}</span></div>}
            </div>
          )}
          {tab === 'attachments' && (
            <div className="card">
              <Attachments items={lead.attachments} onChange={onAttachmentsChange} t={t} locale={locale} currentUser={currentUser} />
            </div>
          )}
        </div>
        <div>
          <div className="sidebar-card">
            <h4>{t('quick_actions')}</h4>
            {canConvert && <button className="qa-btn" onClick={() => setConvertOpen(true)}><Sparkles size={14} /> {t('convert_to_deal')}</button>}
            {lead.mobile && <a href={'tel:' + lead.mobile} style={{ textDecoration: 'none' }}><button className="qa-btn"><Phone size={14} /> {lead.mobile}</button></a>}
            <button className="qa-btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
            <button className="qa-btn" onClick={() => setTab('attachments')}><Paperclip size={14} /> {t('attach_file')}</button>
          </div>
          <div className="sidebar-card">
            <h4>{t('change_stage' in DICT ? 'change_stage' : 'stage')}</h4>
            {STAGES.map(s => (
              <button key={s} className="qa-btn" onClick={() => onStageChange(lead.id, s)} style={lead.stage === s ? { background: 'var(--color-background-secondary)' } : {}}>
                <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: STAGE_COLORS[s] }}></span>
                {t(STAGE_LABELS[s])}
                {lead.stage === s && <Check size={12} style={{ marginInlineStart: 'auto' }} />}
              </button>
            ))}
          </div>
        </div>
      </div>

      {convertOpen && (
        <ConvertLead lead={lead} state={state} t={t} locale={locale}
          onClose={() => setConvertOpen(false)}
          onConfirm={(opts) => { onConvert(lead, opts); setConvertOpen(false); }}
        />
      )}
    </>
  );
}

function ConvertLead({ lead, state, t, locale, onClose, onConfirm }) {
  // Allow linking to an existing customer, or create a new one
  const existing = state.customers.filter(c => c.name.includes(lead.customerName) || (lead.mobile && c.mobile === lead.mobile));
  const [mode, setMode] = useState(existing.length > 0 ? 'link' : 'new');
  const [customerId, setCustomerId] = useState(existing[0]?.id || '');
  const [nationalId, setNationalId] = useState('');
  const [salePrice, setSalePrice] = useState(lead.price);
  const [listPrice, setListPrice] = useState(lead.price);

  return (
    <Modal open onClose={onClose} locale={locale}
      title={t('convert_to_deal')}
      footer={<>
        <button className="btn" onClick={onClose}>{t('cancel')}</button>
        <button className="btn prim" onClick={() => onConfirm({ mode, customerId, nationalId, salePrice, listPrice })}><Check size={14} /> {t('confirm' in DICT ? 'confirm' : 'save')}</button>
      </>}>
      <p style={{ fontSize: 13, color: 'var(--color-text-secondary)', marginBottom: 14 }}>{t('convert_desc')}</p>
      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        <label style={{ flex: 1, padding: 10, border: '0.5px solid ' + (mode === 'new' ? 'var(--color-border-primary)' : 'var(--color-border-tertiary)'), borderRadius: 'var(--r-md)', cursor: 'pointer', fontSize: 13 }}>
          <input type="radio" checked={mode === 'new'} onChange={() => setMode('new')} style={{ marginInlineEnd: 6 }} />
          {locale === 'ar' ? 'عميل جديد' : 'New customer'}
        </label>
        <label style={{ flex: 1, padding: 10, border: '0.5px solid ' + (mode === 'link' ? 'var(--color-border-primary)' : 'var(--color-border-tertiary)'), borderRadius: 'var(--r-md)', cursor: 'pointer', fontSize: 13, opacity: state.customers.length ? 1 : 0.5 }}>
          <input type="radio" checked={mode === 'link'} onChange={() => setMode('link')} disabled={!state.customers.length} style={{ marginInlineEnd: 6 }} />
          {locale === 'ar' ? 'ربط بعميل حالي' : 'Link to existing customer'}
        </label>
      </div>
      {mode === 'link' && (
        <div className="field" style={{ marginBottom: 14 }}>
          <label>{t('customer_name')}</label>
          <select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
            <option value="">—</option>
            {state.customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      )}
      {mode === 'new' && (
        <div className="field" style={{ marginBottom: 14 }}>
          <label>{t('national_id')}</label>
          <input value={nationalId} onChange={(e) => setNationalId(e.target.value)} />
        </div>
      )}
      <div className="form-grid">
        <div className="field"><label>{t('list_price')}</label><input type="number" value={listPrice} onChange={(e) => setListPrice(Number(e.target.value))} /></div>
        <div className="field"><label>{t('sale_price')}</label><input type="number" value={salePrice} onChange={(e) => setSalePrice(Number(e.target.value))} /></div>
      </div>
    </Modal>
  );
}

function LeadForm({ lead, t, locale, onSave, onClose }) {
  const [f, setF] = useState(lead || {
    id: 'PIPE-' + String(Math.floor(Math.random() * 900) + 100),
    customerName: '', mobile: '', vehicleModel: '', color: '', price: 0,
    stage: 'lead', assignedTo: 'u1', followUpDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
    notes: '', createdAt: new Date().toISOString().slice(0, 10), attachments: [],
  });
  const upd = (k, v) => setF({ ...f, [k]: v });
  return (
    <Modal open onClose={onClose} locale={locale}
      title={lead ? (locale === 'ar' ? 'تعديل فرصة' : 'Edit lead') : (locale === 'ar' ? 'فرصة جديدة' : 'New lead')}
      footer={<>
        <button className="btn" onClick={onClose}>{t('cancel')}</button>
        <button className="btn prim" onClick={() => onSave(f)}><Save size={14} /> {t('save')}</button>
      </>}>
      <div className="form-grid">
        <div className="field"><label>{t('deal_id')}</label><input value={f.id} onChange={(e) => upd('id', e.target.value)} /></div>
        <div className="field"><label>{t('stage')}</label>
          <select value={f.stage} onChange={(e) => upd('stage', e.target.value)}>
            {STAGES.map(s => <option key={s} value={s}>{t(STAGE_LABELS[s])}</option>)}
          </select>
        </div>
        <div className="field span-2"><label>{t('customer_name')}</label><input value={f.customerName} onChange={(e) => upd('customerName', e.target.value)} /></div>
        <div className="field"><label>{t('mobile')}</label><input value={f.mobile || ''} onChange={(e) => upd('mobile', e.target.value)} /></div>
        <div className="field"><label>{t('assigned_to')}</label>
          <select value={f.assignedTo} onChange={(e) => upd('assignedTo', e.target.value)}>
            {SEED_USERS.map(u => <option key={u.id} value={u.id}>{locale === 'ar' ? u.nameAr : u.name}</option>)}
          </select>
        </div>
        <div className="field"><label>{t('vehicle_model')}</label><input value={f.vehicleModel} onChange={(e) => upd('vehicleModel', e.target.value)} /></div>
        <div className="field"><label>{t('color')}</label><input value={f.color} onChange={(e) => upd('color', e.target.value)} /></div>
        <div className="field"><label>{t('price')}</label><input type="number" value={f.price} onChange={(e) => upd('price', Number(e.target.value))} /></div>
        <div className="field"><label>{t('follow_up_date')}</label><input type="date" value={f.followUpDate || ''} onChange={(e) => upd('followUpDate', e.target.value)} /></div>
        <div className="field span-2"><label>{t('notes')}</label><textarea value={f.notes || ''} onChange={(e) => upd('notes', e.target.value)} rows={3} /></div>
      </div>
    </Modal>
  );
}

// ==================== STOCK MODULE ====================
function StockList({ state, t, locale, useArNum, setDetail, onNew }) {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [view, setView] = useState('cards');

  const rows = state.stock.filter(s => {
    const qs = q.trim().toLowerCase();
    const hit = !qs || [s.vehicleModel, s.chassis, s.color, s.id, s.comment].some(f => f && String(f).toLowerCase().includes(qs));
    const st = !status || s.status === status;
    return hit && st;
  });

  // group stock counts by model
  const byModel = {};
  state.stock.forEach(s => { const k = s.vehicleModel; if (!byModel[k]) byModel[k] = { total: 0, available: 0 }; byModel[k].total++; if (s.status === 'in_stock') byModel[k].available++; });

  const keys1 = state.stock.filter(s => s.keys === 1).length;
  const withSafia = state.stock.filter(s => s.status === 'with_safia').length;

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('stock')}</div>
          <div className="page-sub">{fmtNumber(rows.length, useArNum)} {t('of')} {fmtNumber(state.stock.length, useArNum)} {t('records')}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div style={{ display: 'flex', gap: 0, border: '0.5px solid var(--color-border-secondary)', borderRadius: 'var(--r-md)', overflow: 'hidden' }}>
            <button className="btn sm" style={view === 'cards' ? { background: 'var(--color-text-primary)', color: 'var(--color-background-primary)', border: 'none' } : { border: 'none' }} onClick={() => setView('cards')}>{t('card_view')}</button>
            <button className="btn sm" style={view === 'list' ? { background: 'var(--color-text-primary)', color: 'var(--color-background-primary)', border: 'none' } : { border: 'none' }} onClick={() => setView('list')}>{t('list_view')}</button>
          </div>
          <button className="btn prim" onClick={onNew}><Plus size={14} /> {t('new')}</button>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi"><div className="kpi-label">{t('kpi_stock_units')}</div><div className="kpi-val">{fmtNumber(state.stock.length, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('stk_in_stock')}</div><div className="kpi-val success">{fmtNumber(state.stock.filter(s => s.status === 'in_stock').length, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('stk_with_safia')}</div><div className="kpi-val warn">{fmtNumber(withSafia, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{locale === 'ar' ? 'مفتاح واحد' : '1-key (used)'}</div><div className="kpi-val sm">{fmtNumber(keys1, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{locale === 'ar' ? 'موديلات متوفرة' : 'Models carried'}</div><div className="kpi-val sm">{fmtNumber(Object.keys(byModel).length, useArNum)}</div></div>
      </div>

      <div className="controls">
        <input type="text" placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">{t('all_statuses')}</option>
          {Object.keys(STATUS_LABELS).map(k => <option key={k} value={k}>{t(STATUS_LABELS[k])}</option>)}
        </select>
      </div>

      {view === 'cards' ? (
        <div className="stock-grid">
          {rows.map(s => {
            const cls = s.status === 'with_safia' ? ' with-safia' : s.status === 'out_with_client' ? ' out-client' : '';
            return (
              <div key={s.id} className={'stock-card' + cls} onClick={() => setDetail({ type: 'stock', id: s.id })}>
                <span className="stock-badge" style={s.status !== 'in_stock' ? { background: 'var(--color-background-warning)', color: 'var(--color-text-warning)' } : {}}>{t(STATUS_LABELS[s.status])}</span>
                <div className="stock-model">{s.vehicleModel}</div>
                <div className="stock-color"><span className="color-dot" style={{ background: colorSwatch(s.color) }}></span>{s.color} · {fmtNumber(s.year, useArNum)}</div>
                <div className="stock-meta">VIN: {s.chassis || '—'}</div>
                <div className="stock-meta">Keys: {fmtNumber(s.keys, useArNum)} · {s.id}</div>
                {s.comment && <div style={{ fontSize: 11, color: 'var(--color-text-warning)', marginTop: 6 }}>{s.comment}</div>}
              </div>
            );
          })}
          {rows.length === 0 && <div className="empty" style={{ gridColumn: '1/-1' }}>{t('no_results')}</div>}
        </div>
      ) : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>{t('stock_id')}</th><th>{t('vehicle_model')}</th><th>{t('year')}</th><th>{t('color')}</th><th>{t('chassis')}</th><th className="r">{t('keys')}</th><th>{t('status')}</th><th>{t('comment')}</th></tr></thead>
            <tbody>
              {rows.map(s => (
                <tr key={s.id} className="clickable" onClick={() => setDetail({ type: 'stock', id: s.id })}>
                  <td className="mono nowrap">{s.id}</td>
                  <td className="nowrap">{s.vehicleModel}</td>
                  <td className="nowrap">{fmtNumber(s.year, useArNum)}</td>
                  <td className="nowrap"><span className="color-dot" style={{ background: colorSwatch(s.color), display: 'inline-block', marginInlineEnd: 6, verticalAlign: 'middle' }}></span>{s.color}</td>
                  <td className="mono nowrap">{s.chassis || '—'}</td>
                  <td className="r">{fmtNumber(s.keys, useArNum)}</td>
                  <td><StatusBadge status={s.status} t={t} /></td>
                  <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12, color: 'var(--color-text-secondary)' }}>{s.comment || '—'}</td>
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={8} className="empty">{t('no_results')}</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      <div className="section">
        <div className="section-hd"><div className="section-title">{t('stock_by_model')}</div></div>
        <div className="card">
          {Object.entries(byModel).sort((a, b) => b[1].total - a[1].total).map(([name, d]) => (
            <div key={name} className="bar-row">
              <div className="bar-label" title={name}>{name}</div>
              <div className="bar-track"><div className="bar-fill" style={{ width: (d.total / Math.max(...Object.values(byModel).map(x => x.total)) * 100) + '%', background: '#534AB7' }} /></div>
              <div className="bar-val">{fmtNumber(d.total, useArNum)} · {fmtNumber(d.available, useArNum)} {locale === 'ar' ? 'متاح' : 'avail'}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

const Circle = ({ size = 10 }) => <span style={{ display: 'inline-block', width: size, height: size, borderRadius: '50%', border: '1.5px solid var(--color-text-secondary)' }}></span>;

function StockDetail({ item, state, t, locale, useArNum, onEdit, onDelete, onStatusChange, onBack, onAttachmentsChange, onPrint, currentUser, setDetail }) {
  const [tab, setTab] = useState('details');
  const deal = state.deals.find(d => d.chassis === item.chassis);
  const movements = state.movements.filter(m => m.chassis === item.chassis);

  return (
    <>
      <div className="page-hd">
        <button className="btn" onClick={onBack}><ArrowLeft size={14} style={{ transform: locale === 'ar' ? 'scaleX(-1)' : 'none' }} /> {t('back')}</button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" onClick={onPrint}><Printer size={14} /> {t('stock_card')}</button>
          <button className="btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
          <button className="btn danger" onClick={onDelete}><Trash2 size={14} /> {t('delete')}</button>
        </div>
      </div>

      <div className="detail-head">
        <div className="detail-head-top">
          <div className="avatar lg" style={{ background: colorSwatch(item.color) + '33', color: 'var(--color-text-primary)' }}><Car size={20} /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="detail-head-title">{item.vehicleModel}</div>
            <div className="detail-head-sub">{item.id} · {item.color} · {fmtNumber(item.year, useArNum)}</div>
          </div>
          <StatusBadge status={item.status} t={t} />
        </div>
        <div className="detail-head-meta">
          <div><div className="meta-lbl">{t('chassis')}</div><div className="meta-val mono">{item.chassis || '—'}</div></div>
          <div><div className="meta-lbl">{t('keys')}</div><div className="meta-val">{fmtNumber(item.keys, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('location')}</div><div className="meta-val">{item.location}</div></div>
          <div><div className="meta-lbl">{t('year')}</div><div className="meta-val">{fmtNumber(item.year, useArNum)}</div></div>
        </div>
      </div>

      <div className="detail">
        <div>
          <Tabs value={tab} onChange={setTab} tabs={[
            { value: 'details', label: t('details') },
            { value: 'related', label: `${t('related')} (${(deal ? 1 : 0) + movements.length})` },
            { value: 'attachments', label: `${t('attachments')} (${item.attachments.length})` },
          ]} />
          {tab === 'details' && (
            <div className="card">
              <div className="detail-row"><span className="detail-lbl">{t('stock_id')}</span><span className="detail-val mono">{item.id}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('vehicle_model')}</span><span className="detail-val">{item.vehicleModel}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('year')}</span><span className="detail-val">{fmtNumber(item.year, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('color')}</span><span className="detail-val"><span className="color-dot" style={{ background: colorSwatch(item.color), display: 'inline-block', marginInlineEnd: 6, verticalAlign: 'middle' }}></span>{item.color}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('chassis')}</span><span className="detail-val mono">{item.chassis || '—'}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('keys')}</span><span className="detail-val">{fmtNumber(item.keys, useArNum)}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('location')}</span><span className="detail-val">{item.location}</span></div>
              <div className="detail-row"><span className="detail-lbl">{t('status')}</span><span className="detail-val"><StatusBadge status={item.status} t={t} /></span></div>
              {item.comment && <div className="detail-row"><span className="detail-lbl">{t('comment')}</span><span className="detail-val">{item.comment}</span></div>}
            </div>
          )}
          {tab === 'related' && (
            <div>
              {deal && (
                <div className="card" style={{ marginBottom: 10 }}>
                  <div className="section-hd"><div className="section-title">{t('deals')}</div></div>
                  <div className="tbl-wrap">
                    <table className="tbl">
                      <tbody>
                        <tr className="clickable" onClick={() => setDetail({ type: 'deal', id: deal.id })}>
                          <td className="mono">{deal.id}</td>
                          <td>{deal.customerName}</td>
                          <td>{fmtDate(deal.date, locale, useArNum)}</td>
                          <td className="r"><b>{fmtCurrencyShort(deal.salePrice, useArNum)}</b></td>
                          <td><StatusBadge status={deal.deliveryStatus} t={t} /></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              {movements.length > 0 && (
                <div className="card">
                  <div className="section-hd"><div className="section-title">{t('movements')}</div></div>
                  <div className="tbl-wrap">
                    <table className="tbl">
                      <thead><tr><th>#</th><th>{t('vehicle_model')}</th><th>{t('comment')}</th><th>{t('status')}</th></tr></thead>
                      <tbody>
                        {movements.map(m => (
                          <tr key={m.id}>
                            <td className="mono">{m.id}</td>
                            <td>{m.vehicleModel}</td>
                            <td style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>{m.movement || m.inDate || m.comment || '—'}</td>
                            <td><StatusBadge status={m.status} t={t} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              {!deal && movements.length === 0 && <div className="empty">{t('no_data')}</div>}
            </div>
          )}
          {tab === 'attachments' && (
            <div className="card">
              <Attachments items={item.attachments} onChange={onAttachmentsChange} t={t} locale={locale} currentUser={currentUser} />
            </div>
          )}
        </div>
        <div>
          <div className="sidebar-card">
            <h4>{t('quick_actions')}</h4>
            <button className="qa-btn" onClick={onPrint}><Printer size={14} /> {t('stock_card')}</button>
            <button className="qa-btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
            <button className="qa-btn" onClick={() => setTab('attachments')}><Paperclip size={14} /> {t('attach_file')}</button>
          </div>
          <div className="sidebar-card">
            <h4>{t('status')}</h4>
            {Object.keys(STATUS_LABELS).map(s => (
              <button key={s} className="qa-btn" onClick={() => onStatusChange(item.id, s)} style={item.status === s ? { background: 'var(--color-background-secondary)' } : {}}>
                <Circle size={10} />
                {t(STATUS_LABELS[s])}
                {item.status === s && <Check size={12} style={{ marginInlineStart: 'auto' }} />}
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function StockForm({ item, t, locale, onSave, onClose }) {
  const [f, setF] = useState(item || {
    id: 'STK-AG-' + String(Math.floor(Math.random() * 900) + 100),
    location: 'Abou Ghali', vehicleModel: '', year: new Date().getFullYear(),
    color: '', chassis: '', keys: 2, comment: null, status: 'in_stock', attachments: [],
  });
  const upd = (k, v) => setF({ ...f, [k]: v });
  return (
    <Modal open onClose={onClose} locale={locale}
      title={item ? (locale === 'ar' ? 'تعديل سيارة' : 'Edit vehicle') : (locale === 'ar' ? 'سيارة جديدة' : 'New vehicle')}
      footer={<>
        <button className="btn" onClick={onClose}>{t('cancel')}</button>
        <button className="btn prim" onClick={() => onSave(f)}><Save size={14} /> {t('save')}</button>
      </>}>
      <div className="form-grid">
        <div className="field"><label>{t('stock_id')}</label><input value={f.id} onChange={(e) => upd('id', e.target.value)} /></div>
        <div className="field"><label>{t('location')}</label><input value={f.location} onChange={(e) => upd('location', e.target.value)} /></div>
        <div className="field span-2"><label>{t('vehicle_model')}</label><input value={f.vehicleModel} onChange={(e) => upd('vehicleModel', e.target.value)} /></div>
        <div className="field"><label>{t('year')}</label><input type="number" value={f.year} onChange={(e) => upd('year', Number(e.target.value))} /></div>
        <div className="field"><label>{t('color')}</label><input value={f.color} onChange={(e) => upd('color', e.target.value)} /></div>
        <div className="field"><label>{t('chassis')}</label><input value={f.chassis || ''} onChange={(e) => upd('chassis', e.target.value)} /></div>
        <div className="field"><label>{t('keys')}</label><input type="number" min={0} max={3} value={f.keys} onChange={(e) => upd('keys', Number(e.target.value))} /></div>
        <div className="field"><label>{t('status')}</label>
          <select value={f.status} onChange={(e) => upd('status', e.target.value)}>
            {Object.keys(STATUS_LABELS).map(s => <option key={s} value={s}>{t(STATUS_LABELS[s])}</option>)}
          </select>
        </div>
        <div className="field span-2"><label>{t('comment')}</label><textarea value={f.comment || ''} onChange={(e) => upd('comment', e.target.value)} rows={2} /></div>
      </div>
    </Modal>
  );
}

// ==================== MOVEMENTS MODULE ====================
function MovementsList({ state, t, locale, useArNum }) {
  const [q, setQ] = useState('');
  const [dir, setDir] = useState('');

  const rows = state.movements.filter(m => {
    const qs = q.trim().toLowerCase();
    const hit = !qs || [m.vehicleModel, m.chassis, m.color, m.id, m.movement, m.inDate, m.comment].some(f => f && String(f).toLowerCase().includes(qs));
    const dm = !dir || m.direction === dir;
    return hit && dm;
  });

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('movements')}</div>
          <div className="page-sub">{fmtNumber(rows.length, useArNum)} {t('of')} {fmtNumber(state.movements.length, useArNum)} {t('records')}</div>
        </div>
      </div>
      <div className="kpi-grid">
        <div className="kpi"><div className="kpi-label">{locale === 'ar' ? 'إجمالي الحركات' : 'Total movements'}</div><div className="kpi-val">{fmtNumber(state.movements.length, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('stk_in_stock')}</div><div className="kpi-val success">{fmtNumber(state.movements.filter(m => m.status === 'in_stock').length, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('stk_out_client')}</div><div className="kpi-val warn">{fmtNumber(state.movements.filter(m => m.status === 'out_with_client').length, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('stk_with_safia')}</div><div className="kpi-val">{fmtNumber(state.movements.filter(m => m.status === 'with_safia').length, useArNum)}</div></div>
      </div>
      <div className="controls">
        <input type="text" placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={dir} onChange={(e) => setDir(e.target.value)}>
          <option value="">{locale === 'ar' ? 'كل الاتجاهات' : 'All directions'}</option>
          <option value="in">{t('move_in')}</option>
          <option value="out">{t('move_out')}</option>
        </select>
      </div>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead><tr><th>{t('stock_id')}</th><th>{t('vehicle_model')}</th><th>{t('year')}</th><th>{t('color')}</th><th>{t('chassis')}</th><th className="c">{t('keys')}</th><th>{locale === 'ar' ? 'التفاصيل' : 'Detail'}</th><th>{t('status')}</th></tr></thead>
          <tbody>
            {rows.map(m => (
              <tr key={m.id}>
                <td className="mono nowrap">{m.id}</td>
                <td className="nowrap">{m.vehicleModel}</td>
                <td>{m.year ? fmtNumber(m.year, useArNum) : '—'}</td>
                <td className="nowrap"><span className="color-dot" style={{ background: colorSwatch(m.color), display: 'inline-block', marginInlineEnd: 6, verticalAlign: 'middle' }}></span>{m.color}</td>
                <td className="mono nowrap">{m.chassis || '—'}</td>
                <td className="c">{fmtNumber(m.keys, useArNum)}</td>
                <td style={{ maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12, color: 'var(--color-text-secondary)' }} title={m.movement || m.inDate || m.comment}>
                  {m.direction === 'out' ? <ArrowUpRight size={11} style={{ verticalAlign: 'middle', color: 'var(--color-text-warning)' }} /> : <ArrowDownRight size={11} style={{ verticalAlign: 'middle', color: 'var(--color-text-success)' }} />}
                  {' '}{m.movement || m.inDate || m.comment || '—'}
                </td>
                <td><StatusBadge status={m.status} t={t} /></td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="empty">{t('no_results')}</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ==================== PAYMENTS MODULE ====================
function PaymentsList({ state, t, locale, useArNum, onNew, onEdit, setDetail }) {
  const [q, setQ] = useState('');
  const [year, setYear] = useState('');
  const [method, setMethod] = useState('');

  const rows = state.payments.filter(p => {
    const qs = q.trim().toLowerCase();
    const hit = !qs || [p.id, p.date, p.method].some(f => f && String(f).toLowerCase().includes(qs));
    const yr = !year || String(p.year) === year;
    const mt = !method || p.method === method;
    return hit && yr && mt;
  }).sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  const total = rows.reduce((a, p) => a + p.amount, 0);
  const cashTotal = rows.filter(p => p.method === 'cash').reduce((a, p) => a + p.amount, 0);
  const bankTotal = rows.filter(p => p.method === 'bank').reduce((a, p) => a + p.amount, 0);

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('payments')}</div>
          <div className="page-sub">{fmtNumber(rows.length, useArNum)} {t('of')} {fmtNumber(state.payments.length, useArNum)} {t('records')}</div>
        </div>
        <button className="btn prim" onClick={onNew}><Plus size={14} /> {t('new')}</button>
      </div>
      <div className="kpi-grid">
        <div className="kpi"><div className="kpi-label">{locale === 'ar' ? 'المجموع المعروض' : 'Showing total'}</div><div className="kpi-val sm success">{fmtCurrencyShort(total, useArNum)}</div></div>
        <div className="kpi"><div className="kpi-label">{t('method_cash')}</div><div className="kpi-val sm">{fmtCurrencyShort(cashTotal, useArNum)}</div><div className="kpi-sub">{total > 0 ? Math.round(cashTotal / total * 100) : 0}%</div></div>
        <div className="kpi"><div className="kpi-label">{t('method_bank')}</div><div className="kpi-val sm">{fmtCurrencyShort(bankTotal, useArNum)}</div><div className="kpi-sub">{total > 0 ? Math.round(bankTotal / total * 100) : 0}%</div></div>
        <div className="kpi"><div className="kpi-label">{locale === 'ar' ? 'متوسط الدفعة' : 'Avg payment'}</div><div className="kpi-val sm">{fmtCurrencyShort(rows.length ? total / rows.length : 0, useArNum)}</div></div>
      </div>
      <div className="controls">
        <input type="text" placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={year} onChange={(e) => setYear(e.target.value)}>
          <option value="">{t('all_years')}</option><option value="2025">2025</option><option value="2026">2026</option>
        </select>
        <select value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="">{t('all_methods')}</option>
          <option value="cash">{t('method_cash')}</option>
          <option value="bank">{t('method_bank')}</option>
          <option value="unknown">{t('method_unknown')}</option>
        </select>
      </div>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead><tr><th>{t('payment_id')}</th><th>{t('date')}</th><th className="r">{t('amount')}</th><th>{t('method')}</th><th></th></tr></thead>
          <tbody>
            {rows.map(p => (
              <tr key={p.id} className="clickable" onClick={() => setDetail({ type: 'payment', id: p.id })}>
                <td className="mono nowrap">{p.id}</td>
                <td className="nowrap">{fmtDate(p.date, locale, useArNum)}</td>
                <td className="r nowrap"><b style={{ color: 'var(--color-text-success)' }}>{fmtCurrency(p.amount, useArNum)}</b></td>
                <td>{t(METHOD_LABELS[p.method] || 'method_unknown')}</td>
                <td><button className="btn sm" onClick={(e) => { e.stopPropagation(); onEdit(p); }}><Edit2 size={12} /></button></td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="empty">{t('no_results')}</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function PaymentDetail({ payment, state, t, locale, useArNum, onEdit, onDelete, onBack, onAttachmentsChange, onPrint, currentUser }) {
  const deal = state.deals.find(d => d.id === payment.dealId);
  return (
    <>
      <div className="page-hd">
        <button className="btn" onClick={onBack}><ArrowLeft size={14} style={{ transform: locale === 'ar' ? 'scaleX(-1)' : 'none' }} /> {t('back')}</button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" onClick={onPrint}><Printer size={14} /> {t('receipt')}</button>
          <button className="btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
          <button className="btn danger" onClick={onDelete}><Trash2 size={14} /> {t('delete')}</button>
        </div>
      </div>
      <div className="detail-head">
        <div className="detail-head-top">
          <div className="avatar lg"><Wallet size={18} /></div>
          <div style={{ flex: 1 }}>
            <div className="detail-head-title">{fmtCurrency(payment.amount, useArNum)}</div>
            <div className="detail-head-sub">{payment.id} · {fmtDate(payment.date, locale, useArNum)}</div>
          </div>
        </div>
        <div className="detail-head-meta">
          <div><div className="meta-lbl">{t('method')}</div><div className="meta-val">{t(METHOD_LABELS[payment.method] || 'method_unknown')}</div></div>
          <div><div className="meta-lbl">{t('year')}</div><div className="meta-val">{fmtNumber(payment.year, useArNum)}</div></div>
          <div><div className="meta-lbl">{t('link_to_deal')}</div><div className="meta-val mono">{payment.dealId || '—'}</div></div>
        </div>
      </div>
      <div className="detail">
        <div>
          <div className="card">
            <Attachments items={payment.attachments || []} onChange={onAttachmentsChange} t={t} locale={locale} currentUser={currentUser} />
          </div>
        </div>
        <div>
          <div className="sidebar-card">
            <h4>{t('quick_actions')}</h4>
            <button className="qa-btn" onClick={onPrint}><Printer size={14} /> {t('receipt')}</button>
            <button className="qa-btn" onClick={onEdit}><Edit2 size={14} /> {t('edit')}</button>
          </div>
        </div>
      </div>
    </>
  );
}

function PaymentForm({ payment, state, t, locale, onSave, onClose }) {
  const [f, setF] = useState(payment || {
    id: 'PAY-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random() * 900) + 100),
    year: new Date().getFullYear(), date: new Date().toISOString().slice(0, 10),
    amount: 0, method: 'cash', dealId: null, attachments: [],
  });
  const upd = (k, v) => setF({ ...f, [k]: v });
  return (
    <Modal open onClose={onClose} locale={locale}
      title={payment ? (locale === 'ar' ? 'تعديل دفعة' : 'Edit payment') : (locale === 'ar' ? 'دفعة جديدة' : 'New payment')}
      footer={<>
        <button className="btn" onClick={onClose}>{t('cancel')}</button>
        <button className="btn prim" onClick={() => onSave(f)}><Save size={14} /> {t('save')}</button>
      </>}>
      <div className="form-grid">
        <div className="field"><label>{t('payment_id')}</label><input value={f.id} onChange={(e) => upd('id', e.target.value)} /></div>
        <div className="field"><label>{t('date')}</label><input type="date" value={f.date || ''} onChange={(e) => { const v = e.target.value; setF(prev => ({ ...prev, date: v, year: v ? new Date(v).getFullYear() : prev.year })); }} /></div>
        <div className="field"><label>{t('amount')}</label><input type="number" value={f.amount} onChange={(e) => upd('amount', Number(e.target.value))} /></div>
        <div className="field"><label>{t('method')}</label>
          <select value={f.method} onChange={(e) => upd('method', e.target.value)}>
            <option value="cash">{t('method_cash')}</option>
            <option value="bank">{t('method_bank')}</option>
            <option value="unknown">{t('method_unknown')}</option>
          </select>
        </div>
        <div className="field span-2"><label>{t('link_to_deal')}</label>
          <select value={f.dealId || ''} onChange={(e) => upd('dealId', e.target.value || null)}>
            <option value="">—</option>
            {state.deals.map(d => <option key={d.id} value={d.id}>{d.id} · {d.customerName} ({d.vehicleModel})</option>)}
          </select>
        </div>
      </div>
    </Modal>
  );
}

// ==================== PARTNERS MODULE ====================
function PartnersPage({ state, t, locale, useArNum, setDetail, setModule }) {
  const jy = state.deals.filter(d => d.jeanYasmineShare !== 0);
  const am = state.deals.filter(d => d.ahmedMohsenShare !== 0);
  const jyTotal = jy.reduce((a, d) => a + d.jeanYasmineShare, 0);
  const amTotal = am.reduce((a, d) => a + d.ahmedMohsenShare, 0);
  const totalProfit = state.deals.reduce((a, d) => a + d.profit, 0);

  const partnerRows = (deals, shareKey) => deals.map(d => ({ ...d, share: d[shareKey] })).sort((a, b) => Math.abs(b.share) - Math.abs(a.share));

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('partners')}</div>
          <div className="page-sub">{locale === 'ar' ? 'تتبع عمولات الشركاء' : 'Partner commission tracking'}</div>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi"><div className="kpi-label">{t('kpi_total_profit')}</div><div className="kpi-val sm">{fmtCurrencyShort(totalProfit, useArNum)}</div><div className="kpi-sub">{fmtNumber(state.deals.length, useArNum)} {locale === 'ar' ? 'صفقة' : 'deals'}</div></div>
        <div className="kpi"><div className="kpi-label">{t('jean_yasmine_share')}</div><div className="kpi-val sm info">{fmtCurrencyShort(jyTotal, useArNum)}</div><div className="kpi-sub">{fmtNumber(jy.length, useArNum)} {locale === 'ar' ? 'صفقة' : 'deals'}</div></div>
        <div className="kpi"><div className="kpi-label">{t('ahmed_mohsen_share')}</div><div className="kpi-val sm info">{fmtCurrencyShort(amTotal, useArNum)}</div><div className="kpi-sub">{fmtNumber(am.length, useArNum)} {locale === 'ar' ? 'صفقة' : 'deals'}</div></div>
        <div className="kpi"><div className="kpi-label">{locale === 'ar' ? 'نسبة للعمولات من الأرباح' : 'Shares of profit'}</div><div className="kpi-val sm">{totalProfit > 0 ? Math.round((jyTotal + amTotal) / totalProfit * 100) : 0}%</div></div>
      </div>

      <div className="two-col section">
        <div>
          <div className="section-hd">
            <div className="section-title">{locale === 'ar' ? 'جان/ياسمين — تفاصيل العمولة' : 'Jean/Yasmine — commission detail'}</div>
            <div className="section-sub">{fmtNumber(jy.length, useArNum)} {locale === 'ar' ? 'صفقة · إجمالي ' : 'deals · total '}{fmtCurrencyShort(jyTotal, useArNum)}</div>
          </div>
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr><th>{t('deal_id')}</th><th>{t('customer_name')}</th><th>{t('vehicle_model')}</th><th className="r">{t('profit')}</th><th className="r">{t('share_total')}</th></tr></thead>
              <tbody>
                {partnerRows(jy, 'jeanYasmineShare').map(d => (
                  <tr key={d.id} className="clickable" onClick={() => { setModule('deals'); setDetail({ type: 'deal', id: d.id }); }}>
                    <td className="mono nowrap">{d.id}</td>
                    <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.customerName}</td>
                    <td className="nowrap">{d.vehicleModel}</td>
                    <td className="r nowrap" style={{ color: d.profit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(d.profit, useArNum)}</td>
                    <td className="r nowrap"><b style={{ color: d.share < 0 ? 'var(--color-text-danger)' : 'var(--color-text-info)' }}>{fmtCurrencyShort(d.share, useArNum)}</b></td>
                  </tr>
                ))}
                {jy.length === 0 && <tr><td colSpan={5} className="empty">{t('no_data')}</td></tr>}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <div className="section-hd">
            <div className="section-title">{locale === 'ar' ? 'أحمد محسن — تفاصيل العمولة' : 'Ahmed Mohsen — commission detail'}</div>
            <div className="section-sub">{fmtNumber(am.length, useArNum)} {locale === 'ar' ? 'صفقة · إجمالي ' : 'deals · total '}{fmtCurrencyShort(amTotal, useArNum)}</div>
          </div>
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr><th>{t('deal_id')}</th><th>{t('customer_name')}</th><th>{t('vehicle_model')}</th><th className="r">{t('profit')}</th><th className="r">{t('share_total')}</th></tr></thead>
              <tbody>
                {partnerRows(am, 'ahmedMohsenShare').map(d => (
                  <tr key={d.id} className="clickable" onClick={() => { setModule('deals'); setDetail({ type: 'deal', id: d.id }); }}>
                    <td className="mono nowrap">{d.id}</td>
                    <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.customerName}</td>
                    <td className="nowrap">{d.vehicleModel}</td>
                    <td className="r nowrap" style={{ color: d.profit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(d.profit, useArNum)}</td>
                    <td className="r nowrap"><b style={{ color: d.share < 0 ? 'var(--color-text-danger)' : 'var(--color-text-info)' }}>{fmtCurrencyShort(d.share, useArNum)}</b></td>
                  </tr>
                ))}
                {am.length === 0 && <tr><td colSpan={5} className="empty">{t('no_data')}</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}

// ==================== REPORTS MODULE ====================
function ReportsPage({ state, t, locale, useArNum }) {
  const byYear = { 2025: 0, 2026: 0 };
  state.deals.forEach(d => { byYear[d.year] = (byYear[d.year] || 0) + d.salePrice; });
  const byMonth = state.monthly.map(m => ({ month: m.month.slice(0,3), '2025': m.y2025, '2026': m.y2026 }));

  const profitByModel = {};
  state.deals.forEach(d => {
    const k = d.vehicleModel;
    if (!profitByModel[k]) profitByModel[k] = { count: 0, revenue: 0, profit: 0 };
    profitByModel[k].count++;
    profitByModel[k].revenue += d.salePrice;
    profitByModel[k].profit += d.profit;
  });
  const topModels = Object.entries(profitByModel).sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 10);

  const monthlyRevenue = {}; // deals-based revenue by YYYY-MM
  state.deals.forEach(d => {
    if (!d.date) return;
    const k = d.date.slice(0, 7);
    monthlyRevenue[k] = (monthlyRevenue[k] || 0) + d.salePrice;
  });
  const revenueTrend = Object.entries(monthlyRevenue).sort().map(([k, v]) => ({ month: k, revenue: v }));

  const statusMix = [
    { name: t('delivered'), value: state.deals.filter(d => d.deliveryStatus === 'delivered').length, color: '#1D9E75' },
    { name: t('pending'), value: state.deals.filter(d => d.deliveryStatus === 'pending').length, color: '#BA7517' },
  ];

  const top10Customers = [...state.customers].sort((a, b) => b.totalSpend - a.totalSpend).slice(0, 10);

  const csvDownload = () => {
    const rows = [['Deal ID','Date','Customer','Vehicle','Chassis','Color','List Price','Sale Price','Profit','Status','J/Y Share','A.M Share']];
    state.deals.forEach(d => rows.push([d.id, d.date || '', d.customerName, d.vehicleModel, d.chassis || '', d.color, d.listPrice, d.salePrice, d.profit, d.deliveryStatus, d.jeanYasmineShare, d.ahmedMohsenShare]));
    const csv = rows.map(r => r.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\n');
    const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'abou_ghali_deals.csv'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <>
      <div className="page-hd">
        <div>
          <div className="page-title">{t('reports')}</div>
          <div className="page-sub">{locale === 'ar' ? 'تحليل الأداء والتصدير' : 'Performance analytics and export'}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" onClick={csvDownload}><FileDown size={14} /> CSV</button>
          <button className="btn" onClick={() => window.print()}><Printer size={14} /> {t('print')}</button>
        </div>
      </div>

      <div className="two-col">
        <div className="card">
          <div className="section-hd"><div className="section-title">{locale === 'ar' ? 'الإيرادات الشهرية (تحصيلات)' : 'Monthly collections'}</div></div>
          <ResponsiveContainer width="100%" height={240}>
            <ComposedChart data={byMonth} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border-tertiary)" />
              <XAxis dataKey="month" fontSize={11} stroke="var(--color-text-secondary)" />
              <YAxis fontSize={11} stroke="var(--color-text-secondary)" tickFormatter={v => v >= 1e6 ? (v/1e6).toFixed(0)+'M' : v >= 1e3 ? (v/1e3).toFixed(0)+'K' : v} />
              <Tooltip contentStyle={{ background: 'var(--color-background-primary)', border: '0.5px solid var(--color-border-tertiary)', borderRadius: 8, fontSize: 12 }} formatter={v => fmtCurrency(v, useArNum)} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="2025" fill="#BA7517" radius={[3,3,0,0]} />
              <Line type="monotone" dataKey="2026" stroke="#1D9E75" strokeWidth={2} dot={{ r: 3 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="section-hd"><div className="section-title">{locale === 'ar' ? 'توزيع حالة التسليم' : 'Delivery status mix'}</div></div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={statusMix} cx="50%" cy="50%" innerRadius={60} outerRadius={90} dataKey="value" paddingAngle={2}>
                {statusMix.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background: 'var(--color-background-primary)', border: '0.5px solid var(--color-border-tertiary)', borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="section">
        <div className="section-hd"><div className="section-title">{locale === 'ar' ? 'الإيرادات والأرباح حسب الموديل (أفضل ١٠)' : 'Revenue & profit by model (top 10)'}</div></div>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>#</th><th>{t('vehicle_model')}</th><th className="r">{locale === 'ar' ? 'الصفقات' : 'Deals'}</th><th className="r">{locale === 'ar' ? 'الإيراد' : 'Revenue'}</th><th className="r">{t('profit')}</th><th className="r">{locale === 'ar' ? 'هامش' : 'Margin'}</th></tr></thead>
            <tbody>
              {topModels.map(([name, d], i) => (
                <tr key={name}>
                  <td className="mono">{fmtNumber(i + 1, useArNum)}</td>
                  <td><b>{name}</b></td>
                  <td className="r">{fmtNumber(d.count, useArNum)}</td>
                  <td className="r">{fmtCurrencyShort(d.revenue, useArNum)}</td>
                  <td className="r" style={{ color: d.profit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(d.profit, useArNum)}</td>
                  <td className="r">{d.revenue ? (d.profit / d.revenue * 100).toFixed(1) : '0.0'}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="section">
        <div className="section-hd"><div className="section-title">{t('top_customers')}</div></div>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>#</th><th>{t('customer_name')}</th><th className="r">{t('total_deals')}</th><th className="r">{t('total_spend')}</th><th className="r">{t('profit')}</th><th>{t('models_purchased')}</th></tr></thead>
            <tbody>
              {top10Customers.map((c, i) => (
                <tr key={c.id}>
                  <td className="mono">{fmtNumber(i + 1, useArNum)}</td>
                  <td><b>{c.name}</b> <span style={{ color: 'var(--color-text-secondary)', fontSize: 11 }}>· {c.id}</span></td>
                  <td className="r">{fmtNumber(c.totalDeals, useArNum)}</td>
                  <td className="r"><b>{fmtCurrencyShort(c.totalSpend, useArNum)}</b></td>
                  <td className="r" style={{ color: c.totalProfit < 0 ? 'var(--color-text-danger)' : 'var(--color-text-success)' }}>{fmtCurrencyShort(c.totalProfit, useArNum)}</td>
                  <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.modelsPurchased}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

// ==================== PRINT VIEWS ====================
function PrintContract({ deal, state, t, locale, useArNum, onClose }) {
  const customer = state.customers.find(c => c.id === deal.customerId) || { name: deal.customerName, nationalId: deal.nationalId, mobile: deal.mobile };
  const paid = state.payments.filter(p => p.dealId === deal.id).reduce((a, p) => a + p.amount, 0);
  const balance = deal.salePrice - paid;
  useEffect(() => { const to = setTimeout(() => window.print(), 300); return () => clearTimeout(to); }, []);
  return (
    <div className="modal-wrap no-print" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{ maxWidth: 780, width: '100%', background: 'white', color: 'black' }}>
        <div className="print-doc printable" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
          <div className="p-hd">
            <div>
              <h1>{t('brand')}</h1>
              <div style={{ fontSize: 11, color: '#444', marginTop: 2 }}>{t('hq_line')}</div>
            </div>
            <div style={{ textAlign: locale === 'ar' ? 'left' : 'right', fontSize: 12 }}>
              <div><b>{t('contract')}</b></div>
              <div>{deal.id}</div>
              <div style={{ color: '#666' }}>{fmtDate(deal.date, locale, useArNum)}</div>
            </div>
          </div>
          <h2>{t('customer_name')}</h2>
          <table>
            <tbody>
              <tr><th style={{ width: '30%' }}>{t('customer_name')}</th><td>{customer.name}</td></tr>
              <tr><th>{t('national_id')}</th><td>{customer.nationalId || '—'}</td></tr>
              <tr><th>{t('mobile')}</th><td>{customer.mobile || '—'}</td></tr>
            </tbody>
          </table>
          <h2>{t('vehicle_model')}</h2>
          <table>
            <tbody>
              <tr><th style={{ width: '30%' }}>{t('vehicle_model')}</th><td>{deal.vehicleModel}</td></tr>
              <tr><th>{t('color')}</th><td>{deal.color}</td></tr>
              <tr><th>{t('chassis')}</th><td>{deal.chassis || '—'}</td></tr>
            </tbody>
          </table>
          <h2>{t('summary' in DICT ? 'summary' : 'details')}</h2>
          <table>
            <tbody>
              <tr><th style={{ width: '30%' }}>{t('list_price')}</th><td>{fmtCurrency(deal.listPrice, useArNum)}</td></tr>
              <tr><th>{t('sale_price')}</th><td><b>{fmtCurrency(deal.salePrice, useArNum)}</b></td></tr>
              <tr><th>{t('collected')}</th><td>{fmtCurrency(paid, useArNum)}</td></tr>
              <tr><th>{t('balance')}</th><td><b>{fmtCurrency(balance, useArNum)}</b></td></tr>
            </tbody>
          </table>
          {deal.notes && <><h2>{t('notes')}</h2><p style={{ fontSize: 12 }}>{deal.notes}</p></>}
          <div className="sig">
            <div>{t('customer_signature' in DICT ? 'customer_signature' : 'signature')}</div>
            <div>{locale === 'ar' ? 'عن أبو غالي لتجارة السيارات' : 'For Abou Ghali Car Sales'}</div>
          </div>
          <div className="p-foot">
            <span>{t('thanks')}</span>
            <span>{t('printed_on')}: {fmtDate(new Date().toISOString(), locale, useArNum)}</span>
          </div>
        </div>
        <div className="modal-btn-row no-print" style={{ background: 'white', padding: '12px 20px' }}>
          <button className="btn" onClick={onClose}>{t('close')}</button>
          <button className="btn prim" onClick={() => window.print()}><Printer size={14} /> {t('print')}</button>
        </div>
      </div>
    </div>
  );
}

function PrintReceipt({ payment, state, t, locale, useArNum, onClose }) {
  const deal = state.deals.find(d => d.id === payment.dealId);
  useEffect(() => { const to = setTimeout(() => window.print(), 300); return () => clearTimeout(to); }, []);
  return (
    <div className="modal-wrap no-print" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{ maxWidth: 600, width: '100%', background: 'white' }}>
        <div className="print-doc printable" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
          <div className="p-hd">
            <div><h1>{t('brand')}</h1><div style={{ fontSize: 11, color: '#444', marginTop: 2 }}>{t('hq_line')}</div></div>
            <div style={{ textAlign: locale === 'ar' ? 'left' : 'right', fontSize: 12 }}>
              <div><b>{t('receipt')}</b></div>
              <div>{payment.id}</div>
              <div style={{ color: '#666' }}>{fmtDate(payment.date, locale, useArNum)}</div>
            </div>
          </div>
          <table style={{ marginTop: 20 }}>
            <tbody>
              <tr><th style={{ width: '40%' }}>{t('amount')}</th><td><b style={{ fontSize: 20 }}>{fmtCurrency(payment.amount, useArNum)}</b></td></tr>
              <tr><th>{t('method')}</th><td>{t(METHOD_LABELS[payment.method])}</td></tr>
              <tr><th>{t('date')}</th><td>{fmtDate(payment.date, locale, useArNum)}</td></tr>
              {deal && <>
                <tr><th>{t('deal_id')}</th><td>{deal.id}</td></tr>
                <tr><th>{t('customer_name')}</th><td>{deal.customerName}</td></tr>
                <tr><th>{t('vehicle_model')}</th><td>{deal.vehicleModel} · {deal.color}</td></tr>
              </>}
            </tbody>
          </table>
          <div className="sig"><div>{t('customer_signature' in DICT ? 'customer_signature' : 'signature')}</div><div>{locale === 'ar' ? 'عن أبو غالي لتجارة السيارات' : 'For Abou Ghali Car Sales'}</div></div>
          <div className="p-foot"><span>{t('thanks')}</span><span>{t('printed_on')}: {fmtDate(new Date().toISOString(), locale, useArNum)}</span></div>
        </div>
        <div className="modal-btn-row no-print" style={{ background: 'white', padding: '12px 20px' }}>
          <button className="btn" onClick={onClose}>{t('close')}</button>
          <button className="btn prim" onClick={() => window.print()}><Printer size={14} /> {t('print')}</button>
        </div>
      </div>
    </div>
  );
}

function PrintStockCard({ item, t, locale, useArNum, onClose }) {
  useEffect(() => { const to = setTimeout(() => window.print(), 300); return () => clearTimeout(to); }, []);
  return (
    <div className="modal-wrap no-print" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{ maxWidth: 600, width: '100%', background: 'white' }}>
        <div className="print-doc printable" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
          <div className="p-hd">
            <div><h1>{t('brand')}</h1><div style={{ fontSize: 11, color: '#444', marginTop: 2 }}>{t('hq_line')}</div></div>
            <div style={{ textAlign: locale === 'ar' ? 'left' : 'right', fontSize: 12 }}>
              <div><b>{t('stock_card')}</b></div>
              <div>{item.id}</div>
            </div>
          </div>
          <table style={{ marginTop: 20 }}>
            <tbody>
              <tr><th style={{ width: '35%' }}>{t('vehicle_model')}</th><td><b>{item.vehicleModel}</b></td></tr>
              <tr><th>{t('year')}</th><td>{fmtNumber(item.year, useArNum)}</td></tr>
              <tr><th>{t('color')}</th><td>{item.color}</td></tr>
              <tr><th>{t('chassis')}</th><td>{item.chassis || '—'}</td></tr>
              <tr><th>{t('keys')}</th><td>{fmtNumber(item.keys, useArNum)}</td></tr>
              <tr><th>{t('location')}</th><td>{item.location}</td></tr>
              <tr><th>{t('status')}</th><td>{t(STATUS_LABELS[item.status])}</td></tr>
              {item.comment && <tr><th>{t('comment')}</th><td>{item.comment}</td></tr>}
            </tbody>
          </table>
          <div className="p-foot"><span>{t('thanks')}</span><span>{t('printed_on')}: {fmtDate(new Date().toISOString(), locale, useArNum)}</span></div>
        </div>
        <div className="modal-btn-row no-print" style={{ background: 'white', padding: '12px 20px' }}>
          <button className="btn" onClick={onClose}>{t('close')}</button>
          <button className="btn prim" onClick={() => window.print()}><Printer size={14} /> {t('print')}</button>
        </div>
      </div>
    </div>
  );
}

// ==================== MAIN APP ====================
// ==================== SIGN IN ====================
function SignIn({ t, locale, setLocale, onAuthenticate }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const submit = (e) => {
    if (e) e.preventDefault();
    const u = SEED_USERS.find(x =>
      x.username && x.password &&
      x.username.toLowerCase() === username.trim().toLowerCase() &&
      x.password === password
    );
    if (!u) { setError(t('signin_error')); return; }
    setError('');
    onAuthenticate(u);
  };

  return (
    <div className="signin-screen" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
      <div className="signin-langbar">
        <button className={'signin-lang' + (locale === 'ar' ? ' active' : '')} onClick={() => setLocale('ar')}>عربي</button>
        <span className="signin-lang-sep">·</span>
        <button className={'signin-lang' + (locale === 'en' ? ' active' : '')} onClick={() => setLocale('en')}>English</button>
      </div>

      <div className="signin-card">
        <div className="signin-brand">
          <div className="signin-brand-name">{t('brand')}</div>
          <div className="signin-brand-sub">{t('signin_subtitle')}</div>
        </div>

        <form className="signin-form" onSubmit={submit}>
          <div className="signin-field">
            <label>{t('signin_username')}</label>
            <input
              type="text"
              autoComplete="username"
              autoFocus
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              dir="ltr"
            />
          </div>
          <div className="signin-field">
            <label>{t('signin_password')}</label>
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              dir="ltr"
            />
          </div>
          {error && <div className="signin-error"><AlertCircle size={13} /> {error}</div>}
          <button type="submit" className="signin-submit">{t('signin_submit')}</button>
        </form>
      </div>
    </div>
  );
}

// ==================== ROOT COMPONENT ====================
export default function AbouGhaliCRM() {
  const [state, setState] = useState(() => buildInitialState());
  const [currentUser, setCurrentUser] = useState(null);
  const [module, setModule] = useState('dashboard');
  const [detail, setDetail] = useState(null); // { type, id }
  const [locale, setLocale] = useState('ar');
  const [useArNum, setUseArNum] = useState(true);
  const [editOpen, setEditOpen] = useState(null); // { type, record?, isNew }
  const [confirmDel, setConfirmDel] = useState(null); // { type, id }
  const [printing, setPrinting] = useState(null); // { type, id }
  const t = useT(locale);

  // ----- Auth handlers -----
  const handleAuthenticate = (user) => {
    setCurrentUser(user);
    // Drop them on the first module their role can access
    setModule(firstAllowedModule(user));
    setDetail(null);
  };
  const handleSignOut = () => {
    setCurrentUser(null);
    setDetail(null);
    setEditOpen(null);
    setConfirmDel(null);
    setPrinting(null);
  };

  // ----- Role-gate the active module: if the user navigates somewhere they
  // shouldn't be (e.g. via global search), bounce them to a permitted module.
  useEffect(() => {
    if (!currentUser) return;
    if (!canAccess(currentUser, module)) {
      setModule(firstAllowedModule(currentUser));
      setDetail(null);
    }
  }, [currentUser, module]);

  // Same gate for detail records — block deep-links to records of forbidden types
  useEffect(() => {
    if (!currentUser || !detail) return;
    const typeToModule = { deal: 'deals', customer: 'customers', lead: 'pipeline', stock: 'stock', payment: 'payments' };
    const required = typeToModule[detail.type];
    if (required && !canAccess(currentUser, required)) {
      setDetail(null);
    }
  }, [currentUser, detail]);

  // Reset detail when user clicks a different module in the sidebar (but not for programmatic nav)
  const prevModule = useRef(module);
  useEffect(() => {
    if (prevModule.current !== module) {
      // Only reset if the detail's type doesn't match the new module
      const matchingTypes = {
        deals: ['deal'], customers: ['customer'], pipeline: ['lead'],
        stock: ['stock'], payments: ['payment'],
      };
      const allowed = matchingTypes[module] || [];
      if (!detail || !allowed.includes(detail.type)) {
        setDetail(null);
      }
      prevModule.current = module;
    }
  }, [module, detail]);

  // ----- Recompute customer aggregates after any deal change -----
  function recomputeCustomers(deals, customers) {
    const byId = {};
    deals.forEach(d => {
      if (!d.customerId) return;
      if (!byId[d.customerId]) byId[d.customerId] = { totalDeals: 0, totalSpend: 0, totalProfit: 0, firstDealDate: null, lastDealDate: null, models: new Set() };
      const c = byId[d.customerId];
      c.totalDeals++;
      c.totalSpend += d.salePrice;
      c.totalProfit += d.profit;
      if (d.date) {
        if (!c.firstDealDate || d.date < c.firstDealDate) c.firstDealDate = d.date;
        if (!c.lastDealDate || d.date > c.lastDealDate) c.lastDealDate = d.date;
      }
      c.models.add(d.vehicleModel);
    });
    return customers.map(c => {
      const agg = byId[c.id];
      if (!agg) return c;
      return {
        ...c,
        totalDeals: agg.totalDeals,
        totalSpend: agg.totalSpend,
        totalProfit: agg.totalProfit,
        firstDealDate: agg.firstDealDate,
        lastDealDate: agg.lastDealDate,
        modelsPurchased: [...agg.models].join(', '),
        segment: agg.totalDeals > 1 ? 'repeat' : c.segment,
      };
    });
  }

  // ================ DEAL HANDLERS ================
  const saveDeal = (d) => {
    const profit = (Number(d.salePrice) || 0) - (Number(d.listPrice) || 0);
    const full = { ...d, profit, attachments: d.attachments || [] };
    setState(s => {
      const exists = s.deals.find(x => x.id === full.id);
      const deals = exists ? s.deals.map(x => x.id === full.id ? full : x) : [...s.deals, full];
      return { ...s, deals, customers: recomputeCustomers(deals, s.customers) };
    });
    setEditOpen(null);
  };
  const deleteDeal = (id) => {
    setState(s => {
      const deals = s.deals.filter(d => d.id !== id);
      return { ...s, deals, customers: recomputeCustomers(deals, s.customers) };
    });
    setDetail(null);
    setConfirmDel(null);
  };
  const updateDealAttachments = (id, atts) => {
    setState(s => ({ ...s, deals: s.deals.map(d => d.id === id ? { ...d, attachments: atts } : d) }));
  };

  // ================ CUSTOMER HANDLERS ================
  const saveCustomer = (c) => {
    setState(s => {
      const exists = s.customers.find(x => x.id === c.id);
      const customers = exists ? s.customers.map(x => x.id === c.id ? { ...x, ...c } : x) : [...s.customers, { ...c, attachments: c.attachments || [] }];
      return { ...s, customers };
    });
    setEditOpen(null);
  };
  const deleteCustomer = (id) => {
    setState(s => ({ ...s, customers: s.customers.filter(c => c.id !== id) }));
    setDetail(null); setConfirmDel(null);
  };
  const updateCustomerAttachments = (id, atts) => {
    setState(s => ({ ...s, customers: s.customers.map(c => c.id === id ? { ...c, attachments: atts } : c) }));
  };

  // ================ LEAD HANDLERS ================
  const saveLead = (l) => {
    setState(s => {
      const exists = s.leads.find(x => x.id === l.id);
      const leads = exists ? s.leads.map(x => x.id === l.id ? { ...x, ...l } : x) : [...s.leads, { ...l, attachments: l.attachments || [] }];
      return { ...s, leads };
    });
    setEditOpen(null);
  };
  const deleteLead = (id) => {
    setState(s => ({ ...s, leads: s.leads.filter(l => l.id !== id) }));
    setDetail(null); setConfirmDel(null);
  };
  const updateLeadAttachments = (id, atts) => {
    setState(s => ({ ...s, leads: s.leads.map(l => l.id === id ? { ...l, attachments: atts } : l) }));
  };
  const changeLeadStage = (id, stage) => {
    setState(s => ({ ...s, leads: s.leads.map(l => l.id === id ? { ...l, stage } : l) }));
  };
  const convertLead = (lead, opts) => {
    let newDealId = null;
    setState(s => {
      let customer;
      let customerList = s.customers;
      if (opts.mode === 'link' && opts.customerId) {
        customer = s.customers.find(c => c.id === opts.customerId);
      } else {
        const newId = 'CUST-' + String(s.customers.length + 1).padStart(3, '0');
        customer = {
          id: newId, name: lead.customerName, nationalId: opts.nationalId || null, mobile: lead.mobile,
          totalDeals: 0, totalSpend: 0, totalProfit: 0,
          firstDealDate: null, lastDealDate: null,
          modelsPurchased: lead.vehicleModel, segment: 'standard', attachments: [],
        };
        customerList = [...s.customers, customer];
      }
      const dealId = 'DEAL-' + new Date().getFullYear() + '-' + String(s.deals.length + 1).padStart(3, '0');
      newDealId = dealId;
      const newDeal = {
        id: dealId, year: new Date().getFullYear(), date: new Date().toISOString().slice(0, 10),
        customerId: customer.id, customerName: customer.name,
        nationalId: customer.nationalId, mobile: customer.mobile,
        vehicleModel: lead.vehicleModel, chassis: null, color: lead.color,
        listPrice: opts.listPrice, salePrice: opts.salePrice, profit: opts.salePrice - opts.listPrice,
        deliveryStatus: 'pending',
        jeanYasmineShare: 0, ahmedMohsenShare: 0,
        notes: lead.notes, assignedTo: lead.assignedTo, linkedStockId: null, attachments: [],
      };
      const deals = [...s.deals, newDeal];
      const customers = recomputeCustomers(deals, customerList);
      const leads = s.leads.map(l => l.id === lead.id ? { ...l, stage: 'converted', convertedDealId: dealId, convertedCustomerId: customer.id } : l);
      return { ...s, deals, customers, leads };
    });
    // Navigate to the newly created deal after state flushes
    setTimeout(() => {
      setModule('deals');
      if (newDealId) setDetail({ type: 'deal', id: newDealId });
    }, 0);
  };

  // ================ STOCK HANDLERS ================
  const saveStock = (item) => {
    setState(s => {
      const exists = s.stock.find(x => x.id === item.id);
      const stock = exists ? s.stock.map(x => x.id === item.id ? { ...x, ...item } : x) : [...s.stock, { ...item, attachments: item.attachments || [] }];
      return { ...s, stock };
    });
    setEditOpen(null);
  };
  const deleteStock = (id) => {
    setState(s => ({ ...s, stock: s.stock.filter(x => x.id !== id) }));
    setDetail(null); setConfirmDel(null);
  };
  const changeStockStatus = (id, status) => {
    setState(s => ({ ...s, stock: s.stock.map(x => x.id === id ? { ...x, status } : x) }));
  };
  const updateStockAttachments = (id, atts) => {
    setState(s => ({ ...s, stock: s.stock.map(x => x.id === id ? { ...x, attachments: atts } : x) }));
  };

  // ================ PAYMENT HANDLERS ================
  const savePayment = (p) => {
    setState(s => {
      const exists = s.payments.find(x => x.id === p.id);
      const payments = exists ? s.payments.map(x => x.id === p.id ? { ...x, ...p } : x) : [...s.payments, { ...p, attachments: p.attachments || [] }];
      return { ...s, payments };
    });
    setEditOpen(null);
  };
  const deletePayment = (id) => {
    setState(s => ({ ...s, payments: s.payments.filter(x => x.id !== id) }));
    setDetail(null); setConfirmDel(null);
  };
  const updatePaymentAttachments = (id, atts) => {
    setState(s => ({ ...s, payments: s.payments.map(p => p.id === id ? { ...p, attachments: atts } : p) }));
  };

  // ================ GLOBAL NEW QUICK CREATE ================
  const openNewFor = (kind) => {
    if (kind === 'deal') setEditOpen({ type: 'deal', record: null });
    else if (kind === 'customer') setEditOpen({ type: 'customer', record: null });
    else if (kind === 'lead') setEditOpen({ type: 'lead', record: null });
    else if (kind === 'stock') setEditOpen({ type: 'stock', record: null });
    else if (kind === 'payment') setEditOpen({ type: 'payment', record: null });
  };

  // ================ RENDER ROUTING ================
  const renderModule = () => {
    if (detail) {
      if (detail.type === 'deal') {
        const deal = state.deals.find(d => d.id === detail.id);
        if (!deal) return <DealsList state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onNew={() => openNewFor('deal')} />;
        return <DealDetail
          deal={deal} state={state} t={t} locale={locale} useArNum={useArNum}
          onEdit={() => setEditOpen({ type: 'deal', record: deal })}
          onDelete={() => setConfirmDel({ type: 'deal', id: deal.id })}
          onPrint={() => setPrinting({ type: 'contract', id: deal.id })}
          onBack={() => setDetail(null)}
          onAttachmentsChange={(a) => updateDealAttachments(deal.id, a)}
          currentUser={currentUser} setDetail={setDetail}
        />;
      }
      if (detail.type === 'customer') {
        const customer = state.customers.find(c => c.id === detail.id);
        if (!customer) return <CustomersList state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onNew={() => openNewFor('customer')} />;
        return <CustomerDetail
          customer={customer} state={state} t={t} locale={locale} useArNum={useArNum}
          onEdit={() => setEditOpen({ type: 'customer', record: customer })}
          onDelete={() => setConfirmDel({ type: 'customer', id: customer.id })}
          onBack={() => setDetail(null)}
          onAttachmentsChange={(a) => updateCustomerAttachments(customer.id, a)}
          currentUser={currentUser} setDetail={setDetail}
        />;
      }
      if (detail.type === 'lead') {
        const lead = state.leads.find(l => l.id === detail.id);
        if (!lead) return <PipelineBoard state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onStageChange={changeLeadStage} onNew={() => openNewFor('lead')} />;
        return <LeadDetail
          lead={lead} state={state} t={t} locale={locale} useArNum={useArNum}
          onEdit={() => setEditOpen({ type: 'lead', record: lead })}
          onDelete={() => setConfirmDel({ type: 'lead', id: lead.id })}
          onBack={() => setDetail(null)}
          onConvert={convertLead}
          onStageChange={changeLeadStage}
          onAttachmentsChange={(a) => updateLeadAttachments(lead.id, a)}
          currentUser={currentUser} setDetail={setDetail}
        />;
      }
      if (detail.type === 'stock') {
        const item = state.stock.find(s => s.id === detail.id);
        if (!item) return <StockList state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onNew={() => openNewFor('stock')} />;
        return <StockDetail
          item={item} state={state} t={t} locale={locale} useArNum={useArNum}
          onEdit={() => setEditOpen({ type: 'stock', record: item })}
          onDelete={() => setConfirmDel({ type: 'stock', id: item.id })}
          onStatusChange={changeStockStatus}
          onPrint={() => setPrinting({ type: 'stockCard', id: item.id })}
          onBack={() => setDetail(null)}
          onAttachmentsChange={(a) => updateStockAttachments(item.id, a)}
          currentUser={currentUser} setDetail={setDetail}
        />;
      }
      if (detail.type === 'payment') {
        const payment = state.payments.find(p => p.id === detail.id);
        if (!payment) return <PaymentsList state={state} t={t} locale={locale} useArNum={useArNum} onNew={() => openNewFor('payment')} onEdit={(p) => setEditOpen({ type: 'payment', record: p })} setDetail={setDetail} />;
        return <PaymentDetail
          payment={payment} state={state} t={t} locale={locale} useArNum={useArNum}
          onEdit={() => setEditOpen({ type: 'payment', record: payment })}
          onDelete={() => setConfirmDel({ type: 'payment', id: payment.id })}
          onPrint={() => setPrinting({ type: 'receipt', id: payment.id })}
          onBack={() => setDetail(null)}
          onAttachmentsChange={(a) => updatePaymentAttachments(payment.id, a)}
          currentUser={currentUser}
        />;
      }
    }

    switch (module) {
      case 'dashboard': return <Dashboard state={state} t={t} locale={locale} useArNum={useArNum} setModule={setModule} setDetail={setDetail} />;
      case 'deals': return <DealsList state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onNew={() => openNewFor('deal')} />;
      case 'customers': return <CustomersList state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onNew={() => openNewFor('customer')} />;
      case 'pipeline': return <PipelineBoard state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onStageChange={changeLeadStage} onNew={() => openNewFor('lead')} />;
      case 'stock': return <StockList state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} onNew={() => openNewFor('stock')} />;
      case 'movements': return <MovementsList state={state} t={t} locale={locale} useArNum={useArNum} />;
      case 'payments': return <PaymentsList state={state} t={t} locale={locale} useArNum={useArNum} onNew={() => openNewFor('payment')} onEdit={(p) => setEditOpen({ type: 'payment', record: p })} setDetail={setDetail} />;
      case 'partners': return <PartnersPage state={state} t={t} locale={locale} useArNum={useArNum} setDetail={setDetail} setModule={setModule} />;
      case 'reports': return <ReportsPage state={state} t={t} locale={locale} useArNum={useArNum} />;
      default: return null;
    }
  };

  return (
    <>
      <style>{CSS}</style>
      {!currentUser ? (
        <div className="ag-root" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
          <SignIn t={t} locale={locale} setLocale={setLocale} onAuthenticate={handleAuthenticate} />
        </div>
      ) : (
      <div className="ag-root" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
        <div className={'shell' + (locale === 'ar' ? ' rtl' : '')}>
          <Sidebar module={module} setModule={setModule} state={state} t={t} locale={locale} currentUser={currentUser} />
          <div className="main">
            <TopBar state={state} t={t} locale={locale} setLocale={setLocale} useArNum={useArNum} setUseArNum={setUseArNum} onGlobalOpen={openNewFor} setModule={setModule} setDetail={setDetail} currentUser={currentUser} onSignOut={handleSignOut} />
            <div className="content">
              {renderModule()}
            </div>
          </div>
        </div>

        {/* Edit / New modals */}
        {editOpen && editOpen.type === 'deal' && <DealForm deal={editOpen.record} state={state} t={t} locale={locale} useArNum={useArNum} onSave={saveDeal} onClose={() => setEditOpen(null)} />}
        {editOpen && editOpen.type === 'customer' && <CustomerForm customer={editOpen.record} t={t} locale={locale} onSave={saveCustomer} onClose={() => setEditOpen(null)} />}
        {editOpen && editOpen.type === 'lead' && <LeadForm lead={editOpen.record} t={t} locale={locale} onSave={saveLead} onClose={() => setEditOpen(null)} />}
        {editOpen && editOpen.type === 'stock' && <StockForm item={editOpen.record} t={t} locale={locale} onSave={saveStock} onClose={() => setEditOpen(null)} />}
        {editOpen && editOpen.type === 'payment' && <PaymentForm payment={editOpen.record} state={state} t={t} locale={locale} onSave={savePayment} onClose={() => setEditOpen(null)} />}

        {/* Delete confirmation */}
        {confirmDel && (
          <Modal open onClose={() => setConfirmDel(null)} locale={locale}
            title={t('confirm_delete')}
            footer={<>
              <button className="btn" onClick={() => setConfirmDel(null)}>{t('cancel')}</button>
              <button className="btn danger prim" style={{ background: 'var(--color-text-danger)', borderColor: 'var(--color-text-danger)' }} onClick={() => {
                if (confirmDel.type === 'deal') deleteDeal(confirmDel.id);
                else if (confirmDel.type === 'customer') deleteCustomer(confirmDel.id);
                else if (confirmDel.type === 'lead') deleteLead(confirmDel.id);
                else if (confirmDel.type === 'stock') deleteStock(confirmDel.id);
                else if (confirmDel.type === 'payment') deletePayment(confirmDel.id);
              }}><Trash2 size={14} /> {t('delete')}</button>
            </>}>
            <p style={{ fontSize: 13, color: 'var(--color-text-secondary)' }}>{t('delete_warn')}</p>
          </Modal>
        )}

        {/* Print overlays */}
        {printing && printing.type === 'contract' && (() => {
          const deal = state.deals.find(d => d.id === printing.id);
          return deal ? <PrintContract deal={deal} state={state} t={t} locale={locale} useArNum={useArNum} onClose={() => setPrinting(null)} /> : null;
        })()}
        {printing && printing.type === 'receipt' && (() => {
          const payment = state.payments.find(p => p.id === printing.id);
          return payment ? <PrintReceipt payment={payment} state={state} t={t} locale={locale} useArNum={useArNum} onClose={() => setPrinting(null)} /> : null;
        })()}
        {printing && printing.type === 'stockCard' && (() => {
          const item = state.stock.find(s => s.id === printing.id);
          return item ? <PrintStockCard item={item} t={t} locale={locale} useArNum={useArNum} onClose={() => setPrinting(null)} /> : null;
        })()}
      </div>
      )}
    </>
  );
}
